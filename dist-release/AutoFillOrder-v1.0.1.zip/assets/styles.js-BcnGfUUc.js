(function(){(()=>{(function(){if(typeof document>"u")return;const r="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@300;400;500;600;700&family=Noto+Sans:wght@300;400;500;600;700&display=swap";if(!document.querySelector(`link[href="${r}"]`))try{const e=document.createElement("link");e.rel="stylesheet",e.href=r,e.crossOrigin="anonymous",document.head.appendChild(e)}catch{}})();const o=`
/* Font fallback tốt cho cả trường hợp Google Fonts bị block */

#vnpost-autofill-panel {
    /* --- DESIGN SYSTEM TOKENS --- */
    --space-xs: 4px;
    --space-sm: 8px;
    --space-md: 16px;
    --space-lg: 24px;
    --space-xl: 32px;
    
    --shadow-sm: 0 1px 2px rgba(0,0,0,0.05);
    --shadow-md: 0 4px 6px rgba(0,0,0,0.1);
    --shadow-lg: 0 10px 15px rgba(0,0,0,0.1);
    --shadow-xl: 0 20px 25px rgba(0,0,0,0.15);
    
    --transition-fast: 150ms cubic-bezier(0.4, 0, 0.2, 1);
    --transition-normal: 250ms cubic-bezier(0.4, 0, 0.2, 1);
    
    /* True Glassmorphism Deep Midnight */
    --bg-panel: rgba(15, 23, 42, 0.94);
    --border-panel: rgba(255, 255, 255, 0.1);
    --text-primary: #f8fafc;
    --text-secondary: #94a3b8;
    --text-muted: #64748b;
    
    --btn-parse-bg: linear-gradient(135deg, #10b981 0%, #059669 100%);
    --btn-parse-bg-hover: linear-gradient(135deg, #059669 0%, #047857 100%);
    --btn-parse-border: rgba(255, 255, 255, 0.15);
    --btn-parse-border-hover: rgba(255, 255, 255, 0.3);
    --btn-parse-text: #ffffff;
    
    --btn-clear-bg: rgba(255, 255, 255, 0.05);
    --btn-clear-border: rgba(255, 255, 255, 0.08);
    --btn-clear-text: #94a3b8;
    
    --card-bg: rgba(30, 41, 59, 0.5);
    --card-border: rgba(255, 255, 255, 0.08);
    --card-row-bg: rgba(15, 23, 42, 0.6);
    --card-row-border: rgba(255, 255, 255, 0.08);
    --card-row-hover-bg: rgba(30, 41, 59, 0.85);
    --card-row-hover-border: rgba(16, 185, 129, 0.35);
    
    --input-bg: rgba(15, 23, 42, 0.75);
    --input-border: rgba(255, 255, 255, 0.12);
    --input-text: #f8fafc;
    --input-focus-bg: rgba(15, 23, 42, 0.95);
    
    --cod-bg: linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(16, 185, 129, 0.18) 100%);
    --cod-border: rgba(16, 185, 129, 0.28);
    --cod-text: #34d399;
    --cod-val: #10b981;
    
    --ai-box-bg: rgba(30, 41, 59, 0.6);
    --ai-box-border: rgba(56, 189, 248, 0.25);
    --ai-box-text: #e0f2fe;
    --ai-box-title: #38bdf8;
    --ai-box-accent: #38bdf8;
    --ai-item-bg: rgba(15, 23, 42, 0.7);
    --ai-item-border: rgba(56, 189, 248, 0.2);
    --ai-item-hover-bg: rgba(30, 41, 59, 0.95);
    
    --progress-bg: rgba(16, 185, 129, 0.25);
    
    /* --- STRUCTURAL LAYOUT --- */
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 999999;
    background: var(--bg-panel);
    backdrop-filter: blur(24px) saturate(180%);
    -webkit-backdrop-filter: blur(24px) saturate(180%);
    width: 360px;
    font-family: 'Be Vietnam Pro', 'Noto Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    border-radius: 16px;
    box-shadow: 0 25px 60px rgba(0, 0, 0, 0.35), inset 0 0 0 1px rgba(255, 255, 255, 0.1);
    overflow: hidden;
    border: 1px solid var(--border-panel);
    transition: width 0.35s cubic-bezier(0.16, 1, 0.3, 1), height 0.35s cubic-bezier(0.16, 1, 0.3, 1), border-radius 0.35s cubic-bezier(0.16, 1, 0.3, 1), background var(--transition-normal), transform var(--transition-fast);
    color: var(--text-primary);
}

#vnpost-autofill-panel.panel-docked {
    position: fixed !important;
    top: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    left: auto !important;
    width: 340px !important;
    max-width: 92vw !important;
    height: 100vh !important;
    max-height: 100vh !important;
    border-radius: 0 !important;
    border-top: 0 !important;
    border-right: 0 !important;
    border-bottom: 0 !important;
    border-left: 1px solid var(--border-panel) !important;
    box-shadow: -10px 0 36px rgba(0, 0, 0, 0.28), inset 1px 0 0 rgba(255, 255, 255, 0.08) !important;
    transform: translateX(0);
    transition: transform 280ms cubic-bezier(0.4, 0, 0.2, 1), background var(--transition-normal), box-shadow var(--transition-normal);
    display: flex !important;
    flex-direction: column !important;
    z-index: 2147483647 !important;
}

#vnpost-autofill-panel.panel-docked #vnpost-panel-header {
    cursor: default;
    flex-shrink: 0;
}

#vnpost-autofill-panel.panel-docked #vnpost-panel-body {
    flex: 1;
    max-height: none;
    overflow-y: auto;
    padding-bottom: 24px;
}

#vnpost-autofill-panel.panel-docked.collapsed {
    transform: translateX(100%) !important;
    box-shadow: none !important;
}

#vnpost-autofill-panel.panel-floating {
    position: fixed !important;
    width: 360px !important;
    height: auto !important;
    max-height: 90vh !important;
    border-radius: 18px !important;
    border: 1px solid var(--border-panel) !important;
    box-shadow: 0 30px 70px rgba(0, 0, 0, 0.35), inset 0 0 0 1px rgba(255, 255, 255, 0.12) !important;
    transform: none !important;
    z-index: 2147483647 !important;
}

#vnpost-dock-toggle-tab {
    position: fixed !important;
    top: 50% !important;
    right: 0 !important;
    transform: translateY(-50%) !important;
    display: none;
    align-items: center;
    justify-content: center;
    min-height: 118px;
    padding: 12px 7px;
    border: 1px solid rgba(255, 255, 255, 0.28);
    border-right: 0;
    border-radius: 12px 0 0 12px;
    background: var(--theme-color, #0056b3);
    color: #ffffff;
    box-shadow: -6px 0 22px rgba(0, 0, 0, 0.2);
    cursor: pointer;
    font-family: 'Be Vietnam Pro', 'Noto Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 0;
    line-height: 1;
    text-orientation: mixed;
    transition: transform 150ms cubic-bezier(0.4, 0, 0.2, 1), filter 150ms ease;
    user-select: none;
    writing-mode: vertical-rl;
    z-index: 2147483646 !important;
}

#vnpost-dock-toggle-tab.is-visible {
    display: flex !important;
}

#vnpost-dock-toggle-tab:hover {
    filter: brightness(1.08);
    transform: translateY(-50%) scale(1.04) !important;
}

/* Minimized State */
#vnpost-autofill-panel.minimized {
    width: 52px;
    height: 52px;
    border-radius: 50%;
    cursor: pointer;
    background: rgba(15, 23, 42, 0.96);
    border: 2px solid var(--theme-color, #10b981);
    box-shadow: 0 16px 36px rgba(0, 0, 0, 0.35), 0 0 12px var(--theme-color, rgba(16, 185, 129, 0.3)), inset 0 0 0 1px rgba(255, 255, 255, 0.1);
    display: flex;
    align-items: center;
    justify-content: center;
}
#vnpost-autofill-panel.minimized #vnpost-panel-header,
#vnpost-autofill-panel.minimized #vnpost-panel-body {
    display: none !important;
}
.minimized-icon {
    display: none;
    color: var(--theme-color, #10b981);
}
#vnpost-autofill-panel.minimized .minimized-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    animation: pulseGlow 2.5s infinite;
}
#vnpost-autofill-panel.minimized .minimized-icon svg {
    width: 22px;
    height: 22px;
}
#vnpost-autofill-panel.minimized:hover {
    transform: scale(1.08);
    background: rgba(20, 22, 28, 0.98);
    border-color: var(--theme-color, #10b981);
    box-shadow: 0 20px 45px rgba(0, 0, 0, 0.45), 0 0 18px var(--theme-color, rgba(16, 185, 129, 0.5));
}
#vnpost-autofill-panel.minimized:active {
    transform: scale(0.96);
}

@keyframes pulseGlow {
    0% { transform: scale(1); opacity: 0.9; }
    50% { transform: scale(1.1); opacity: 1; filter: drop-shadow(0 0 6px var(--theme-color, #10b981)); }
    100% { transform: scale(1); opacity: 0.9; }
}

/* =========================================================================
   HEADER & CONTEXT BAR
   ========================================================================= */
#vnpost-panel-header {
    padding: 11px 14px 10px;
    background: rgba(15, 23, 42, 0.96);
    border-top: 3px solid var(--theme-color, #10b981);
    border-bottom: 1px solid var(--border-panel);
    display: flex;
    flex-direction: column;
    gap: 8px;
    cursor: move;
    user-select: none;
}

.vnpost-header-main {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
}

.panel-context-strip {
    display: grid;
    gap: 3px;
    width: 100%;
    padding: 7px 9px;
    border-top: 1px solid var(--border-panel);
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.04);
    position: relative;
}
.panel-context-shop,
.panel-account-trigger {
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 5px;
    color: var(--text-primary);
    font-size: 10px;
    font-weight: 700;
}
.panel-account-trigger {
    width: 100%;
    padding: 2px 0;
    border: 0;
    background: transparent;
    cursor: pointer;
    text-align: left;
}
.panel-account-trigger:hover { color: #10b981; }
.context-separator { color: var(--text-muted); }
.panel-account-menu {
    position: absolute;
    top: calc(100% + 5px);
    left: 0;
    right: 0;
    z-index: 80;
    display: grid;
    gap: 4px;
    padding: 10px;
    border: 1px solid var(--border-panel);
    border-radius: 10px;
    background: var(--bg-panel);
    box-shadow: var(--shadow-md);
    font-size: 11px;
}
.panel-account-menu[hidden] { display: none !important; }
.panel-account-menu span { color: var(--text-secondary); }
.panel-account-menu hr { width: 100%; margin: 4px 0; border: 0; border-top: 1px solid var(--border-panel); }
.panel-account-menu button { padding: 6px; border: 0; border-radius: 6px; background: transparent; color: var(--text-primary); text-align: left; cursor: pointer; }
.panel-account-menu button:hover { background: rgba(16, 185, 129, 0.12); }
.panel-context-row {
    display: grid;
    grid-template-columns: 74px minmax(0, 1fr);
    align-items: center;
    gap: 7px;
    min-width: 0;
    padding: 1px 0;
    font-size: 9.5px;
    line-height: 1.35;
}
.panel-context-label {
    color: var(--text-muted);
    font-weight: 600;
    white-space: nowrap;
}
.panel-context-value {
    min-width: 0;
    color: var(--text-primary);
    font-weight: 700;
    overflow-wrap: anywhere;
}
.panel-context-value.context-missing { color: #f59e0b; font-weight: 600; }
#vnpost-autofill-panel.light-mode .panel-context-value.context-missing { color: #b45309; }

.vnpost-brand-group {
    display: flex;
    align-items: center;
    gap: 7px;
}

.brand-live-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #10b981;
    box-shadow: 0 0 8px rgba(16, 185, 129, 0.7);
    display: inline-block;
    animation: livePulse 2s infinite ease-in-out;
}
@keyframes livePulse {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.6; transform: scale(0.85); }
}

.brand-title {
    font-family: 'Be Vietnam Pro', sans-serif;
    font-weight: 700;
    font-size: 16px;
    color: var(--text-primary);
    letter-spacing: -0.01em;
}

#vnpost-panel-header-text {
    font-family: 'Be Vietnam Pro', sans-serif;
    font-weight: 700;
    font-size: 16px;
    color: var(--text-primary);
    letter-spacing: -0.01em;
}

.badge-version {
    background: rgba(255, 255, 255, 0.08);
    color: var(--text-muted);
    padding: 1px 5px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 600;
    border: 1px solid var(--border-panel);
}

.vnpost-header-controls {
    display: flex;
    align-items: center;
    gap: 5px;
}

.status-strip-bar {
    display: flex;
    align-items: center;
    gap: 6px;
    width: 100%;
    overflow: hidden;
    padding-top: 1px;
}
.status-strip-bar::-webkit-scrollbar {
    display: none;
}

.status-pill {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 600;
    line-height: 1.2;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    cursor: default;
    flex: 1 1 0;
    min-width: 0;
    box-sizing: border-box;
    transition: all 0.15s;
}

.pill-shop {
    background: rgba(16, 185, 129, 0.14);
    color: #34d399;
    border: 1px solid rgba(16, 185, 129, 0.28);
}

.pill-carrier {
    background: rgba(56, 189, 248, 0.14);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.28);
}

.pill-user {
    background: rgba(99, 102, 241, 0.14);
    color: #a5b4fc;
    border: 1px solid rgba(99, 102, 241, 0.28);
}

#vnpost-autofill-panel.light-mode .pill-shop {
    background: #ecfdf5;
    color: #047857;
    border: 1px solid #a7f3d0;
}

#vnpost-autofill-panel.light-mode .pill-carrier {
    background: #f0f9ff;
    color: #0369a1;
    border: 1px solid #bae6fd;
}

#vnpost-autofill-panel.light-mode .pill-user {
    background: #eef2ff;
    color: #4338ca;
    border: 1px solid #c7d2fe;
}

/* Header Buttons */
#vnpost-btn-minimize, #vnpost-btn-settings, #vnpost-btn-theme, #vnpost-btn-dock-toggle {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.08);
    color: var(--text-secondary);
    cursor: pointer;
    width: 27px;
    height: 27px;
    border-radius: 7px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all var(--transition-fast);
    outline: none;
}
#vnpost-btn-minimize:hover, #vnpost-btn-settings:hover, #vnpost-btn-theme:hover, #vnpost-btn-dock-toggle:hover { 
    background: rgba(255, 255, 255, 0.12); 
    color: #ffffff;
    border-color: rgba(255, 255, 255, 0.2);
    transform: translateY(-1px);
}
#vnpost-btn-minimize:active, #vnpost-btn-settings:active, #vnpost-btn-theme:active, #vnpost-btn-dock-toggle:active {
    transform: scale(0.92);
}

/* =========================================================================
   PANEL BODY & INPUT CARD
   ========================================================================= */
#vnpost-panel-body {
    padding: 14px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    max-height: 80vh;
    overflow-y: auto;
}
#vnpost-panel-body::-webkit-scrollbar {
    width: 4px;
}
#vnpost-panel-body::-webkit-scrollbar-track {
    background: transparent;
}
#vnpost-panel-body::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.12);
    border-radius: 2px;
}

.input-card {
    background: var(--card-bg);
    border: 1px solid var(--card-border);
    border-radius: 12px;
    padding: 12px;
    display: flex;
    flex-direction: column;
    gap: 8px;
    box-shadow: var(--shadow-sm);
}

.input-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.source-card-header-actions {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 5px;
}
.source-edit-btn {
    border: 0;
    border-radius: 5px;
    padding: 2px 5px;
    background: rgba(56, 189, 248, 0.1);
    color: #38bdf8;
    font-size: 9.5px;
    font-weight: 700;
    cursor: pointer;
}
.source-edit-btn:hover, .source-edit-btn:focus-visible {
    background: rgba(56, 189, 248, 0.2);
    outline: 1px solid #38bdf8;
}
.source-dirty-badge {
    align-items: center;
    color: #f59e0b;
    font-size: 9px;
    font-weight: 700;
}
.source-dirty-message {
    margin: 6px 0;
    padding: 6px 8px;
    border: 1px solid rgba(245, 158, 11, 0.3);
    border-radius: 6px;
    background: rgba(245, 158, 11, 0.08);
    color: #fbbf24;
    font-size: 9.5px;
    line-height: 1.35;
}
.source-collapsed-preview {
    width: 100%;
    flex-direction: column;
    align-items: stretch;
    gap: 5px;
    padding: 9px 10px 7px;
    border: 1px solid var(--border-panel);
    border-radius: 8px;
    background: var(--input-bg);
    color: inherit;
    text-align: left;
    cursor: pointer;
}
.source-collapsed-preview:hover, .source-collapsed-preview:focus-visible {
    border-color: rgba(56, 189, 248, 0.45);
    background: rgba(56, 189, 248, 0.06);
    outline: none;
}
.source-preview-primary {
    color: var(--text-primary);
    font-size: 10px;
    font-weight: 800;
    line-height: 1.35;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: var(--text-secondary);
}
.source-preview-address {
    display: block;
    overflow: visible;
    color: var(--text-primary);
    font-size: 11px;
    font-weight: 500;
    line-height: 1.5;
    white-space: pre-wrap;
    word-break: break-word;
}
.source-preview-hint {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    margin-top: 2px;
    padding-top: 6px;
    border-top: 1px solid var(--border-panel);
    color: #38bdf8;
    font-size: 9.5px;
    font-weight: 750;
    letter-spacing: 0.01em;
}
.source-collapsed-preview:hover .source-preview-hint,
.source-collapsed-preview:focus-visible .source-preview-hint {
    color: #0ea5e9;
}
#vnpost-autofill-panel.light-mode .source-preview-hint {
    color: #0369a1;
}
.input-card.is-collapsed {
    gap: 5px;
    padding: 9px 10px;
}
.input-card.source-dirty {
    border-color: rgba(245, 158, 11, 0.45);
}
#vnpost-autofill-panel.light-mode .source-edit-btn { color: #0369a1; background: #e0f2fe; }
#vnpost-autofill-panel.light-mode .source-dirty-message { color: #92400e; background: #fffbeb; border-color: #fde68a; }

.input-card-title {
    font-size: 11px;
    font-weight: 700;
    color: var(--text-secondary);
    text-transform: uppercase;
    letter-spacing: 0.04em;
}

.input-kbd-shortcut {
    font-size: 10px;
    font-weight: 600;
    color: var(--text-muted);
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid var(--border-panel);
    padding: 1px 6px;
    border-radius: 4px;
}

#rawOrderText {
    width: 100%;
    box-sizing: border-box;
    padding: 10px 12px;
    border: 1px solid var(--input-border);
    border-radius: 9px;
    font-size: 13px;
    line-height: 1.5;
    resize: vertical;
    outline: none;
    background: var(--input-bg);
    color: var(--input-text);
    transition: all var(--transition-normal);
}
#rawOrderText::placeholder {
    color: var(--text-muted);
    opacity: 0.75;
}
#rawOrderText:focus {
    background-color: var(--input-focus-bg);
    border-color: #10b981;
    box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2);
}

.input-card-actions {
    display: flex;
    gap: 8px;
    margin-top: 2px;
}

.btn-parse-primary, #btnParseOrder {
    flex: 1;
    padding: 10px 14px;
    background: var(--btn-parse-bg);
    color: var(--btn-parse-text);
    border: 1px solid var(--btn-parse-border);
    border-radius: 9px;
    cursor: pointer;
    font-weight: 700;
    font-size: 13px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    box-shadow: var(--shadow-md);
    transition: all var(--transition-fast);
}
.btn-parse-primary:hover, #btnParseOrder:hover { 
    background: var(--btn-parse-bg-hover);
    border-color: var(--btn-parse-border-hover);
    box-shadow: var(--shadow-lg);
    transform: translateY(-1px);
}
.btn-parse-primary:active, #btnParseOrder:active {
    transform: translateY(0) scale(0.98);
}

.btn-clear-secondary, #btnClearOrder {
    min-width: 68px;
    padding: 10px 12px;
    background: var(--btn-clear-bg);
    color: var(--btn-clear-text);
    border: 1px solid var(--btn-clear-border);
    border-radius: 9px;
    cursor: pointer;
    font-weight: 600;
    font-size: 12.5px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    transition: all var(--transition-fast);
}
.btn-clear-secondary:hover, #btnClearOrder:hover {
    background: rgba(239, 68, 68, 0.15);
    border-color: rgba(239, 68, 68, 0.3);
    color: #f87171;
    transform: translateY(-1px);
}
.btn-clear-secondary:active, #btnClearOrder:active {
    transform: translateY(0) scale(0.98);
}

/* =========================================================================
   REVIEW BENTO PANEL
   ========================================================================= */
/* =========================================================================
   REVIEW BENTO PANEL (V2 DECISION-FIRST)
   ========================================================================= */
#review-panel {
    background: var(--card-bg);
    border: 1px solid var(--card-border);
    border-radius: 12px;
    padding: 11px;
    margin: 0;
    display: none;
    flex-direction: column;
    gap: 0;
}

.panel-empty-state {
    min-height: 92px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 5px;
    padding: 14px;
    border: 1px dashed var(--border-panel);
    border-radius: 10px;
    color: var(--text-muted);
    text-align: center;
    font-size: 11px;
}
.panel-empty-state[hidden], .panel-validation-error[hidden] { display: none !important; }
.panel-empty-state strong { color: var(--text-secondary); font-size: 12px; }
.panel-validation-error {
    display: grid;
    gap: 8px;
    padding: 12px;
    border: 1px solid rgba(245, 158, 11, 0.4);
    border-radius: 10px;
    background: rgba(245, 158, 11, 0.1);
    color: var(--text-primary);
    font-size: 11px;
}
#panel-validation-checklist { display: grid; grid-template-columns: 1fr 1fr; gap: 4px 8px; }
#panel-validation-checklist span { font-weight: 600; }
#panel-validation-checklist .is-valid { color: #10b981; }
#panel-validation-checklist .is-missing { color: #ef4444; }
#panel-validation-message { margin: 0; color: var(--text-secondary); }
#panel-fix-information { padding: 7px 10px; border: 1px solid rgba(245, 158, 11, 0.45); border-radius: 7px; background: transparent; color: #f59e0b; font-weight: 700; cursor: pointer; }
.review-editable.is-invalid { border-color: #ef4444 !important; background: rgba(239, 68, 68, 0.08); }

.panel-duplicate-alert {
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding: 10px 12px;
    border: 1px solid rgba(239, 68, 68, 0.45);
    border-radius: 10px;
    background: linear-gradient(135deg, rgba(239, 68, 68, 0.12) 0%, rgba(220, 38, 38, 0.06) 100%);
    color: var(--text-primary);
    font-size: 11px;
}
.duplicate-alert-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: 700;
}
.duplicate-alert-title {
    color: #f87171;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 11.5px;
}
.duplicate-alert-time {
    font-size: 10px;
    color: var(--text-muted);
    font-weight: 500;
}
.duplicate-alert-message {
    color: var(--text-primary);
    line-height: 1.4;
    font-size: 11px;
}
.duplicate-alert-details {
    display: flex;
    flex-wrap: wrap;
    gap: 4px 8px;
    margin-top: 2px;
    padding: 4px 8px;
    background: rgba(0, 0, 0, 0.2);
    border-radius: 6px;
    font-size: 10.5px;
}
.duplicate-detail-tag {
    display: inline-flex;
    align-items: center;
    gap: 3px;
    color: var(--text-secondary);
}
.duplicate-detail-tag strong {
    color: #fff;
}
.duplicate-detail-code {
    font-family: 'JetBrains Mono', monospace;
    color: #38bdf8;
    background: rgba(56, 189, 248, 0.15);
    padding: 1px 4px;
    border-radius: 4px;
}

.review-header-v2 {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 1px 9px;
    border-bottom: 1px solid var(--border-panel);
}

.review-section-title {
    font-family: 'Be Vietnam Pro', sans-serif;
    font-weight: 700;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--text-secondary);
}

.review-edit-badge {
    font-size: 10px;
    font-weight: 500;
    color: var(--text-muted);
}

.bento-grid-v2 { 
    display: grid; 
    grid-template-columns: repeat(2, 1fr); 
    gap: 0; 
    font-size: 13px; 
}

.bento-cell { 
    display: flex; 
    flex-direction: column;
    gap: 3px;
    background: transparent;
    border: 0;
    border-bottom: 1px solid var(--border-panel);
    padding: 9px 7px;
    border-radius: 0;
    transition: all var(--transition-fast) ease;
}
.bento-cell:hover {
    background: rgba(56, 189, 248, 0.05);
}
.bento-cell:nth-child(odd) { border-right: 1px solid var(--border-panel); }

.bento-label-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.bento-label { 
    font-size: 10px;
    color: var(--text-secondary); 
    font-weight: 700; 
    text-transform: uppercase;
    letter-spacing: 0.03em;
    display: flex;
    align-items: center;
    gap: 4px;
}
.bento-label svg {
    color: var(--text-muted);
}

.bento-val { 
    font-weight: 600; 
    color: var(--text-primary); 
    word-break: break-word;
}

.fee-status { 
    text-transform: uppercase; 
    font-weight: 700; 
    font-size: 12px;
}
.fee-status--yes { 
    color: #10b981; 
}
.fee-status--no { 
    color: var(--text-muted); 
}

/* COD PRIMARY FINANCIAL CARD */
.cod-primary-card {
    background: rgba(16, 185, 129, 0.08);
    border: 0;
    border-bottom: 1px solid rgba(16, 185, 129, 0.24);
    border-radius: 0;
    padding: 10px 7px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: none;
}
#vnpost-autofill-panel.light-mode .cod-primary-card {
    background: #f0fdf4;
    border: 0;
    border-bottom: 1px solid #bbf7d0;
    box-shadow: none;
}

.cod-card-left {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.cod-card-label {
    font-size: 10.5px;
    font-weight: 700;
    color: #34d399;
    text-transform: uppercase;
    letter-spacing: 0.04em;
}
#vnpost-autofill-panel.light-mode .cod-card-label {
    color: #047857;
}

.cod-status-badge {
    font-size: 10px;
    font-weight: 600;
    color: #10b981;
    display: inline-flex;
    align-items: center;
    gap: 3px;
}
#vnpost-autofill-panel.light-mode .cod-status-badge {
    color: #059669;
}

.cod-primary-val, #rev-cod {
    font-family: 'Be Vietnam Pro', 'Segoe UI', sans-serif;
    font-size: 18px;
    font-weight: 800;
    color: #f87171;
    letter-spacing: -0.02em;
}
#vnpost-autofill-panel.light-mode .cod-primary-val, #vnpost-autofill-panel.light-mode #rev-cod {
    color: #dc2626;
}

.customer-history-card {
    display: grid;
    gap: 8px;
    padding: 10px;
    border: 1px solid var(--border-panel);
    border-radius: 10px;
    background: var(--card-bg);
}
.customer-history-card[hidden] { display: none !important; }
.customer-history-heading { display: flex; justify-content: space-between; gap: 8px; font-size: 11px; }
.customer-history-count-badge {
    min-width: 18px;
    height: 18px;
    padding: 0 5px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 999px;
    background: #10b981;
    color: #fff;
    font-size: 9px;
    font-weight: 800;
}
.customer-history-count-badge[hidden] { display: none !important; }
.customer-history-search-row { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 6px; }
#customer-history-search { min-width: 0; padding: 7px 9px; border: 1px solid var(--border-panel); border-radius: 7px; background: transparent; color: var(--text-primary); font-size: 11px; }
#customer-history-search-btn { padding: 7px 10px; border: 0; border-radius: 7px; background: #0f766e; color: white; font-weight: 700; cursor: pointer; }
.customer-history-result { display: grid; gap: 4px; color: var(--text-secondary); font-size: 10px; line-height: 1.45; }
.customer-history-result strong { color: var(--text-primary); }
.customer-history-orders { display: grid; gap: 6px; }
.customer-history-order {
    display: grid;
    gap: 2px;
    padding: 6px 7px;
    border-left: 2px solid #10b981;
    border-radius: 0 6px 6px 0;
    background: rgba(16, 185, 129, 0.07);
}
.customer-history-order-code { color: var(--text-primary); font-size: 10px; font-weight: 800; }
.customer-history-order-address { color: var(--text-muted); font-size: 9.5px; line-height: 1.35; }
.customer-history-summary { padding: 6px 8px; border-radius: 6px; background: rgba(16,185,129,.08); color: #047857; font-size: 10px; font-weight: 700; }
.customer-history-summary.risk-warning { background: #fffbeb; color: #b45309; }
.customer-history-summary.risk-blacklist { background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca; }
.customer-history-addresses { display: grid; gap: 5px; padding-top: 5px; border-top: 1px solid var(--border-panel); }
.customer-history-address-title { color: var(--text-muted); font-size: 9px; font-weight: 700; text-transform: uppercase; }
.customer-history-address-option { width: 100%; padding: 6px 7px; border: 1px solid var(--border-panel); border-radius: 6px; background: transparent; color: var(--text-primary); text-align: left; font-size: 9.5px; line-height: 1.35; cursor: pointer; }
.customer-history-address-option:hover { border-color: #10b981; background: rgba(16,185,129,.08); }

/* ADDRESS ENGINE CARD */
.address-engine-card {
    background: transparent;
    border: 0;
    border-radius: 0;
    padding: 11px 0 0;
    display: flex;
    flex-direction: column;
    gap: 8px;
    box-shadow: none;
}

.address-engine-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.address-title-group {
    display: flex;
    align-items: center;
    gap: 6px;
}

.address-engine-title {
    font-size: 10.5px;
    font-weight: 700;
    color: var(--text-secondary);
    text-transform: uppercase;
    letter-spacing: 0.04em;
}

.address-verified-badge {
    font-size: 9.5px;
    font-weight: 700;
    padding: 1.5px 6px;
    border-radius: 4px;
    background: rgba(16, 185, 129, 0.18);
    color: #34d399;
    border: 1px solid rgba(16, 185, 129, 0.3);
}
#vnpost-autofill-panel.light-mode .address-verified-badge {
    background: #ecfdf5;
    color: #047857;
    border-color: #a7f3d0;
}

.address-main-box {
    background: var(--input-bg);
    border: 1px solid var(--input-border);
    border-radius: 8px;
    padding: 8px 10px;
    transition: all var(--transition-fast) ease;
}
.address-main-box:hover {
    border-color: rgba(56, 189, 248, 0.35);
}

.address-text-main, #rev-address {
    font-size: 13px;
    font-weight: 600;
    color: var(--text-primary);
    line-height: 1.45;
    word-break: break-word;
    display: block;
}

.address-reference-box {
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding: 8px;
    border-radius: 8px;
    background: #f0f9ff;
    border: 1px solid #bae6fd;
    margin-top: 6px;
}
.address-reference-disclosure {
    border-top: 1px solid var(--border-panel);
    padding-top: 8px;
    margin-top: 6px;
}
.address-reference-disclosure > summary {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    list-style: none;
    user-select: none;
}
.address-reference-disclosure > summary::-webkit-details-marker { display: none; }
.address-reference-disclosure > summary::after {
    content: '▾';
    color: var(--text-muted);
    font-size: 14px;
    font-weight: 700;
    transition: transform var(--transition-fast);
}
.address-reference-disclosure:not([open]) > summary::after {
    content: '›';
    font-size: 16px;
}
.address-reference-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
}
.address-reference-title {
    color: #475569;
    font-size: 11.5px;
    font-weight: 700;
}
.address-reference-status {
    color: #047857;
    font-size: 11px;
    font-weight: 600;
    white-space: nowrap;
    margin-left: auto;
    margin-right: 4px;
}
.address-reference-status.is-loading { color: #f59e0b; }
.address-reference-status.is-ready { color: #047857; }
.address-reference-status.is-warning { color: #fb923c; }
.address-reference-option {
    width: 100%;
    display: grid;
    grid-template-columns: 95px minmax(0, 1fr);
    align-items: start;
    gap: 8px;
    padding: 8px 10px;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    background: #ffffff;
    color: inherit;
    text-align: left;
    cursor: pointer;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03);
    transition: border-color var(--transition-fast) ease, background var(--transition-fast) ease, box-shadow var(--transition-fast) ease;
}
.address-reference-option:hover {
    border-color: #38bdf8;
    background: #f8fafc;
    box-shadow: 0 2px 4px rgba(56, 189, 248, 0.12);
}
.address-reference-label {
    color: #334155;
    font-size: 11px;
    font-weight: 700;
    white-space: nowrap;
}
.address-reference-value {
    color: #0f172a;
    font-size: 11.5px;
    font-weight: 600;
    line-height: 1.4;
    word-break: break-word;
}
.address-reference-help {
    color: #94a3b8;
    font-size: 10.5px;
    line-height: 1.3;
    padding: 2px 2px 0 2px;
}
#vnpost-autofill-panel.light-mode .address-reference-title {
    color: #475569;
}
#vnpost-autofill-panel.light-mode .address-reference-box {
    background: #f0f9ff;
    border-color: #bae6fd;
}
#vnpost-autofill-panel.light-mode .address-reference-option {
    background: #ffffff;
    border-color: #e2e8f0;
}
#vnpost-autofill-panel.light-mode .address-reference-status.is-ready { color: #047857; }

.address-format-bar {
    display: none;
    align-items: center;
    gap: 6px;
    padding-top: 2px;
}

.format-bar-label {
    font-size: 10px;
    color: var(--text-muted);
    font-weight: 600;
}

.format-pill-btn {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: var(--text-secondary);
    font-size: 10.5px;
    font-weight: 600;
    padding: 3px 8px;
    border-radius: 6px;
    cursor: pointer;
    transition: all var(--transition-fast) ease;
}
.format-pill-btn:hover {
    background: rgba(255, 255, 255, 0.12);
    color: #ffffff;
    transform: translateY(-1px);
}
.format-pill-btn.active {
    background: rgba(56, 189, 248, 0.18);
    border-color: #38bdf8;
    color: #38bdf8;
}
#vnpost-autofill-panel.light-mode .format-pill-btn.active {
    background: #e0f2fe;
    border-color: #0284c7;
    color: #0284c7;
}

/* Collapsible technical accordion */
.address-accordion {
    border-top: 1px dashed var(--border-panel);
    padding-top: 6px;
    margin-top: 2px;
}

.accordion-toggle-btn {
    background: transparent;
    border: none;
    padding: 2px 0;
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 10.5px;
    font-weight: 600;
    color: var(--text-muted);
    cursor: pointer;
    transition: color 0.15s;
}
.accordion-toggle-btn:hover {
    color: var(--text-secondary);
}

.accordion-arrow {
    transition: transform 0.2s ease;
    font-size: 11px;
}
.accordion-toggle-btn.open .accordion-arrow {
    transform: rotate(180deg);
}

.accordion-content {
    padding: 6px 0 2px 0;
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.accordion-detail-row {
    display: flex;
    gap: 6px;
    font-size: 11px;
    line-height: 1.4;
}
.acc-label {
    color: var(--text-muted);
    flex-shrink: 0;
}
.acc-val {
    color: var(--text-secondary);
    word-break: break-word;
}

.accordion-detail-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4px;
    background: var(--input-bg);
    border: 1px solid var(--border-panel);
    border-radius: 6px;
    padding: 6px 8px;
    font-size: 11px;
}
.acc-grid-item {
    display: flex;
    flex-direction: column;
    gap: 1px;
}
.acc-grid-item.acc-full {
    grid-column: span 2;
}
.acc-sublabel {
    font-size: 9.5px;
    color: var(--text-muted);
    text-transform: uppercase;
}
.acc-subval {
    font-weight: 600;
    color: var(--text-secondary);
}

#ai-merger-notice {
    background: rgba(245, 158, 11, 0.15);
    border: 1px solid rgba(245, 158, 11, 0.4);
    border-left: 3px solid #f59e0b;
    color: #fde047;
    padding: 7px 10px;
    border-radius: 6px;
    font-size: 11.5px;
    margin-bottom: 6px;
    line-height: 1.45;
    font-weight: 500;
}
#vnpost-autofill-panel.light-mode #ai-merger-notice {
    background: #fffbeb;
    border: 1px solid #fde68a;
    border-left: 3px solid #d97706;
    color: #92400e;
    font-weight: 600;
}

.copy-btn {
    background: transparent;
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 6px;
    padding: 3px 6px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: var(--text-secondary);
    flex-shrink: 0;
    transition: all var(--transition-fast) ease;
}
.copy-btn.mini-copy {
    padding: 1px 4px;
    border-radius: 4px;
}
.copy-btn:hover {
    background: rgba(255,255,255,0.1);
    color: #ffffff;
    border-color: rgba(255,255,255,0.3);
    transform: scale(1.05);
}
.copy-btn:active {
    transform: scale(0.92);
}

/* =========================================================================
   STICKY ACTION FOOTER & READINESS STATUS
   ========================================================================= */
.panel-sticky-footer {
    position: sticky;
    bottom: 0;
    background: var(--bg-panel);
    border-top: 1px solid var(--border-panel);
    padding: 10px 14px 12px 14px;
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    z-index: 20;
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.order-readiness-bar {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 5px 10px;
    border-radius: 7px;
    font-size: 11.5px;
    font-weight: 700;
    letter-spacing: 0.02em;
    transition: all 0.2s ease;
}
.readiness-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    flex-shrink: 0;
}

.order-readiness-bar.readiness-ready {
    background: rgba(16, 185, 129, 0.15);
    border: 1px solid rgba(16, 185, 129, 0.35);
    color: #34d399;
}
.order-readiness-bar.readiness-ready .readiness-dot {
    background: #10b981;
    box-shadow: 0 0 8px #10b981;
}
#vnpost-autofill-panel.light-mode .order-readiness-bar.readiness-ready {
    background: #ecfdf5;
    border-color: #a7f3d0;
    color: #047857;
}

.order-readiness-bar.readiness-warn {
    background: rgba(245, 158, 11, 0.15);
    border: 1px solid rgba(245, 158, 11, 0.35);
    color: #fbbf24;
}
.order-readiness-bar.readiness-warn .readiness-dot {
    background: #f59e0b;
    box-shadow: 0 0 8px #f59e0b;
}
#vnpost-autofill-panel.light-mode .order-readiness-bar.readiness-warn {
    background: #fffbeb;
    border-color: #fde68a;
    color: #b45309;
}

.order-readiness-bar.readiness-error {
    background: rgba(239, 68, 68, 0.15);
    border: 1px solid rgba(239, 68, 68, 0.35);
    color: #f87171;
}
.order-readiness-bar.readiness-error .readiness-dot {
    background: #ef4444;
    box-shadow: 0 0 8px #ef4444;
}
#vnpost-autofill-panel.light-mode .order-readiness-bar.readiness-error {
    background: #fef2f2;
    border-color: #fecaca;
    color: #b91c1c;
}

.order-readiness-bar.readiness-idle {
    background: rgba(255, 255, 255, 0.04);
    border: 1px solid rgba(255, 255, 255, 0.08);
    color: var(--text-muted);
}
.order-readiness-bar.readiness-idle .readiness-dot {
    background: var(--text-muted);
}
#vnpost-autofill-panel.light-mode .order-readiness-bar.readiness-idle {
    background: #f1f5f9;
    border-color: #e2e8f0;
    color: #64748b;
}

.panel-bottom-actions {
    display: flex;
    gap: 8px;
    width: 100%;
}

.btn-fill {
    flex: 1;
    padding: 10px 14px;
    color: white;
    border: none;
    border-radius: 9px;
    cursor: pointer;
    font-weight: 700;
    font-size: 13px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    box-shadow: var(--shadow-sm);
    transition: all var(--transition-fast);
}
.btn-fill:hover { 
    transform: translateY(-1px); 
    box-shadow: var(--shadow-md);
}
.btn-fill:active {
    transform: translateY(0) scale(0.98);
}
.btn-fill:disabled, #btnParseOrder:disabled { 
    opacity: 0.38;
    filter: grayscale(0.75);
    cursor: not-allowed; 
    transform: none; 
    box-shadow: none; 
}

.btn-fill-vnpost {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
}
.btn-fill-vnpost:hover {
    background: linear-gradient(135deg, #059669 0%, #047857 100%);
}

.btn-fill-jt {
    background: linear-gradient(135deg, #f43f5e 0%, #e11d48 100%);
}
.btn-fill-jt:hover {
    background: linear-gradient(135deg, #e11d48 0%, #be123c 100%);
}

.btn-save-order {
    background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
}
.btn-save-order:hover {
    background: linear-gradient(135deg, #4f46e5 0%, #4338ca 100%);
}

.review-editable {
    cursor: text;
    outline: none;
    border-radius: 5px;
    padding: 2px 5px;
    margin: -2px -5px;
    border: 1px dashed transparent;
    transition: all var(--transition-fast) ease;
    display: inline-block;
}
.review-editable:hover { 
    background: rgba(255, 255, 255, 0.06);
    border-color: rgba(255, 255, 255, 0.15);
}
.review-editable:focus { 
    background: rgba(255, 255, 255, 0.12); 
    border-color: #10b981;
    border-style: solid;
    box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.25);
}

/* Progress bar */
#gemini-progress-container {
    display: none;
    width: 100%;
    padding: 2px 0 0;
}
.ai-progress-header {
    display: flex;
    justify-content: space-between;
    font-size: 11px;
    margin-bottom: 6px;
}
#ai-status { font-weight: 500; color: var(--text-secondary); }
#ai-percent { font-weight: 700; color: #10b981; }
.progress-bar-bg {
    width: 100%;
    background-color: var(--progress-bg);
    height: 3px;
    border-radius: 6px;
    overflow: hidden;
}
#gemini-progress-bar {
    width: 0%;
    height: 100%;
    background-color: #10b981;
    transition: width 0.35s ease;
}
.parse-progress-steps {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4px 8px;
    margin-top: 9px;
    color: var(--text-secondary);
    font-size: 9.5px;
}
.parse-progress-steps span:last-child { color: #10b981; font-weight: 700; }
.parse-progress-steps .is-complete { color: #10b981; }
.parse-progress-steps .is-missing { color: #ef4444; }
.parse-progress-steps .is-active { color: #10b981; font-weight: 700; }

/* Header decision-first: carrier title + account context; secondary tools live outside the primary hierarchy. */
#vnpost-api-status { display: none !important; }

/* Toast styling */
#vnpost-toast-container {
    position: fixed;
    top: 24px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 10000000;
    display: flex;
    flex-direction: column;
    gap: 8px;
    align-items: center;
    pointer-events: none;
}
.vnpost-toast {
    font-family: 'Be Vietnam Pro', 'Noto Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: rgba(15, 23, 42, 0.95);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    color: #fff;
    padding: 9px 18px;
    border-radius: 10px;
    font-size: 13px;
    font-weight: 500;
    min-width: 250px;
    text-align: center;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.35), inset 0 0 0 1px rgba(255, 255, 255, 0.1);
    opacity: 0;
    border-left: 4px solid var(--theme-color, #10b981);
    transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}
.vnpost-toast.show {
    opacity: 1;
    animation: vnpostSlideDownPop 0.35s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
}
.vnpost-toast--success {
    border-left-color: #10b981;
}
.vnpost-toast--error {
    border-left-color: #ef4444;
}

@keyframes vnpostSlideDownPop {
  0% { opacity: 0; transform: translateY(-20px) scale(0.96); }
  100% { opacity: 1; transform: translateY(0) scale(1); }
}
@keyframes vnpostShakeError {
  0% { opacity: 0; transform: translateY(-20px) scale(0.96); }
  35% { opacity: 1; transform: translateY(0) scale(1.02); }
  50% { transform: translateX(-5px) scale(1); }
  65% { transform: translateX(5px); }
  80% { transform: translateX(-3px); }
  90% { transform: translateX(3px); }
  100% { transform: translateX(0); }
}

/* Spinner Rotate Animation for SVG loading */
.spinner-loading {
    animation: spinRotate 1.2s linear infinite;
    transform-origin: center;
}
@keyframes spinRotate {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* Skeleton Screen Loading Animation */
.skeleton {
    display: inline-block;
    height: 14px;
    border-radius: 4px;
    background: linear-gradient(90deg, rgba(255, 255, 255, 0.08) 25%, rgba(255, 255, 255, 0.22) 37%, rgba(255, 255, 255, 0.08) 63%);
    background-size: 400% 100%;
    animation: skeletonShimmer 1.4s ease-in-out infinite;
    vertical-align: middle;
    pointer-events: none;
    user-select: none;
    color: transparent !important;
}
#vnpost-autofill-panel.light-mode .skeleton {
    background: linear-gradient(90deg, rgba(0, 0, 0, 0.06) 25%, rgba(0, 0, 0, 0.16) 37%, rgba(0, 0, 0, 0.06) 63%);
    background-size: 400% 100%;
}
@keyframes skeletonShimmer {
    0% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

/* =========================================================================
   LIGHT MODE STYLES (CRISP, CLEAN & MODERN)
   ========================================================================= */
#vnpost-autofill-panel.light-mode {
    --bg-panel: rgba(255, 255, 255, 0.98);
    --border-panel: #e2e8f0;
    --text-primary: #0f172a;
    --text-secondary: #475569;
    --text-muted: #94a3b8;
    
    --btn-parse-bg: linear-gradient(135deg, #10b981 0%, #059669 100%);
    --btn-parse-bg-hover: linear-gradient(135deg, #059669 0%, #047857 100%);
    --btn-parse-border: rgba(16, 185, 129, 0.3);
    --btn-parse-border-hover: rgba(5, 150, 105, 0.5);
    --btn-parse-text: #ffffff;
    
    --btn-clear-bg: #f8fafc;
    --btn-clear-border: #e2e8f0;
    --btn-clear-text: #64748b;
    
    --card-bg: #f8fafc;
    --card-border: #e2e8f0;
    --card-row-bg: #ffffff;
    --card-row-border: #e2e8f0;
    --card-row-hover-bg: #ffffff;
    --card-row-hover-border: #10b981;
    
    --input-bg: #ffffff;
    --input-border: #cbd5e1;
    --input-text: #0f172a;
    --input-focus-bg: #ffffff;
    
    --cod-bg: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
    --cod-border: #a7f3d0;
    --cod-text: #065f46;
    --cod-val: #047857;
    
    --ai-box-bg: #eff6ff;
    --ai-box-border: #bfdbfe;
    --ai-box-text: #1e40af;
    --ai-box-title: #1d4ed8;
    --ai-box-accent: #3b82f6;
    --ai-item-bg: #ffffff;
    --ai-item-border: #bfdbfe;
    --ai-item-hover-bg: #f0fdf4;
    
    --progress-bg: #e2e8f0;
    
    box-shadow: 0 20px 45px -8px rgba(0, 0, 0, 0.15), 0 0 1px 1px rgba(0, 0, 0, 0.06);
}

#vnpost-autofill-panel.light-mode #vnpost-panel-header {
    background: #f8fafc;
    border-bottom: 1px solid #e2e8f0;
}
#vnpost-autofill-panel.light-mode .panel-context-strip {
    background: #ffffff;
    border-color: #e2e8f0;
}
#vnpost-autofill-panel.light-mode #vnpost-panel-header-text,
#vnpost-autofill-panel.light-mode .brand-title {
    color: #0f172a;
}
#vnpost-autofill-panel.light-mode .badge-version {
    background: #f1f5f9;
    color: #64748b;
    border-color: #e2e8f0;
}
#vnpost-autofill-panel.light-mode .pill-shop {
    background: #ecfdf5;
    color: #047857;
    border-color: #a7f3d0;
}
#vnpost-autofill-panel.light-mode .pill-carrier {
    background: #f0f9ff;
    color: #0369a1;
    border-color: #bae6fd;
}
#vnpost-autofill-panel.light-mode .pill-user {
    background: #eef2ff;
    color: #4338ca;
    border-color: #c7d2fe;
}
#vnpost-autofill-panel.light-mode #vnpost-btn-minimize,
#vnpost-autofill-panel.light-mode #vnpost-btn-settings,
#vnpost-autofill-panel.light-mode #vnpost-btn-theme,
#vnpost-autofill-panel.light-mode #vnpost-btn-dock-toggle {
    background: #f8fafc;
    border-color: #e2e8f0;
    color: #64748b;
}
#vnpost-autofill-panel.light-mode #vnpost-btn-minimize:hover,
#vnpost-autofill-panel.light-mode #vnpost-btn-settings:hover,
#vnpost-autofill-panel.light-mode #vnpost-btn-theme:hover,
#vnpost-autofill-panel.light-mode #vnpost-btn-dock-toggle:hover {
    background: #f1f5f9;
    color: #0f172a;
    border-color: #cbd5e1;
}
#vnpost-autofill-panel.light-mode #rawOrderText {
    background: #ffffff;
    border-color: #cbd5e1;
    color: #0f172a;
}
#vnpost-autofill-panel.light-mode #rawOrderText:focus {
    background: #ffffff;
    border-color: #10b981;
    box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.18);
}
#vnpost-autofill-panel.light-mode .review-editable:hover {
    background: #f1f5f9;
    border-color: #cbd5e1;
}
#vnpost-autofill-panel.light-mode .review-editable:focus {
    background: #ffffff;
    border-color: #10b981;
    box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.2);
}
#vnpost-autofill-panel.light-mode.minimized {
    background: #ffffff;
    box-shadow: 0 16px 36px rgba(0, 0, 0, 0.12), 0 0 12px rgba(16, 185, 129, 0.25);
    border-color: #10b981;
}
#vnpost-autofill-panel.light-mode .copy-btn {
    border-color: #cbd5e1;
    color: #64748b;
}
#vnpost-autofill-panel.light-mode .copy-btn:hover {
    background: #f1f5f9;
    color: #0f172a;
    border-color: #94a3b8;
}
#vnpost-autofill-panel.theme-light,
#vnpost-autofill-panel.light-mode ~ #vnpost-toast-container .vnpost-toast {
    background: #ffffff;
    color: #0f172a;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12), inset 0 0 0 1px rgba(0, 0, 0, 0.05);
}

/* Mini Floating Dock Widget (Phase 4) */
#vnpost-mini-dock {
    position: fixed;
    right: 16px;
    bottom: 80px;
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    box-shadow: 0 4px 15px rgba(16, 185, 129, 0.45), 0 2px 6px rgba(0,0,0,0.2);
    display: none;
    align-items: center;
    justify-content: center;
    cursor: grab;
    z-index: 2147483646;
    transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.2s;
    user-select: none;
}
#vnpost-mini-dock.is-visible {
    display: flex !important;
    animation: vnpostFadeIn 0.2s ease-out;
}
#vnpost-mini-dock:hover {
    transform: scale(1.08);
    box-shadow: 0 6px 22px rgba(16, 185, 129, 0.6);
}
#vnpost-mini-dock:active {
    cursor: grabbing;
}
.mini-dock-badge {
    position: absolute;
    top: -2px;
    right: -2px;
    min-width: 18px;
    height: 18px;
    border-radius: 9px;
    background: #ef4444;
    color: #ffffff;
    font-size: 10px;
    font-weight: 800;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 4px;
    border: 2px solid #ffffff;
    box-shadow: 0 1px 3px rgba(0,0,0,0.25);
}

/* DRAFT QUEUE NAVIGATOR (Tách đơn trên web nạp ra panel) */
.draft-queue-container {
    margin: 0 var(--space-md) var(--space-sm) var(--space-md);
    padding: 8px 10px;
    border-radius: 10px;
    background: rgba(30, 41, 59, 0.75);
    border: 1px solid rgba(56, 189, 248, 0.3);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    display: flex;
    flex-direction: column;
    gap: 6px;
    animation: vnpostFadeIn 0.2s ease-out;
    transition: all 0.2s ease;
}
#vnpost-autofill-panel.theme-light .draft-queue-container,
#vnpost-autofill-panel.light-mode .draft-queue-container {
    background: #f0f9ff;
    border-color: #bae6fd;
}
.draft-queue-container.is-collapsed {
    padding: 6px 10px;
    gap: 0;
}
.draft-queue-container.is-collapsed .draft-queue-body {
    display: none !important;
}
.draft-queue-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.draft-queue-title-group {
    display: flex;
    align-items: center;
    gap: 6px;
    min-width: 0;
    flex: 1;
}
.draft-queue-icon {
    font-size: 13px;
    flex-shrink: 0;
}
.draft-queue-title {
    font-size: 11px;
    font-weight: 700;
    color: #38bdf8;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    flex-shrink: 0;
}
#vnpost-autofill-panel.theme-light .draft-queue-title,
#vnpost-autofill-panel.light-mode .draft-queue-title {
    color: #0284c7;
}
.draft-queue-badge {
    background: #0284c7;
    color: #ffffff;
    font-size: 10px;
    font-weight: 700;
    padding: 1px 6px;
    border-radius: 10px;
    flex-shrink: 0;
}
.draft-queue-mini-summary {
    font-size: 11px;
    font-weight: 600;
    color: var(--text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-left: 4px;
    max-width: 145px;
}
#vnpost-autofill-panel.theme-light .draft-queue-mini-summary,
#vnpost-autofill-panel.light-mode .draft-queue-mini-summary {
    color: #475569;
}
.draft-queue-header-actions {
    display: flex;
    align-items: center;
    gap: 4px;
    flex-shrink: 0;
}
.draft-queue-btn-collapse {
    background: transparent;
    border: none;
    color: var(--text-muted);
    cursor: pointer;
    font-size: 11px;
    padding: 2px 5px;
    border-radius: 4px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    transition: all 0.15s ease;
}
.draft-queue-btn-collapse:hover {
    color: #38bdf8;
    background: rgba(56, 189, 248, 0.15);
}
.draft-queue-close {
    background: transparent;
    border: none;
    color: var(--text-muted);
    cursor: pointer;
    font-size: 12px;
    padding: 1px 4px;
    border-radius: 4px;
}
.draft-queue-close:hover {
    color: #ef4444;
    background: rgba(239, 68, 68, 0.1);
}
.draft-queue-body {
    display: flex;
    flex-direction: column;
    gap: 6px;
}
.draft-queue-nav {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
    background: rgba(15, 23, 42, 0.6);
    border-radius: 8px;
    padding: 4px 6px;
}
#vnpost-autofill-panel.theme-light .draft-queue-nav,
#vnpost-autofill-panel.light-mode .draft-queue-nav {
    background: #ffffff;
    border: 1px solid #e2e8f0;
}
.draft-nav-btn {
    width: 24px;
    height: 24px;
    border-radius: 6px;
    border: 1px solid rgba(255, 255, 255, 0.15);
    background: rgba(255, 255, 255, 0.08);
    color: var(--text-primary);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    font-size: 10px;
    transition: all 0.15s;
}
.draft-nav-btn:hover:not(:disabled) {
    background: rgba(56, 189, 248, 0.3);
    border-color: #38bdf8;
}
.draft-nav-btn:disabled {
    opacity: 0.3;
    cursor: not-allowed;
}
.draft-current-info {
    flex: 1;
    text-align: center;
    overflow: hidden;
    padding: 0 4px;
}
.draft-index-text {
    font-size: 9px;
    font-weight: 700;
    color: #94a3b8;
}
.draft-summary-text {
    font-size: 11px;
    font-weight: 600;
    color: var(--text-primary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.draft-queue-actions,
.draft-queue-actions-container {
    display: flex;
    flex-direction: column;
    gap: 6px;
}
.draft-queue-primary-row {
    display: flex;
    gap: 8px;
}
.btn-draft-action-primary, 
.btn-draft-action-success {
    flex: 1;
    min-height: 33px;
    padding: 6px 10px;
    border-radius: 7px;
    font-size: 11.5px;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
    border: none;
    white-space: nowrap;
    transition: all 0.15s ease-in-out;
}
.btn-draft-action-primary {
    background: #0284c7;
    color: #ffffff;
    box-shadow: 0 1px 3px rgba(2, 132, 199, 0.25);
}
.btn-draft-action-primary:hover {
    background: #0369a1;
    transform: translateY(-1px);
}
.btn-draft-action-success {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    color: #ffffff;
    box-shadow: 0 1px 3px rgba(16, 185, 129, 0.25);
}
.btn-draft-action-success:hover {
    background: linear-gradient(135deg, #059669 0%, #047857 100%);
    transform: translateY(-1px);
}

.draft-queue-secondary-row {
    display: flex;
    gap: 8px;
    align-items: center;
}
.btn-draft-action-danger,
.btn-draft-action-ghost-danger,
.btn-draft-action-warning,
.btn-draft-action-ghost-warning {
    flex: 1;
    min-height: 26px;
    padding: 4px 8px;
    border-radius: 6px;
    font-size: 10.5px;
    font-weight: 500;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    white-space: nowrap;
    transition: all 0.15s ease-in-out;
}
.btn-draft-action-ghost-danger,
.btn-draft-action-danger {
    border: 1px solid rgba(239, 68, 68, 0.3);
    background: rgba(239, 68, 68, 0.08);
    color: #ef4444;
}
.btn-draft-action-ghost-danger:hover,
.btn-draft-action-danger:hover {
    background: rgba(239, 68, 68, 0.2);
    border-color: #ef4444;
}
.btn-draft-action-ghost-warning,
.btn-draft-action-warning {
    border: 1px solid rgba(245, 158, 11, 0.3);
    background: rgba(245, 158, 11, 0.08);
    color: #f59e0b;
}
.btn-draft-action-ghost-warning:hover,
.btn-draft-action-warning:hover {
    background: rgba(245, 158, 11, 0.2);
    border-color: #f59e0b;
}

#vnpost-autofill-panel.theme-light .btn-draft-action-ghost-danger,
#vnpost-autofill-panel.light-mode .btn-draft-action-ghost-danger {
    background: #fef2f2;
    border-color: #fecaca;
    color: #dc2626;
}
#vnpost-autofill-panel.theme-light .btn-draft-action-ghost-warning,
#vnpost-autofill-panel.light-mode .btn-draft-action-ghost-warning {
    background: #fffbeb;
    border-color: #fde68a;
    color: #d97706;
}

/* Badge trên Header nút Toggle */
.header-draft-badge {
    position: absolute;
    top: -3px;
    right: -3px;
    background: #ef4444;
    color: #fff;
    font-size: 8.5px;
    font-weight: 700;
    line-height: 1;
    padding: 1px 4px;
    border-radius: 8px;
    border: 1px solid rgba(255, 255, 255, 0.6);
    min-width: 12px;
    text-align: center;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}

/* Confirm modal inside Shadow DOM */
#vnpost-confirm-overlay {
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(4px);
    z-index: 100000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    animation: vnpostFadeIn 0.2s ease-out;
}
#vnpost-confirm-modal {
    background: #181922;
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 14px;
    padding: 16px;
    width: 100%;
    max-width: 290px;
    box-shadow: 0 20px 50px rgba(0,0,0,0.5);
    animation: vnpostModalPop 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.15);
}
#vnpost-autofill-panel.light-mode #vnpost-confirm-modal {
    background: #ffffff;
    border-color: rgba(0, 0, 0, 0.08);
    box-shadow: 0 20px 50px rgba(0,0,0,0.15);
    color: #1f2937;
}
#vnpost-confirm-title {
    font-size: 13.5px;
    font-weight: 600;
    margin-bottom: 8px;
    color: #fff;
    display: flex;
    align-items: center;
    gap: 6px;
}
#vnpost-autofill-panel.light-mode #vnpost-confirm-title {
    color: #111827;
}
#vnpost-confirm-msg {
    font-size: 12px;
    color: #94a3b8;
    line-height: 1.5;
    margin-bottom: 16px;
}
#vnpost-autofill-panel.light-mode #vnpost-confirm-msg {
    color: #4b5563;
}
#vnpost-confirm-actions {
    display: flex;
    gap: 10px;
    justify-content: flex-end;
}
#vnpost-confirm-actions button {
    padding: 8px 20px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    border: none;
    transition: background 0.15s;
}
#vnpost-confirm-btn-cancel {
    background: #2d3548;
    color: #94a3b8;
}
#vnpost-confirm-btn-cancel:hover {
    background: #3b4459;
    color: #f1f5f9;
}
#vnpost-confirm-btn-ok {
    background: #4f46e5;
    color: #fff;
}
#vnpost-confirm-btn-ok:hover {
    background: #6366f1;
}

#vnpost-autofill-panel.light-mode #vnpost-confirm-btn-cancel {
    background: #e4e4e7;
    color: #4b5563;
}
#vnpost-autofill-panel.light-mode #vnpost-confirm-btn-cancel:hover {
    background: #d4d4d8;
    color: #18181b;
}

/* --- PANEL INLINE LOGIN FORM STYLES --- */
.panel-login-box {
    padding: 16px 14px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    text-align: left;
}
.panel-login-title {
    font-size: 15px;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 2px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.panel-login-subtitle {
    font-size: 12px;
    color: var(--text-muted);
    margin-bottom: 4px;
    line-height: 1.45;
}
.panel-login-tabs {
    display: flex;
    gap: 6px;
    background: rgba(0, 0, 0, 0.05);
    padding: 4px;
    border-radius: 8px;
    margin: 4px 0 8px 0;
}
#vnpost-autofill-panel.light-mode .panel-login-tabs {
    background: #f1f5f9;
}
.panel-login-tab {
    flex: 1;
    padding: 7px 8px;
    font-size: 11.5px;
    font-weight: 700;
    border: none;
    border-radius: 6px;
    background: transparent;
    color: var(--text-muted);
    cursor: pointer;
    text-align: center;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
}
.panel-login-tab.active {
    background: var(--surface-bg, #ffffff);
    color: var(--theme-color, #0056b3);
    box-shadow: 0 1px 3px rgba(0,0,0,0.12);
}
#vnpost-autofill-panel.light-mode .panel-login-tab.active {
    background: #ffffff;
    color: var(--theme-color, #0056b3);
}
.panel-login-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.panel-login-label {
    font-size: 11.5px;
    font-weight: 600;
    color: var(--text-secondary);
}
.panel-login-input {
    width: 100%;
    padding: 9px 12px;
    border-radius: 8px;
    border: 1px solid var(--input-border);
    background: var(--input-bg);
    color: var(--text-primary);
    font-size: 13px;
    outline: none;
    box-sizing: border-box;
    transition: border-color 0.2s, background-color 0.2s;
}
.panel-login-input:focus {
    border-color: var(--theme-color, #6366f1);
    background: var(--input-focus-bg);
}
#vnpost-autofill-panel.light-mode .panel-login-title {
    color: #0f172a;
}
#vnpost-autofill-panel.light-mode .panel-login-subtitle {
    color: #475569;
}
#vnpost-autofill-panel.light-mode .panel-login-label {
    color: #0f766e;
}
#vnpost-autofill-panel.light-mode .panel-login-input {
    background: #ffffff;
    border: 1px solid #cbd5e1;
    color: #0f172a;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
}
#vnpost-autofill-panel.light-mode .panel-login-input:focus {
    border-color: var(--theme-color, #0056b3);
    background: #ffffff;
    box-shadow: 0 0 0 3px rgba(0, 86, 179, 0.15);
}
.panel-login-error {
    display: none;
    padding: 8px 10px;
    border-radius: 8px;
    background: rgba(239, 68, 68, 0.15);
    border: 1px solid rgba(239, 68, 68, 0.3);
    color: #fca5a5;
    font-size: 12px;
    line-height: 1.4;
}
#vnpost-autofill-panel.light-mode .panel-login-error {
    background: #fef2f2;
    border-color: #fecaca;
    color: #dc2626;
}
.panel-login-btn {
    width: 100%;
    padding: 10px 14px;
    border-radius: 9px;
    border: none;
    background: var(--theme-color, #6366f1);
    color: #ffffff;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    transition: opacity 0.2s, transform 0.1s;
    box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
}
.panel-login-btn:hover:not(:disabled) {
    opacity: 0.92;
    transform: translateY(-1px);
}
.panel-login-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}
.panel-login-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 2px;
    font-size: 11.5px;
}
.panel-login-link {
    color: var(--theme-color, #6366f1);
    text-decoration: none;
    cursor: pointer;
    font-weight: 600;
}
.panel-login-link:hover {
    text-decoration: underline;
}

.panel-version-badge {
    font-size: 10px;
    font-weight: 700;
    padding: 2px 7px;
    border-radius: 10px;
    background: rgba(56, 189, 248, 0.15);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.35);
    letter-spacing: 0.3px;
    display: inline-flex;
    align-items: center;
    margin-left: 6px;
    flex-shrink: 0;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}
#vnpost-autofill-panel.theme-light .panel-version-badge,
#vnpost-autofill-panel.light-mode .panel-version-badge {
    background: #e0f2fe;
    color: #0284c7;
    border-color: #bae6fd;
}

@keyframes vnpostFadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}
/* --- MODAL XÉT DUYỆT & ĐỐI CHIẾU ĐƠN HÀNG (TRỌNG TÂM TIỀN COD - BẢN RỘNG RÃI & CHI TIẾT) --- */
.af-approval-overlay {
    position: fixed;
    inset: 0;
    z-index: 2147483647;
    background: rgba(15, 23, 42, 0.82);
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    box-sizing: border-box;
    font-family: 'Be Vietnam Pro', 'Noto Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    animation: vnpostFadeIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
}

.af-approval-card {
    background: var(--bg-panel, #0f172a);
    border: 1px solid rgba(255, 255, 255, 0.18);
    border-radius: 20px;
    width: 100%;
    max-width: 920px;
    max-height: 94vh;
    overflow-y: auto;
    box-shadow: 0 30px 80px rgba(0, 0, 0, 0.65), inset 0 0 0 1px rgba(255, 255, 255, 0.12);
    display: flex;
    flex-direction: column;
    gap: 16px;
    padding: 26px 30px;
    box-sizing: border-box;
    color: var(--text-primary, #f8fafc);
    animation: vnpostModalPop 0.25s cubic-bezier(0.16, 1, 0.3, 1);
}

.af-approval-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    border-bottom: 1px solid rgba(255, 255, 255, 0.12);
    padding-bottom: 14px;
}

.af-approval-title-group h3 {
    margin: 0 0 6px 0;
    font-size: 18px;
    font-weight: 800;
    color: #f8fafc;
    display: flex;
    align-items: center;
    gap: 10px;
    letter-spacing: -0.2px;
}

.af-approval-meta-row {
    display: flex;
    gap: 8px;
    align-items: center;
    font-size: 12px;
    color: #94a3b8;
    flex-wrap: wrap;
}

.af-approval-pill {
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.14);
    border-radius: 8px;
    padding: 3px 10px;
    font-weight: 600;
}

.af-approval-close-btn {
    background: transparent;
    border: none;
    color: #94a3b8;
    cursor: pointer;
    font-size: 20px;
    padding: 4px 10px;
    border-radius: 8px;
    transition: all 0.15s ease;
}
.af-approval-close-btn:hover {
    background: rgba(255, 255, 255, 0.14);
    color: #f8fafc;
}

/* Hero COD Card */
.af-hero-cod {
    border-radius: 18px;
    padding: 20px 24px;
    display: flex;
    flex-direction: column;
    gap: 14px;
    transition: all 0.2s ease;
    box-sizing: border-box;
}

.af-hero-cod.level-danger {
    background: linear-gradient(135deg, rgba(239, 68, 68, 0.18) 0%, rgba(185, 28, 28, 0.1) 100%);
    border: 2px solid #ef4444;
    box-shadow: 0 0 25px rgba(239, 68, 68, 0.25);
}

.af-hero-cod.level-warning {
    background: linear-gradient(135deg, rgba(245, 158, 11, 0.18) 0%, rgba(217, 119, 6, 0.1) 100%);
    border: 2px solid #f59e0b;
    box-shadow: 0 0 20px rgba(245, 158, 11, 0.2);
}

.af-hero-cod.level-success {
    background: linear-gradient(135deg, rgba(16, 185, 129, 0.18) 0%, rgba(5, 150, 105, 0.1) 100%);
    border: 2px solid #10b981;
    box-shadow: 0 0 20px rgba(16, 185, 129, 0.2);
}

.af-hero-cod.level-info {
    background: linear-gradient(135deg, rgba(2, 132, 199, 0.18) 0%, rgba(3, 105, 161, 0.1) 100%);
    border: 2px solid #0284c7;
    box-shadow: 0 0 20px rgba(2, 132, 199, 0.2);
}

.af-hero-cod-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.af-hero-cod-label {
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    opacity: 0.9;
}

.af-hero-cod-badge {
    font-size: 11px;
    font-weight: 700;
    padding: 3px 10px;
    border-radius: 20px;
    text-transform: uppercase;
}
.level-danger .af-hero-cod-badge { background: #ef4444; color: #fff; }
.level-warning .af-hero-cod-badge { background: #f59e0b; color: #1e293b; }
.level-success .af-hero-cod-badge { background: #10b981; color: #fff; }
.level-info .af-hero-cod-badge { background: #0284c7; color: #fff; }

.af-hero-cod-center {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.af-hero-cod-amount {
    font-size: 38px;
    font-weight: 800;
    line-height: 1.1;
    letter-spacing: -0.5px;
}
.level-danger .af-hero-cod-amount { color: #f87171; }
.level-warning .af-hero-cod-amount { color: #fbbf24; }
.level-success .af-hero-cod-amount { color: #34d399; }
.level-info .af-hero-cod-amount { color: #38bdf8; }

.af-hero-cod-words {
    font-size: 14.5px;
    font-style: italic;
    opacity: 0.9;
}

.af-cod-compare-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
}

.af-cod-compare-col {
    background: rgba(0, 0, 0, 0.32);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 12px;
    padding: 10px 14px;
    display: flex;
    flex-direction: column;
    gap: 4px;
}
.af-cod-compare-title {
    font-size: 12px;
    color: #94a3b8;
    font-weight: 700;
}
.af-cod-compare-val {
    font-size: 16px;
    font-weight: 800;
}

.af-cod-alert-box {
    border-radius: 12px;
    padding: 12px 16px;
    font-size: 13.5px;
    line-height: 1.45;
    display: flex;
    align-items: flex-start;
    gap: 10px;
}
.level-danger .af-cod-alert-box {
    background: rgba(239, 68, 68, 0.2);
    border: 1px solid rgba(239, 68, 68, 0.35);
    color: #fecaca;
}
.level-warning .af-cod-alert-box {
    background: rgba(245, 158, 11, 0.2);
    border: 1px solid rgba(245, 158, 11, 0.35);
    color: #fef3c7;
}
.level-success .af-cod-alert-box {
    background: rgba(16, 185, 129, 0.15);
    border: 1px solid rgba(16, 185, 129, 0.3);
    color: #d1fae5;
}
.level-info .af-cod-alert-box {
    background: rgba(2, 132, 199, 0.15);
    border: 1px solid rgba(2, 132, 199, 0.3);
    color: #e0f2fe;
}

.af-cod-quick-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: center;
}

.af-quick-btn {
    border: none;
    border-radius: 10px;
    padding: 9px 15px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.15s ease;
    display: inline-flex;
    align-items: center;
    gap: 6px;
}
.af-quick-btn-apply {
    background: #0284c7;
    color: #fff;
    box-shadow: 0 2px 6px rgba(2, 132, 199, 0.3);
}
.af-quick-btn-apply:hover {
    background: #0369a1;
    transform: translateY(-1px);
}
.af-quick-btn-zero {
    background: rgba(2, 132, 199, 0.2);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 0.35);
}
.af-quick-btn-zero:hover {
    background: rgba(2, 132, 199, 0.35);
}
.af-quick-btn-edit {
    background: rgba(255, 255, 255, 0.08);
    color: #e2e8f0;
    border: 1px solid rgba(255, 255, 255, 0.16);
}
.af-quick-btn-edit:hover {
    background: rgba(255, 255, 255, 0.16);
}

.af-inline-cod-edit {
    display: flex;
    gap: 8px;
    align-items: center;
    width: 100%;
}
.af-inline-cod-input {
    flex: 1;
    background: rgba(0, 0, 0, 0.45);
    border: 1px solid rgba(255, 255, 255, 0.25);
    border-radius: 10px;
    padding: 9px 12px;
    color: #fff;
    font-size: 15px;
    font-weight: 700;
    outline: none;
}
.af-inline-cod-input:focus {
    border-color: #38bdf8;
    box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.2);
}

/* Recipient details grid */
.af-review-section-title {
    font-size: 13.5px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #38bdf8;
    margin: 8px 0 2px 0;
    display: flex;
    align-items: center;
    gap: 6px;
}

/* 2-Column Comparison Table (Form Bưu Điện vs Panel Auto Fill) */
.af-compare-container {
    display: flex;
    flex-direction: column;
    gap: 10px;
}
.af-compare-header {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    font-size: 12px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #94a3b8;
    padding: 0 6px;
}
.af-compare-header-col {
    display: flex;
    align-items: center;
    gap: 8px;
}
.af-compare-header-col.carrier {
    color: #cbd5e1;
}
.af-compare-header-col.panel {
    color: #38bdf8;
}
.af-compare-row {
    background: rgba(255, 255, 255, 0.035);
    border: 1px solid rgba(255, 255, 255, 0.09);
    border-radius: 12px;
    padding: 11px 16px;
    display: flex;
    flex-direction: column;
    gap: 6px;
    transition: all 0.15s ease;
}
.af-compare-row.is-mismatch {
    background: rgba(245, 158, 11, 0.09);
    border-color: rgba(245, 158, 11, 0.4);
}
.af-compare-row.is-match {
    border-color: rgba(16, 185, 129, 0.25);
}
.af-compare-row-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 12px;
    font-weight: 700;
    color: #94a3b8;
}
.af-compare-row-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    align-items: start;
}
.af-compare-cell {
    font-size: 14px;
    font-weight: 600;
    word-break: break-word;
    line-height: 1.45;
}
.af-compare-cell.cell-carrier {
    color: #f1f5f9;
}
.af-compare-cell.cell-panel {
    color: #38bdf8;
}
.af-compare-pill-match {
    font-size: 11.5px;
    font-weight: 700;
    color: #34d399;
    background: rgba(16, 185, 129, 0.15);
    border: 1px solid rgba(16, 185, 129, 0.35);
    border-radius: 12px;
    padding: 2px 9px;
}
.af-compare-pill-mismatch {
    font-size: 11.5px;
    font-weight: 700;
    color: #fbbf24;
    background: rgba(245, 158, 11, 0.15);
    border: 1px solid rgba(245, 158, 11, 0.35);
    border-radius: 12px;
    padding: 2px 9px;
}

.af-address-breakdown {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    margin-top: 6px;
}
.af-address-sub-pill {
    font-size: 11.5px;
    font-weight: 600;
    padding: 2px 8px;
    border-radius: 6px;
    background: rgba(255, 255, 255, 0.08);
    color: #cbd5e1;
    border: 1px solid rgba(255, 255, 255, 0.12);
}

.af-raw-preview-details {
    background: rgba(0, 0, 0, 0.28);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 12px;
    padding: 10px 14px;
    font-size: 12.5px;
}
.af-raw-preview-details summary {
    cursor: pointer;
    color: #94a3b8;
    font-weight: 600;
    outline: none;
}
.af-raw-preview-content {
    margin-top: 8px;
    padding-top: 8px;
    border-top: 1px dashed rgba(255, 255, 255, 0.12);
    white-space: pre-wrap;
    color: #cbd5e1;
    max-height: 120px;
    overflow-y: auto;
    line-height: 1.45;
}

/* Modal Actions */
.af-modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    margin-top: 8px;
    border-top: 1px solid rgba(255, 255, 255, 0.12);
    padding-top: 16px;
}
.af-modal-btn-cancel {
    background: rgba(255, 255, 255, 0.08);
    color: #cbd5e1;
    border: 1px solid rgba(255, 255, 255, 0.16);
    border-radius: 11px;
    padding: 12px 20px;
    font-size: 13.5px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.15s ease;
}
.af-modal-btn-cancel:hover {
    background: rgba(255, 255, 255, 0.15);
    color: #fff;
}
.af-modal-btn-confirm {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    color: #fff;
    border: none;
    border-radius: 11px;
    padding: 12px 30px;
    font-size: 14.5px;
    font-weight: 800;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 4px 16px rgba(16, 185, 129, 0.4);
    transition: all 0.15s ease;
}
.af-modal-btn-confirm:hover:not(:disabled) {
    transform: translateY(-1px);
    box-shadow: 0 6px 24px rgba(16, 185, 129, 0.5);
}
.af-modal-btn-confirm:disabled {
    opacity: 0.45;
    cursor: not-allowed;
    background: #475569;
    box-shadow: none;
}

/* Status badges for panel review card */
.cod-badge-danger { background: rgba(239, 68, 68, 0.2) !important; color: #f87171 !important; border: 1px solid rgba(239, 68, 68, 0.35) !important; }
.cod-badge-warning { background: rgba(245, 158, 11, 0.2) !important; color: #fbbf24 !important; border: 1px solid rgba(245, 158, 11, 0.35) !important; }
.cod-badge-success { background: rgba(16, 185, 129, 0.2) !important; color: #34d399 !important; border: 1px solid rgba(16, 185, 129, 0.35) !important; }
.cod-badge-info { background: rgba(2, 132, 199, 0.2) !important; color: #38bdf8 !important; border: 1px solid rgba(2, 132, 199, 0.35) !important; }

`;globalThis.PANEL_CSS=o})();
})()