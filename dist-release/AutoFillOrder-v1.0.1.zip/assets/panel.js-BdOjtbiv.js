(function(){(()=>{const N={theme:'<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/><circle cx="12" cy="12" r="4"/><path d="M12 2a10 10 0 0 0 10 10" fill="currentColor" opacity="0.3"/></svg>',settings:'<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',minimize:'<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>',maximize:'<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',dock:'<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M15 4v16"/><path d="m10 9-3 3 3 3"/></svg>',float:'<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M16 3h3a2 2 0 0 1 2 2v3"/><path d="M8 21H5a2 2 0 0 1-2-2v-3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/></svg>',parse:'<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',clear:'<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>',copy:'<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',check:'<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',user:'<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',phone:'<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',orderCode:'<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="9" y1="3" x2="9" y2="21"/><line x1="15" y1="3" x2="15" y2="21"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/></svg>',fee:'<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>',address:'<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-12a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',package:'<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>',fill:'<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>',save:'<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>',apiWaiting:'<svg class="spinner-loading" xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>',apiWarning:'<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#eab308" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',apiOk:'<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',apiUnknown:'<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',warn:'<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>'},Be=340;function je(){if(typeof document>"u")return null;const t=document.getElementById("vnpost-autofill-shadow-host");return t&&t.shadowRoot?t.shadowRoot:document}function m(t){const s=je();return s&&s.getElementById?s.getElementById(t):null}function Oe(t){if(typeof t=="string"){const s=t.toLowerCase();return s.includes("vnpost")?{id:"vnpost",title:"VNPost",themeColor:"#0056b3"}:s.includes("jt")?{id:"jt",title:"J&T Express",themeColor:"#e11d48"}:{id:s,title:s.toUpperCase(),themeColor:"#4f46e5"}}return t||{id:"vnpost",title:"VNPost",themeColor:"#0056b3"}}function bt(){try{if((typeof localStorage<"u"?localStorage.getItem("antigravity_ui_theme"):null)==="dark")return"dark"}catch{}return"light"}function Ke(t){t&&(bt()==="dark"?t.classList.remove("light-mode"):t.classList.add("light-mode"))}function Ue(t){const s=t?"light":"dark";try{typeof localStorage<"u"&&localStorage.setItem("antigravity_ui_theme",s)}catch{}if(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id&&chrome.storage&&chrome.storage.local)try{chrome.storage.local.set({antigravity_ui_theme:s})}catch{}}const ye={get(t,s){try{if(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id&&chrome.storage&&chrome.storage.local){chrome.storage.local.get(t,v=>{chrome.runtime&&chrome.runtime.lastError,s(v||{})});return}}catch{}const u={};t.forEach(v=>{try{const x=typeof localStorage<"u"?localStorage.getItem(v):null;u[v]=x?JSON.parse(x):void 0}catch{u[v]=void 0}}),s(u)},set(t){try{if(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id&&chrome.storage&&chrome.storage.local){chrome.storage.local.set(t,()=>{chrome.runtime&&chrome.runtime.lastError});return}}catch{}typeof localStorage>"u"||Object.entries(t).forEach(([s,u])=>{try{localStorage.setItem(s,JSON.stringify(u))}catch{}})}};function Je(t,s){t&&t.classList.toggle("is-visible",!!s)}function De(t){if(typeof document>"u"||!document.body)return;const s=document.body,u="vnpost-dock-page-offset-style";let v=document.getElementById(u);if(t){s.dataset.vnpostDockOffsetActive!=="true"&&(s.dataset.vnpostDockOriginalPaddingRight=s.style.paddingRight||"",s.dataset.vnpostDockOriginalTransition=s.style.transition||"");const x=parseFloat(window.getComputedStyle(s).paddingRight||"0")||0,l=s.dataset.vnpostDockOffsetActive==="true"?Math.max(0,x-Be):x;s.style.paddingRight=`${l+Be}px`,s.style.transition||(s.style.transition="padding-right 280ms cubic-bezier(0.4, 0, 0.2, 1)"),s.dataset.vnpostDockOffsetActive="true",v||(v=document.createElement("style"),v.id=u,(document.head||document.documentElement).appendChild(v)),v.textContent=`
        /* Đẩy các thanh công cụ / nút bấm cố định ở đáy trang của VNPost & J&T sang trái khi panel đang ghim */
        .ant-pro-footer-bar,
        .ant-pro-footer-bar-dom,
        .ant-pro-footer-toolbar,
        div[class*="ant-pro-footer-bar"],
        div[class*="ant-pro-footer-toolbar"],
        .fixed-bottom-container,
        div[class*="fixed-bottom-container"],
        .fixed-bottom,
        div[class*="fixed-bottom"],
        .footer-btn,
        div[class*="footer-btn"],
        .page-footer,
        .create-order-footer,
        .order-create-footer,
        .bottom-action-bar,
        .action-bar-fixed,
        .action-bar,
        .order-footer,
        .ant-layout-footer,
        .el-footer,
        footer[class*="fixed" i],
        footer[style*="fixed"],
        div[class*="footer" i][class*="fixed" i],
        div[class*="bottom" i][class*="fixed" i],
        div[class*="footer" i][style*="fixed"],
        div[class*="bottom" i][style*="fixed"],
        div[style*="position: fixed"][style*="bottom: 0"],
        div[style*="position:fixed"][style*="bottom:0"],
        div[style*="position: fixed"][style*="bottom:0"] {
          right: ${Be}px !important;
          width: auto !important;
          max-width: calc(100vw - ${Be}px) !important;
          box-sizing: border-box !important;
          transition: right 280ms cubic-bezier(0.4, 0, 0.2, 1), max-width 280ms cubic-bezier(0.4, 0, 0.2, 1), width 280ms cubic-bezier(0.4, 0, 0.2, 1) !important;
        }

        /* Đảm bảo flex container bên trong các thanh footer không bị tràn */
        .ant-pro-footer-bar-right,
        .ant-pro-footer-bar > div,
        .fixed-bottom-container > div {
          padding-right: 12px !important;
          box-sizing: border-box !important;
        }
      `;return}s.dataset.vnpostDockOffsetActive==="true"&&(s.style.paddingRight=s.dataset.vnpostDockOriginalPaddingRight||"",s.style.transition=s.dataset.vnpostDockOriginalTransition||"",delete s.dataset.vnpostDockOffsetActive,delete s.dataset.vnpostDockOriginalPaddingRight,delete s.dataset.vnpostDockOriginalTransition),v&&v.remove()}function Pe(t,s,u,v,x={}){const l=v==="floating"?"floating":"docked",y=m("vnpost-btn-minimize");if(l==="docked"){t.classList.remove("panel-floating","minimized"),t.classList.add("panel-docked"),t.classList.toggle("collapsed",!!x.collapsed),t.style.top="",t.style.left="",t.style.right="",t.style.bottom="",Je(s,x.collapsed),De(!x.collapsed),u&&(u.innerHTML=N.float,u.title="Thả nổi panel"),y&&(y.innerHTML=N.minimize,y.title="Thu vào mép phải");return}t.classList.remove("panel-docked","collapsed"),t.classList.add("panel-floating"),Je(s,!1),De(!1),u&&(u.innerHTML=N.dock,u.title="Ghim panel vào mép phải"),y&&(y.innerHTML=t.classList.contains("minimized")?N.maximize:N.minimize,y.title="Thu nhỏ panel");const b=x.position||{},p=Number(b.top),g=Number(b.left);Number.isFinite(p)&&Number.isFinite(g)?(t.style.top=`${Math.max(0,p)}px`,t.style.left=`${Math.max(0,g)}px`,t.style.right="auto",t.style.bottom="auto"):(t.style.top="20px",t.style.right="20px",t.style.left="auto",t.style.bottom="auto")}function et(t,s,u,v,x,l,y,b){var O,r,d,T;try{let Le=function(){if(he&&(he.classList.toggle("is-collapsed",Z),Te&&(Te.textContent=Z?"▼":"▲",Te.title=Z?"Mở rộng hàng đợi":"Thu gọn hàng đợi"),Ve))if(Z&&H.length>0){const e=H[W],o=(e==null?void 0:e.name)||"Khách lẻ",a=e!=null&&e.phone?` (${e.phone})`:"";Ve.textContent=`· Đơn ${W+1}: ${o}${a}`,Ve.style.display="inline-block"}else Ve.style.display="none"},Ne=function(){if(!H.length)return;const e=H[W];if(e){if(ot&&(ot.textContent=`Đơn ${W+1}/${H.length}`),at){const o=e.name||"Khách lẻ",a=e.phone||"",i=Number(e.codAmount||e.cod_amount||e.cod)||0,E=i>0?` · COD ${i.toLocaleString("vi-VN")}đ`:"";at.textContent=`${o} (${a})${E}`}He&&(He.disabled=W<=0),qe&&(qe.disabled=W>=H.length-1),Le()}},we=function(){if(!H.length)return;const e=H[W];e&&(globalThis.parsedDataStore={savedOrderId:e.id,name:e.name||"",phone:e.phone||"",address:e.address||"",orderCode:e.orderCode||e.order_code||"",codAmount:Number(e.codAmount||e.cod_amount||e.cod)||0,goodsName:e.goodsName||e.goods_name||"Hàng hóa thời trang",weightGrams:Number(e.weightGrams||e.weight)||200,notes:e.notes||"",collectFee:!!(e.collectFee||e.collect_fee),rawAddress:e.rawAddress||e.address||"",ward:e.ward||"",district:e.district||"",province:e.province||""},G&&(G.value=e.rawText||`${e.name||""} ${e.phone||""} ${e.address||""}`),typeof $e=="function"&&$e(globalThis.parsedDataStore),showVnpostToast(`📥 Đã nạp đơn ${W+1}/${H.length}: ${e.name||"Khách"}`,"info"))};var p=Le,g=Ne,w=we;if(typeof document>"u")return;const c=Oe(t);let P=document.getElementById("vnpost-autofill-shadow-host");const f=P?m("vnpost-autofill-panel"):null;if(f)if(f.dataset&&f.dataset.panelType==="login")f.remove();else return;if(!document.body)return;P||(P=document.createElement("div"),P.id="vnpost-autofill-shadow-host",document.body.appendChild(P));const n=P.shadowRoot||P.attachShadow({mode:"open"}),h=n.querySelector("#vnpost-autofill-panel");h&&h.remove();const S=n.querySelector("#vnpost-dock-toggle-tab");if(S&&S.remove(),!n.querySelector("#vnpost-shadow-style")){const e=document.createElement("style");e.id="vnpost-shadow-style",e.textContent=typeof PANEL_CSS<"u"?PANEL_CSS:"",n.appendChild(e)}const I=document.createElement("div");if(I.id="vnpost-autofill-panel",I.dataset.panelType="input",Ke(I),typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id&&chrome.storage&&chrome.storage.local)try{chrome.storage.local.get(["antigravity_ui_theme"],e=>{if(!chrome.runtime.lastError){if(e&&e.antigravity_ui_theme==="dark"){I.classList.remove("light-mode");try{localStorage.setItem("antigravity_ui_theme","dark")}catch{}}else if(e&&e.antigravity_ui_theme==="light"){I.classList.add("light-mode");try{localStorage.setItem("antigravity_ui_theme","light")}catch{}}}})}catch{}const ce=c.themeColor||(c.id==="vnpost"?"#0056b3":"#4f46e5");I.style.setProperty("--theme-color",ce);const K=c.id==="vnpost",k=K?"display: inline-flex; background-color: #10b981;":"display: none;",L=K?"display: none;":"display: inline-flex; background-color: #e11d48;";let A="v1";try{typeof chrome<"u"&&chrome.runtime&&chrome.runtime.getManifest&&(A="v"+(chrome.runtime.getManifest().version||"1"))}catch{}I.innerHTML=`
        <div class="minimized-icon">${N.parse}</div>
        
        <!-- HEADER TOPBAR -->
        <div id="vnpost-panel-header">
          <div class="vnpost-header-main">
            <div class="vnpost-brand-group">
              <span class="brand-live-dot" title="Sẵn sàng hoạt động"></span>
              <span id="vnpost-panel-header-text" class="brand-title"></span>
              <span id="vnpost-panel-version-badge" class="panel-version-badge" title="Phiên bản Auto Fill Order">${A}</span>
            </div>
            <div class="vnpost-header-controls">
              <span id="vnpost-api-status" title="Kiểm tra kết nối..." class="api-status-badge">${N.apiWaiting}</span>
              <button id="vnpost-btn-toggle-draft-queue" class="panel-header-btn" title="Bật / Tắt Hàng đợi đơn nháp" style="position:relative;">📥<span id="header-draft-count-badge" class="header-draft-badge" style="display:none;">0</span></button>
              <button id="vnpost-btn-dock-toggle" title="Thả nổi / Ghim panel">${N.float}</button>
              <button id="vnpost-btn-theme" title="Chuyển chế độ Sáng / Tối">${N.theme}</button>
              <button id="vnpost-btn-settings" title="Cài đặt & Quản lý">${N.settings}</button>
              <button id="vnpost-btn-minimize" title="Thu nhỏ">${N.minimize}</button>
            </div>
          </div>
          <div class="panel-context-strip" aria-label="Ngữ cảnh lên đơn">
            <div class="panel-context-shop">🏪 <span id="panel-shop-name" class="panel-context-value context-missing">Chưa chọn Shop</span></div>
            <button id="panel-account-trigger" class="panel-account-trigger" type="button" aria-expanded="false" aria-haspopup="menu">
              👤 <span id="panel-user-account" class="panel-context-value context-missing">Chưa xác định</span>
              <span class="context-separator">·</span>
              <span id="panel-carrier-account" class="panel-context-value context-missing">Chưa nhận diện</span>
            </button>
            <div id="panel-account-menu" class="panel-account-menu" role="menu" hidden>
              <strong id="panel-menu-user">---</strong><span id="panel-menu-carrier">---</span>
              <hr><span id="panel-menu-shop">---</span><span>${c.title||""}</span>
              <hr><div class="panel-menu-version-row" style="font-size:11px; color:#94a3b8; padding:3px 8px; font-weight:600; display:flex; justify-content:space-between; align-items:center;">
                <span>Phiên bản:</span>
                <span class="menu-version-badge" style="color:#38bdf8; font-weight:700;">${A}</span>
              </div><hr>
              <button id="panel-menu-settings" type="button" role="menuitem">⚙ Cài đặt</button>
              <button id="panel-menu-logout" type="button" role="menuitem">⇥ Đăng xuất</button>
            </div>
          </div>
        </div>

        <div id="vnpost-panel-body">
          <!-- HÀNG ĐỢI ĐƠN NHÁP (DRAFT QUEUE NAVIGATOR) -->
          <div id="vnpost-draft-queue" class="draft-queue-container" style="display:none;">
            <div class="draft-queue-header">
              <div class="draft-queue-title-group">
                <span class="draft-queue-icon">📥</span>
                <span class="draft-queue-title">Hàng Đợi Đơn Nháp</span>
                <span id="draft-queue-badge" class="draft-queue-badge">0 đơn</span>
                <span id="draft-queue-mini-summary" class="draft-queue-mini-summary" style="display:none;"></span>
              </div>
              <div class="draft-queue-header-actions">
                <button id="btn-draft-queue-toggle-collapse" class="draft-queue-btn-collapse" type="button" title="Thu gọn / Mở rộng hàng đợi">▲</button>
                <button id="btn-draft-queue-clear" class="draft-queue-close" type="button" title="Ẩn / Tắt hàng đợi này">✕</button>
              </div>
            </div>
            <div class="draft-queue-body">
              <div class="draft-queue-nav">
                <button id="btn-draft-prev" class="draft-nav-btn" title="Đơn trước">◀</button>
                <div class="draft-current-info">
                  <div id="draft-current-index" class="draft-index-text">Đơn 1/1</div>
                  <div id="draft-current-summary" class="draft-summary-text">---</div>
                </div>
                <button id="btn-draft-next" class="draft-nav-btn" title="Đơn kế tiếp">▶</button>
              </div>
              <div class="draft-queue-actions-container">
                <div class="draft-queue-primary-row">
                  <button id="btn-draft-load" class="btn-draft-action-primary" title="Nạp đơn này vào bảng kiểm tra">
                    ⚡ <span>Nạp Vào Bảng</span>
                  </button>
                  <button id="btn-draft-fill-next" class="btn-draft-action-success" title="Điền vào form bưu điện và tự chuyển sang đơn kế tiếp">
                    ⏩ <span>Điền & Đơn Tiếp</span>
                  </button>
                </div>
                <div class="draft-queue-secondary-row">
                  <button id="btn-draft-delete" class="btn-draft-action-ghost-danger" title="Xóa đơn này khỏi hàng đợi nháp">
                    🗑️ <span>Xóa đơn này</span>
                  </button>
                  <button id="btn-draft-clear-all" class="btn-draft-action-ghost-warning" title="Dọn sạch toàn bộ các đơn nháp trong hàng đợi">
                    🧹 <span>Xóa tất cả</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div id="source-order-card" class="input-card" aria-expanded="true">
            <div class="input-card-header">
              <span id="source-card-title" class="input-card-title">📝 Nội dung đơn hàng</span>
              <div class="source-card-header-actions">
                <span id="source-dirty-badge" class="source-dirty-badge" style="display:none;">● Đã thay đổi</span>
                <span class="input-kbd-shortcut" title="Phím tắt tách nhanh">Ctrl + ↵</span>
                <button id="btn-edit-source" class="source-edit-btn" type="button" style="display:none;" title="Mở nội dung gốc để chỉnh sửa">✎ Sửa</button>
              </div>
            </div>
            <div id="source-expanded-content">
              <textarea id="rawOrderText" rows="3" placeholder="Dán thông tin đơn hàng thô vào đây...&#10;(Ví dụ: Họ tên, Số điện thoại, Địa chỉ, Tiền thu hộ...)"></textarea>
              <div id="source-dirty-message" class="source-dirty-message" style="display:none;">Nội dung nguồn đã thay đổi. Kết quả bên dưới chưa được cập nhật.</div>
              <div class="input-card-actions">
                <button id="btnParseOrder" class="btn-parse-primary">
                  ${N.parse} <span>Tách Đơn Tự Động</span>
                </button>
                <button id="btnClearOrder" class="btn-clear-secondary">
                  ${N.clear} <span>Xóa</span>
                </button>
              </div>
            </div>
            <button id="source-collapsed-preview" class="source-collapsed-preview" type="button" style="display:none;" aria-label="Mở nội dung đơn hàng gốc để đối chiếu và chỉnh sửa">
              <span id="source-preview-primary" class="source-preview-primary">Nội dung đơn hàng gốc</span>
              <span id="source-preview-address" class="source-preview-address">---</span>
              <span class="source-preview-hint"><span>Bấm để chỉnh sửa nội dung thô</span><span aria-hidden="true">→</span></span>
            </button>
          </div>

          <div id="panel-empty-state" class="panel-empty-state">
            <strong>Chưa có đơn hàng</strong>
            <span>Dán nội dung đơn hàng ở trên để bắt đầu xử lý.</span>
          </div>

          <!-- CẢNH BÁO TRÙNG ĐƠN TRONG NGÀY -->
          <div id="panel-duplicate-alert" class="panel-duplicate-alert" style="display:none;" role="alert">
            <div class="duplicate-alert-header">
              <span id="panel-duplicate-title" class="duplicate-alert-title">⚠️ ĐƠN ĐÃ LÊN TRONG NGÀY</span>
              <span id="panel-duplicate-time" class="duplicate-alert-time">Hôm nay</span>
            </div>
            <div id="panel-duplicate-message" class="duplicate-alert-message"></div>
            <div id="panel-duplicate-details" class="duplicate-alert-details"></div>
          </div>

          <div id="panel-validation-error" class="panel-validation-error" hidden>
            <strong>⚠ CẦN KIỂM TRA</strong>
            <div id="panel-validation-checklist"></div>
            <p id="panel-validation-message"></p>
            <button id="panel-fix-information" type="button">Sửa thông tin</button>
          </div>

          <!-- REVIEW BENTO PANEL (V2 DECISION-FIRST) -->
          <div id="review-panel">
            <div class="review-header-v2">
              <span class="review-section-title">⚡ Dữ liệu đã bóc tách</span>
              <span class="review-edit-badge">✏️ Bấm để sửa nhanh</span>
            </div>

            <div class="bento-grid-v2">
              <div class="bento-cell">
                <span class="bento-label">${N.user} Khách hàng</span>
                <span id="rev-name" class="bento-val review-editable" contenteditable="true" title="Bấm để sửa">---</span>
              </div>

              <div class="bento-cell">
                <div class="bento-label-row">
                  <span class="bento-label">${N.phone} Điện thoại</span>
                  <button class="copy-btn mini-copy" data-copy="rev-phone" title="Sao chép SĐT">${N.copy}</button>
                </div>
                <span id="rev-phone" class="bento-val review-editable" contenteditable="true" title="Bấm để sửa">---</span>
              </div>

              <div class="bento-cell">
                <span class="bento-label">${N.orderCode} Mã đơn</span>
                <span id="rev-code" class="bento-val review-editable" contenteditable="true" title="Bấm để sửa">---</span>
              </div>

              <div class="bento-cell">
                <span class="bento-label">${N.fee} Thu cước</span>
                <span id="rev-fee" class="bento-val fee-status fee-status--no">KHÔNG</span>
              </div>
            </div>

            <div class="cod-primary-card">
              <div class="cod-card-left">
                <span class="cod-card-label">💰 TIỀN THU HỘ (COD)</span>
                <span id="rev-cod-status" class="cod-status-badge">✓ Hợp lệ</span>
              </div>
              <div class="cod-card-right">
                <span id="rev-cod" class="cod-primary-val review-editable" contenteditable="true" title="Bấm để chỉnh sửa tiền COD">0 đ</span>
              </div>
            </div>

            <div class="address-engine-card">
              <div class="address-engine-header">
                <div class="address-title-group">
                  <span class="address-engine-title">📍 ĐỊA CHỈ GIAO HÀNG</span>
                  <span id="address-status-badge" class="address-verified-badge">✓ Đã tối ưu</span>
                </div>
                <button class="copy-btn" data-copy="rev-address" title="Sao chép địa chỉ">${N.copy}</button>
              </div>

              <div class="address-main-box">
                <span id="rev-address" class="address-text-main review-editable" contenteditable="true" title="Bấm để chỉnh sửa trực tiếp">---</span>
              </div>

              <details class="address-reference-disclosure" open>
                <summary>
                  <span class="address-reference-title">Gợi ý tham khảo để đối chiếu</span>
                  <span id="address-reference-status" class="address-reference-status">Đã bóc tách</span>
                </summary>
                <div id="address-reference-box" class="address-reference-box" aria-live="polite">
                <button class="address-reference-option" data-address-format="clean" type="button" title="Áp dụng địa chỉ 3 cấp đầy đủ">
                  <span class="address-reference-label">✨ 3 Cấp đầy đủ</span>
                  <span id="rev-suggest-clean" class="address-reference-value">---</span>
                </button>
                <button class="address-reference-option" data-address-format="2level" type="button" title="Áp dụng địa chỉ 2 cấp mới">
                  <span class="address-reference-label">🎯 2 Cấp mới</span>
                  <span id="rev-suggest-2level" class="address-reference-value">---</span>
                </button>
                  <span class="address-reference-help">Bấm vào gợi ý nếu muốn thay địa chỉ giao hàng.</span>
                </div>
              </details>

              <div class="address-format-bar">
                <span class="format-bar-label">Đổi chuẩn:</span>
                <button id="btn-switch-clean" class="format-pill-btn active" title="Dùng địa chỉ đầy đủ 3 cấp">✨ 3 Cấp đầy đủ</button>
                <button id="btn-switch-2level" class="format-pill-btn" title="Dùng địa chỉ quy đổi 2 cấp">🎯 2 Cấp mới</button>
              </div>

              <div class="address-accordion">
                <button id="address-accordion-btn" class="accordion-toggle-btn" type="button">
                  <span>⚙ Chi tiết chuẩn hóa địa giới</span>
                  <span id="accordion-arrow" class="accordion-arrow">▾</span>
                </button>
                <div id="address-accordion-content" class="accordion-content" style="display: none;">
                  <div id="ai-merger-notice" style="display: none;"></div>
                  <div class="accordion-detail-row">
                    <span class="acc-label">Địa chỉ gốc:</span>
                    <span id="rev-raw-address" class="acc-val">---</span>
                  </div>
                  <div class="accordion-detail-grid">
                    <div class="acc-grid-item">
                      <span class="acc-sublabel">Phường/Xã:</span>
                      <span id="rev-addr-ward" class="acc-subval">---</span>
                    </div>
                    <div class="acc-grid-item">
                      <span class="acc-sublabel">Quận/Huyện:</span>
                      <span id="rev-addr-district" class="acc-subval">---</span>
                    </div>
                    <div class="acc-grid-item acc-full">
                      <span class="acc-sublabel">Tỉnh/TP:</span>
                      <span id="rev-addr-province" class="acc-subval">---</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <section id="customer-history-card" class="customer-history-card" hidden>
            <div class="customer-history-heading"><strong>Lịch sử khách hàng</strong><span id="customer-history-count" class="customer-history-count-badge" title="Số đơn thành công" aria-label="Số đơn thành công"></span></div>
            <div class="customer-history-search-row">
              <input id="customer-history-search" type="search" placeholder="Nhập tên hoặc SĐT khách hàng" autocomplete="off">
              <button id="customer-history-search-btn" type="button">Tra cứu</button>
            </div>
            <div id="customer-history-result" class="customer-history-result">Nhập tên hoặc SĐT để tra cứu lịch sử đã lên đơn.</div>
          </section>
        </div>

        <div id="panel-sticky-footer" class="panel-sticky-footer">
          <div id="order-readiness-bar" class="order-readiness-bar readiness-idle">
            <span class="readiness-dot"></span>
            <span id="readiness-text" class="readiness-text">⚪ Chờ bóc tách nội dung đơn</span>
          </div>
          <div class="panel-bottom-actions">
            <button id="btnFillVNPost" class="btn-fill btn-fill-vnpost" style="${k};" disabled>
              ${N.fill} <span>Nhập đơn</span>
            </button>
            <button id="btnFillJT" class="btn-fill btn-fill-jt" style="${L};" disabled>
              ${N.fill} <span>Nhập đơn</span>
            </button>
            <button id="btnSaveOrder" class="btn-fill btn-save-order" disabled>
              ${N.save} <span>Lưu đơn</span>
            </button>
          </div>
          <div id="gemini-progress-container" aria-label="Tiến trình bóc tách đơn hàng">
            <span id="ai-status" hidden>Đang xử lý</span><span id="ai-percent" hidden>0%</span>
            <span id="parse-step-customer" hidden></span><span id="parse-step-phone" hidden></span>
            <span id="parse-step-cod" hidden></span><span id="parse-step-address" hidden></span>
            <div class="progress-bar-bg"><div id="gemini-progress-bar"></div></div>
          </div>
        </div>
      `,n.appendChild(I);const M=n.querySelector("#vnpost-dock-toggle-tab");M&&M.remove();const D=document.createElement("div");D.id="vnpost-dock-toggle-tab",D.textContent="AUTO FILL",D.title="Mở bảng Auto Fill",D.style.setProperty("--theme-color",ce),n.appendChild(D);const Y=n.getElementById("vnpost-panel-header-text");Y&&(Y.textContent=c.title||"");let q="",V="";const z=()=>{try{const e=n.getElementById("panel-shop-name"),o=n.getElementById("panel-user-account"),a=n.getElementById("panel-carrier-account"),i=typeof globalThis.detectCarrierAccount=="function"?globalThis.detectCarrierAccount(c.id):"";if(e&&(V?(e.textContent=V,e.title=`Shop đang làm việc: ${V}`,e.classList.remove("context-missing")):(e.textContent="Chưa chọn Shop",e.title="Chưa xác định Shop đang làm việc",e.classList.add("context-missing"))),o){const ee=q&&(q.includes("@")?q.split("@")[0]:q);o.textContent=ee||"Chưa xác định tài khoản",o.title=ee?`Tài khoản đăng nhập tiện ích: ${q}`:"Chưa xác định tài khoản đăng nhập Extension",o.classList.toggle("context-missing",!ee)}a&&(a.textContent=i||"Chưa nhận diện tài khoản",a.title=i?`Tài khoản bưu điện trên ${c.title}: ${i}`:`Chưa nhận diện tài khoản bưu điện trên ${c.title}`,a.classList.toggle("context-missing",!i));const E=q&&(q.includes("@")?q.split("@")[0]:q),$=n.getElementById("panel-menu-user"),J=n.getElementById("panel-menu-carrier"),B=n.getElementById("panel-menu-shop");$&&($.textContent=E||"Chưa xác định tài khoản"),J&&(J.textContent=i||"Chưa nhận diện tài khoản bưu điện"),B&&(B.textContent=V||"Chưa chọn Shop")}catch{}},re=()=>{try{typeof AuthSession<"u"&&typeof AuthSession.getSession=="function"&&AuthSession.getSession().then(e=>{var o,a,i;e&&(q=((o=e.user)==null?void 0:o.full_name)||((a=e.user)==null?void 0:a.username)||((i=e.user)==null?void 0:i.email)||"",V=e.shop_name||"",z())}).catch(()=>{}),typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id&&chrome.storage&&chrome.storage.local&&chrome.storage.local.get(["vnpost_session","activeShopName","activeShop","currentUser"],e=>{var o,a,i;if(!(chrome.runtime&&chrome.runtime.lastError)&&e){const E=e.vnpost_session;!q&&E&&(q=((o=E.user)==null?void 0:o.full_name)||((a=E.user)==null?void 0:a.username)||((i=E.user)==null?void 0:i.email)||e.currentUser||""),V||(V=(E==null?void 0:E.shop_name)||e.activeShopName||(e.activeShop?typeof e.activeShop=="object"?e.activeShop.name:"Shop #"+e.activeShop:"")),z()}})}catch{}};re(),setInterval(z,2500),setInterval(re,4e3);try{typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id&&chrome.storage&&chrome.storage.onChanged&&chrome.storage.onChanged.addListener((e,o)=>{o==="local"&&(e.vnpost_session||e.activeShopName||e.activeShop||e.currentUser)&&re()})}catch{}Ge(I,n.getElementById("vnpost-panel-header"));const Q=n.getElementById("vnpost-btn-dock-toggle");D.addEventListener("click",e=>{e.stopPropagation(),Pe(I,D,Q,"docked",{collapsed:!1}),ye.set({panel_display_mode:"docked",panel_dock_collapsed:!1,panelMinimized:!1})}),ye.get(["panel_display_mode","panel_dock_collapsed","panel_float_position","panelMinimized","antigravity_ui_theme"],(e={})=>{const o=e.panel_display_mode==="floating"?"floating":"docked",a=!!(e.panel_dock_collapsed||e.panel_display_mode===void 0&&e.panelMinimized);if(o==="floating"&&e.panelMinimized&&I.classList.add("minimized"),Pe(I,D,Q,o,{collapsed:a,position:e.panel_float_position}),e.antigravity_ui_theme!==void 0)if(e.antigravity_ui_theme==="dark"){I.classList.remove("light-mode");try{localStorage.setItem("antigravity_ui_theme","dark")}catch{}}else{I.classList.add("light-mode");try{localStorage.setItem("antigravity_ui_theme","light")}catch{}}}),n.getElementById("btnParseOrder").addEventListener("click",s),n.getElementById("btnClearOrder").addEventListener("click",v),n.getElementById("btnFillVNPost").addEventListener("click",function(){u("vnpost")}),n.getElementById("btnFillJT").addEventListener("click",function(){u("jt")});const F=n.getElementById("panel-account-trigger"),ae=n.getElementById("panel-account-menu"),be=()=>{!ae||!F||(ae.hidden=!0,F.setAttribute("aria-expanded","false"))};F==null||F.addEventListener("click",e=>{e.stopPropagation(),ae.hidden=!ae.hidden,F.setAttribute("aria-expanded",String(!ae.hidden))}),(O=n.getElementById("panel-menu-settings"))==null||O.addEventListener("click",()=>{be(),typeof l=="function"&&l()}),(r=n.getElementById("panel-menu-logout"))==null||r.addEventListener("click",async()=>{be(),typeof AuthService<"u"&&typeof AuthService.logout=="function"&&(await AuthService.logout(),typeof globalThis.checkUrlAndInject=="function"&&globalThis.checkUrlAndInject())}),document.addEventListener("pointerdown",be),(d=n.getElementById("panel-fix-information"))==null||d.addEventListener("click",()=>{var e;(e=n.querySelector(".review-editable.is-invalid"))==null||e.focus()});const _e=e=>String(e||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim(),C=async e=>{if(typeof AuthSession>"u"||typeof AuthSession.getSession!="function"||typeof SupabaseCloud>"u")return null;const o=await AuthSession.getSession().catch(()=>null),a=await SupabaseCloud.loadConfig().catch(()=>null);if(!(o!=null&&o.active_shop_id)||!(o!=null&&o.access_token)||!(a!=null&&a.url)||!(a!=null&&a.anonKey))return null;const i=String(e||"").replace(/\D/g,"").replace(/^84(?=\d{9}$)/,"0");if(i.length<9)return null;const E={apikey:a.anonKey,Authorization:`Bearer ${o.access_token}`},$=`${String(a.url).replace(/\/$/,"")}/rest/v1`,J=new AbortController,B=setTimeout(()=>J.abort(),1200);try{const ee=await fetch(`${$}/rpc/customer_hub_lookup`,{method:"POST",headers:{...E,"Content-Type":"application/json"},body:JSON.stringify({p_shop_id:o.active_shop_id,p_phone:i}),signal:J.signal});if(!ee.ok)return null;const ne=await ee.json();if(!ne)return{customer:null,orders:[],addresses:[]};const[Ie,Se]=await Promise.all([fetch(`${$}/customer_order_links?shop_id=eq.${encodeURIComponent(o.active_shop_id)}&customer_id=eq.${ne.id}&order=ordered_at.desc&limit=5&select=*`,{headers:E,signal:J.signal}),fetch(`${$}/customer_addresses?shop_id=eq.${encodeURIComponent(o.active_shop_id)}&customer_id=eq.${ne.id}&order=successful_delivery_count.desc,last_used_at.desc&limit=3&select=*`,{headers:E,signal:J.signal})]);return{customer:ne,orders:Ie.ok?await Ie.json():[],addresses:Se.ok?await Se.json():[]}}catch{return null}finally{clearTimeout(B)}},X=async e=>{const o=n.getElementById("customer-history-card"),a=n.getElementById("customer-history-result"),i=n.getElementById("customer-history-count");if(!o||!a)return;o.hidden=!1;const E=String(e||"").trim();if(!E){a.textContent="Nhập tên hoặc SĐT để tra cứu lịch sử đã lên đơn.",i&&(i.textContent="");return}a.textContent="Đang tra cứu...";const $=E.replace(/\D/g,""),J=_e(E),B=await C(E);if(B!=null&&B.customer){const R=B.customer,oe=Number(R.total_orders||B.orders.length||0);i&&(i.textContent=String(oe),i.hidden=!1,i.setAttribute("aria-label",`${oe} đơn`)),a.replaceChildren();const fe=document.createElement("strong");fe.textContent=`${R.name||"Khách hàng"} · ${R.normalized_phone||R.phone||""}`,a.appendChild(fe);const ke=document.createElement("div");ke.className=`customer-history-summary risk-${R.risk_level||"safe"}`;const Et={vip:"VIP",repeat:"Khách quen",churn_risk:"Ngủ đông",risk:"Cần kiểm tra",new:"Khách mới"};if(ke.textContent=`${Et[R.segment]||"Khách hàng"} · LTV ${Number(R.total_spent||R.total_cod||0).toLocaleString("vi-VN")} đ${R.is_blacklisted?` · CẢNH BÁO: ${R.blacklist_reason||"Danh sách đen"}`:""}`,a.appendChild(ke),B.orders.length){const me=document.createElement("div");me.className="customer-history-orders",B.orders.forEach(se=>{const ve=document.createElement("div");ve.className="customer-history-order";const ue=document.createElement("span");ue.className="customer-history-order-code",ue.textContent=`Mã đơn: ${se.order_code||se.source_order_id||"Không có mã"}${se.tracking_code?` · ${se.tracking_code}`:""}`;const Ee=document.createElement("span");Ee.className="customer-history-order-address",Ee.textContent=`${Number(se.cod_amount||0).toLocaleString("vi-VN")} đ · ${se.carrier||""} · ${se.status||""}`,ve.append(ue,Ee),me.appendChild(ve)}),a.appendChild(me)}if(B.addresses.length){const me=document.createElement("div");me.className="customer-history-addresses";const se=document.createElement("span");se.className="customer-history-address-title",se.textContent="Địa chỉ từng giao — bấm để áp dụng",me.appendChild(se),B.addresses.forEach(ve=>{const ue=document.createElement("button");ue.type="button",ue.className="customer-history-address-option",ue.textContent=`${ve.raw_address} · ${ve.use_count||1} lần`,ue.addEventListener("click",()=>{const Ee=ve.raw_address||ve.normalized_address;if(!Ee)return;const yt=n.getElementById("rev-address");yt&&(yt.textContent=Ee),globalThis.parsedDataStore&&(globalThis.parsedDataStore.address=Ee),typeof showVnpostToast=="function"&&showVnpostToast("Đã áp dụng địa chỉ lịch sử theo lựa chọn của bạn.","success")}),me.appendChild(ue)}),a.appendChild(me)}return}if(B&&!B.customer){i&&(i.textContent="",i.hidden=!0),a.textContent="Chưa có hồ sơ khách hàng trong Sổ bạ.";return}if(typeof OrderStorage>"u"||typeof OrderStorage.getSubmittedOrders!="function"){a.textContent="Không thể kết nối Sổ bạ; việc bóc tách và nhập đơn vẫn hoạt động.";return}const ne=(await OrderStorage.getSubmittedOrders().catch(()=>[])||[]).filter(R=>{const oe=String(R.phone||"").replace(/\D/g,""),fe=_e(R.name||R.customer_name||"");return $.length>=3?oe===$||oe.endsWith($):J.length>=2&&fe.includes(J)}).sort((R,oe)=>new Date(oe.submittedAt||oe.createdAt||0)-new Date(R.submittedAt||R.createdAt||0));if(i&&(i.textContent=String(ne.length),i.hidden=ne.length===0,i.setAttribute("aria-label",`${ne.length} đơn thành công`)),!ne.length){a.textContent="Chưa tìm thấy đơn đã gửi của khách hàng này.";return}a.replaceChildren();const Ie=document.createElement("strong");Ie.textContent=`${ne[0].name||ne[0].customer_name||"Khách hàng"} · ${ne[0].phone||"Không có SĐT"}`,a.appendChild(Ie);const Se=document.createElement("div");Se.className="customer-history-orders",ne.slice(0,5).forEach(R=>{const oe=document.createElement("div");oe.className="customer-history-order";const fe=document.createElement("span");fe.className="customer-history-order-code",fe.textContent=`Mã đơn: ${R.orderCode||R.order_code||R.trackingCode||"Không có mã"}`;const ke=document.createElement("span");ke.className="customer-history-order-address",ke.textContent=R.address||"Chưa lưu địa chỉ giao hàng",oe.append(fe,ke),Se.appendChild(oe)}),a.appendChild(Se)};globalThis.lookupPanelCustomerHistory=X;const j=n.getElementById("customer-history-search");(T=n.getElementById("customer-history-search-btn"))==null||T.addEventListener("click",()=>X(j==null?void 0:j.value)),j==null||j.addEventListener("keydown",e=>{e.key==="Enter"&&(e.preventDefault(),X(j.value))});const U=n.getElementById("address-accordion-btn"),le=n.getElementById("address-accordion-content");U&&le&&U.addEventListener("click",e=>{e.stopPropagation();const o=le.style.display!=="none";le.style.display=o?"none":"flex",U.classList.toggle("open",!o)});const ie=n.getElementById("btn-switch-clean"),de=n.getElementById("btn-switch-2level"),We=e=>{const o=e?"rev-suggest-2level":"rev-suggest-clean",a=n.getElementById(o),i=a?a.textContent.trim():"";i&&typeof x=="function"&&(x(i),ie&&de&&(ie.classList.toggle("active",!e),de.classList.toggle("active",e)),showVnpostToast(e?"🎯 Đã chọn địa chỉ 2 cấp mới":"✨ Đã chọn địa chỉ 3 cấp đầy đủ","success"))};ie&&ie.addEventListener("click",e=>{e.stopPropagation(),We(!1)}),de&&de.addEventListener("click",e=>{e.stopPropagation(),We(!0)}),n.querySelectorAll(".address-reference-option").forEach(e=>{e.addEventListener("click",o=>{o.stopPropagation(),We(e.dataset.addressFormat==="2level")})}),n.querySelectorAll(".copy-btn").forEach(e=>{e.addEventListener("click",o=>{o.stopPropagation();const a=e.getAttribute("data-copy"),i=a?n.getElementById(a):null;if(i){const E=i.textContent.trim();E&&navigator.clipboard.writeText(E).then(()=>{const $=e.innerHTML;e.innerHTML=N.check,setTimeout(()=>{e.innerHTML=$},1500),showVnpostToast("📋 Đã sao chép: "+E.substring(0,40)+(E.length>40?"...":""),"success")}).catch(()=>{showVnpostToast("❌ Không thể sao chép","error")})}})}),typeof b=="function"&&n.getElementById("btnSaveOrder").addEventListener("click",b),typeof l=="function"&&n.getElementById("vnpost-btn-settings").addEventListener("click",l),Q&&Q.addEventListener("click",e=>{e.stopPropagation();const o=I.classList.contains("panel-docked")?"floating":"docked",a=o==="floating"?{top:Math.max(20,I.offsetTop||20),left:Math.max(20,window.innerWidth-400)}:null;Pe(I,D,Q,o,{collapsed:!1,position:a}),ye.set({panel_display_mode:o,panel_dock_collapsed:!1,panelMinimized:!1,...a?{panel_float_position:a}:{}})});const nt=n.getElementById("vnpost-btn-theme");nt&&nt.addEventListener("click",e=>{e.stopPropagation();const o=I.classList.toggle("light-mode");Ue(o),showVnpostToast(o?"☀️ Đã chuyển sang giao diện Sáng":"🌙 Đã chuyển sang giao diện Tối","success")});const G=n.getElementById("rawOrderText"),he=n.getElementById("vnpost-draft-queue"),Me=n.getElementById("draft-queue-badge"),Ve=n.getElementById("draft-queue-mini-summary"),Te=n.getElementById("btn-draft-queue-toggle-collapse"),ot=n.getElementById("draft-current-index"),at=n.getElementById("draft-current-summary"),He=n.getElementById("btn-draft-prev"),qe=n.getElementById("btn-draft-next"),it=n.getElementById("btn-draft-load"),st=n.getElementById("btn-draft-fill-next"),rt=n.getElementById("btn-draft-delete"),lt=n.getElementById("btn-draft-clear-all"),dt=n.getElementById("btn-draft-queue-clear");let H=[],W=0,Z=!1;async function ge(){var e,o,a;if(he)try{let i=!0;try{if(typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)){const B=await new Promise(ee=>chrome.storage.local.get(["draft_queue_enabled","draft_queue_collapsed"],ee));B&&B.draft_queue_enabled!==void 0&&(i=!!B.draft_queue_enabled),B&&B.draft_queue_collapsed!==void 0&&(Z=!!B.draft_queue_collapsed)}else{const B=localStorage.getItem("draft_queue_enabled");B!==null&&(i=B==="true");const ee=localStorage.getItem("draft_queue_collapsed");ee!==null&&(Z=ee==="true")}}catch{}if(typeof OrderStorage>"u"||typeof OrderStorage.getOrders!="function")return;typeof OrderStorage._invalidateOrdersCache=="function"&&OrderStorage._invalidateOrdersCache(),H=(await OrderStorage.getOrders()||[]).filter(B=>B&&!B.submittedAt&&!B.trackingCode&&!B.tracking_code);const $=n.getElementById("header-draft-count-badge");if($&&(H.length>0?($.textContent=String(H.length),$.style.display="inline-flex"):$.style.display="none"),H.length===0){he.style.display="none",Me&&(Me.textContent="0 đơn"),W=0,(o=globalThis.parsedDataStore)!=null&&o.savedOrderId&&(globalThis.parsedDataStore=null,G&&(G.value=""),typeof globalThis.resetSourceOrderCard=="function"&&globalThis.resetSourceOrderCard());return}if(!i){he.style.display="none";return}W>=H.length&&(W=Math.max(0,H.length-1)),he.style.display="flex",Me&&(Me.textContent=`${H.length} đơn`);const J=(a=globalThis.parsedDataStore)==null?void 0:a.savedOrderId;J&&!H.some(B=>B.id===J)&&we(),Ne(),Le()}catch(i){console.warn("refreshDraftQueue error",i)}}He&&He.addEventListener("click",e=>{e.stopPropagation(),W>0&&(W--,Ne(),we())}),qe&&qe.addEventListener("click",e=>{e.stopPropagation(),W<H.length-1&&(W++,Ne(),we())}),it&&it.addEventListener("click",e=>{e.stopPropagation(),we()}),st&&st.addEventListener("click",e=>{e.stopPropagation(),we();const a=(c.id||"vnpost")==="vnpost"?n.getElementById("btnFillVNPost"):n.getElementById("btnFillJT");a&&!a.disabled&&(a.click(),showVnpostToast(`⚡ Đang điền đơn ${W+1}...`,"info"),W<H.length-1&&setTimeout(()=>{W++,Ne(),we()},1200))}),rt&&rt.addEventListener("click",async e=>{var a;if(e.stopPropagation(),!H.length)return;const o=H[W];if(o&&confirm(`Xóa đơn nháp của "${o.name||o.phone||"khách này"}" khỏi hàng đợi?`))try{if(typeof OrderStorage<"u"&&typeof OrderStorage.deleteOrder=="function"){await OrderStorage.deleteOrder(o.id),typeof OrderStorage._invalidateOrdersCache=="function"&&OrderStorage._invalidateOrdersCache(),showVnpostToast("🗑️ Đã xóa 1 đơn khỏi hàng đợi.","success");try{typeof chrome<"u"&&((a=chrome.runtime)!=null&&a.sendMessage)&&chrome.runtime.sendMessage({action:"draftOrdersUpdated",source:"panel"},()=>{chrome.runtime.lastError}),window.dispatchEvent(new CustomEvent("draft-queue-updated"))}catch{}await ge()}}catch(i){showVnpostToast("Lỗi khi xóa đơn: "+i.message,"error")}}),lt&&lt.addEventListener("click",async e=>{var a;if(e.stopPropagation(),!H.length)return;const o=H.length;if(confirm(`Bạn có chắc muốn xóa sạch toàn bộ ${o} đơn nháp khỏi hàng đợi?`))try{if(typeof OrderStorage<"u"){const i=H.map(E=>E.id).filter(Boolean);if(typeof OrderStorage.deleteBulkOrders=="function")await OrderStorage.deleteBulkOrders(i);else if(typeof OrderStorage.deleteOrder=="function")for(const E of i)await OrderStorage.deleteOrder(E);typeof OrderStorage._invalidateOrdersCache=="function"&&OrderStorage._invalidateOrdersCache(),showVnpostToast(`🧹 Đã dọn sạch ${o} đơn nháp khỏi hàng đợi!`,"success");try{typeof chrome<"u"&&((a=chrome.runtime)!=null&&a.sendMessage)&&chrome.runtime.sendMessage({action:"draftOrdersUpdated",source:"panel"},()=>{chrome.runtime.lastError}),window.dispatchEvent(new CustomEvent("draft-queue-updated"))}catch{}await ge()}}catch(i){showVnpostToast("Lỗi khi dọn hàng đợi: "+i.message,"error")}}),Te&&Te.addEventListener("click",async e=>{var o;e.stopPropagation(),Z=!Z,Le();try{typeof chrome<"u"&&((o=chrome.storage)!=null&&o.local)&&await chrome.storage.local.set({draft_queue_collapsed:Z});try{localStorage.setItem("draft_queue_collapsed",String(Z))}catch{}}catch{}}),dt&&dt.addEventListener("click",async e=>{var o;e.stopPropagation();try{typeof chrome<"u"&&((o=chrome.storage)!=null&&o.local)&&await chrome.storage.local.set({draft_queue_enabled:!1});try{localStorage.setItem("draft_queue_enabled","false")}catch{}}catch{}he.style.display="none",showVnpostToast("Đã ẩn Hàng đợi đơn nháp. Bấm biểu tượng 📥 trên thanh tiêu đề để bật lại.","info")});const ct=n.getElementById("vnpost-btn-toggle-draft-queue");ct&&ct.addEventListener("click",async e=>{var o,a;e.stopPropagation();try{if(he.style.display==="none"){typeof chrome<"u"&&((o=chrome.storage)!=null&&o.local)&&await chrome.storage.local.set({draft_queue_enabled:!0,draft_queue_collapsed:!1});try{localStorage.setItem("draft_queue_enabled","true"),localStorage.setItem("draft_queue_collapsed","false")}catch{}Z=!1,showVnpostToast("✅ Đã BẬT Hàng đợi đơn nháp","info"),await ge()}else{Z=!Z,Le(),typeof chrome<"u"&&((a=chrome.storage)!=null&&a.local)&&await chrome.storage.local.set({draft_queue_collapsed:Z});try{localStorage.setItem("draft_queue_collapsed",String(Z))}catch{}showVnpostToast(Z?"▾ Đã thu gọn hàng đợi":"▴ Đã mở rộng hàng đợi","info")}}catch(i){console.warn("Lỗi toggle draft queue",i)}}),typeof chrome<"u"&&chrome.storage&&chrome.storage.onChanged&&chrome.storage.onChanged.addListener((e,o)=>{o==="local"&&Object.keys(e).some(i=>i.includes("savedOrders")||i.includes("orders")||i.includes("draft")||i==="vnpost_orders"||i==="draft_queue_updated_at"||i==="draft_queue_enabled"||i==="draft_queue_collapsed")&&(typeof OrderStorage<"u"&&typeof OrderStorage._invalidateOrdersCache=="function"&&OrderStorage._invalidateOrdersCache(),ge())}),window.addEventListener("storage",e=>{e.key&&(e.key.includes("savedOrders")||e.key.includes("orders")||e.key.includes("draft")||e.key==="draft_queue_enabled"||e.key==="draft_queue_collapsed")&&(typeof OrderStorage<"u"&&typeof OrderStorage._invalidateOrdersCache=="function"&&OrderStorage._invalidateOrdersCache(),ge())}),window.addEventListener("draft-queue-updated",()=>{typeof OrderStorage<"u"&&typeof OrderStorage._invalidateOrdersCache=="function"&&OrderStorage._invalidateOrdersCache(),ge()}),typeof chrome<"u"&&chrome.runtime&&chrome.runtime.onMessage&&chrome.runtime.onMessage.addListener(e=>{e&&(e.action==="draftOrdersUpdated"||e.action==="ordersUpdated"||e.action==="refreshDraftQueue")&&(typeof OrderStorage<"u"&&typeof OrderStorage._invalidateOrdersCache=="function"&&OrderStorage._invalidateOrdersCache(),ge())}),setTimeout(ge,500);const te=n.getElementById("source-order-card"),ze=n.getElementById("source-expanded-content"),Ce=n.getElementById("source-collapsed-preview"),pt=n.getElementById("source-preview-primary"),ut=n.getElementById("source-preview-address"),ht=n.getElementById("source-dirty-badge"),gt=n.getElementById("source-dirty-message"),xe=n.getElementById("btn-edit-source");let Fe=!1,ft=!1,Qe=!1,mt={};const Xe=e=>{ft=e,te==null||te.classList.toggle("source-dirty",e),ht&&(ht.style.display=e?"inline-flex":"none"),gt&&(gt.style.display=e?"block":"none");const o=n.querySelector("#btnParseOrder span");o&&(o.textContent=e?"Bóc tách lại":"Tách Đơn Tự Động")},Re=()=>{ze&&(ze.style.display="block"),Ce&&(Ce.style.display="none"),xe&&(xe.style.display="none"),te&&(te.classList.remove("is-collapsed"),te.setAttribute("aria-expanded","true")),window.setTimeout(()=>G==null?void 0:G.focus(),0)},vt=(e={})=>{mt=e;const o=(G==null?void 0:G.value.trim())||"";pt&&(pt.textContent="Nội dung đơn hàng gốc"),ut&&(ut.textContent=o||"Chưa có nội dung"),ze&&(ze.style.display="none"),Ce&&(Ce.style.display="flex"),xe&&(xe.style.display="inline-flex"),te&&(te.classList.add("is-collapsed"),te.setAttribute("aria-expanded","false")),Fe=!0,Xe(!1)};globalThis.collapseSourceOrderCard=vt,globalThis.expandSourceOrderCard=Re,globalThis.resetSourceOrderCard=()=>{Fe=!1,Xe(!1),Re();const e=n.getElementById("review-panel"),o=n.getElementById("panel-empty-state"),a=n.getElementById("panel-validation-error");e&&(e.style.display="none"),o&&(o.hidden=!1),a&&(a.hidden=!0);const i=n.getElementById("customer-history-card");i&&(i.hidden=!0),Ae(null)},Ce==null||Ce.addEventListener("click",Re),xe==null||xe.addEventListener("click",e=>{e.stopPropagation(),Re()}),document.addEventListener("pointerdown",e=>{if(!(!Fe||Qe||(te==null?void 0:te.getAttribute("aria-expanded"))!=="true"||(typeof e.composedPath=="function"?e.composedPath():[]).includes(te))){if(!ft){vt(mt);return}Qe=!0,window.setTimeout(async()=>{try{await s()}finally{Qe=!1}},0)}},!0),G&&(G.addEventListener("focus",()=>{G.style.borderColor=ce,G.style.boxShadow=`0 0 0 3px ${ce}1a`}),G.addEventListener("blur",()=>{G.style.borderColor="rgba(255,255,255,0.08)",G.style.boxShadow="none"}),G.addEventListener("keydown",e=>{(e.ctrlKey||e.metaKey)&&e.key==="Enter"&&(e.preventDefault(),s())}),G.addEventListener("input",()=>{Fe&&Xe(!0)}));const Ye={"rev-name":"name","rev-phone":"phone","rev-code":"orderCode","rev-address":"address","rev-cod":"codAmount"};Object.keys(Ye).forEach(e=>{const o=n.getElementById(e);if(!o)return;const a=()=>{if(typeof y=="function"){const i=Ye[e];let E=o.textContent.trim(),$=E;i==="codAmount"&&($=parseInt(E.replace(/\D/g,""),10)||0),Promise.resolve(y(i,$)).finally(()=>Ae(globalThis.parsedDataStore))}};o.addEventListener("blur",a),o.addEventListener("input",()=>{if(globalThis.parsedDataStore){const i=Ye[e];let E=o.textContent.trim(),$=E;i==="codAmount"&&($=parseInt(E.replace(/\D/g,""),10)||0),globalThis.parsedDataStore[i]=$,Ae(globalThis.parsedDataStore)}}),o.addEventListener("keydown",i=>{i.key==="Enter"&&(i.preventDefault(),o.blur())})});const Ze=n.getElementById("vnpost-btn-minimize");Ze.addEventListener("click",e=>{if(e.stopPropagation(),I.classList.contains("panel-docked")){Pe(I,D,Q,"docked",{collapsed:!0}),ye.set({panel_display_mode:"docked",panel_dock_collapsed:!0,panelMinimized:!1});return}I.classList.add("minimized"),Ze.innerHTML=N.maximize,ye.set({panel_display_mode:"floating",panelMinimized:!0})}),I.addEventListener("click",e=>{I.classList.contains("panel-floating")&&I.classList.contains("minimized")&&(I.classList.remove("minimized"),Ze.innerHTML=N.minimize,ye.set({panel_display_mode:"floating",panelMinimized:!1}))});const pe=n.getElementById("vnpost-api-status");if(pe){let i=function($=!1){return typeof OrderStorage<"u"?OrderStorage.getCacheValue("activeShop")?(pe.innerHTML=N.apiOk,pe.title="AI Gateway: Đã kết nối",a&&(clearInterval(a),a=null),!0):($?(pe.innerHTML=N.apiWarning,pe.title="Chưa chọn Shop — không thể dùng AI"):(pe.innerHTML=N.apiWaiting,pe.title="Đang kiểm tra kết nối AI Gateway..."),!1):(pe.innerHTML=N.apiUnknown,pe.title="Không thể kiểm tra",a&&(clearInterval(a),a=null),!0)};var _=i;let e=0;const o=30;let a=null;i(!1)||(a=setInterval(()=>{e++,(i(e>=o)||e>=o)&&a&&(clearInterval(a),a=null)},300)),typeof chrome<"u"&&chrome.storage&&chrome.storage.onChanged&&chrome.storage.onChanged.addListener(($,J)=>{const B=Object.keys($).some(ee=>ee.startsWith("groqApiKey")||ee.startsWith("activeShop"));J==="local"&&B&&(a&&(clearInterval(a),a=null),i(!0))})}(function(){const o=n.getElementById("panel-device-name");if(typeof FirebaseCloud>"u")return;const a=()=>{try{let i=FirebaseCloud.deviceName||"";if(!i||i==="Máy không tên"||i.startsWith("dev_")){typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id&&chrome.storage&&chrome.storage.local&&chrome.storage.local.get(["fbDeviceName"],E=>{chrome.runtime&&chrome.runtime.lastError||E&&E.fbDeviceName&&E.fbDeviceName!=="Máy không tên"&&!E.fbDeviceName.startsWith("dev_")&&o&&(o.textContent="💻 "+E.fbDeviceName,o.style.display="inline")});return}o&&(o.textContent="💻 "+i,o.style.display="inline")}catch{}};(async()=>{try{if(!FirebaseCloud.isConnected){await FirebaseCloud.signIn();try{await FirebaseCloud.registerDevice()}catch{}}a()}catch{}})(),typeof chrome<"u"&&chrome.storage&&chrome.storage.onChanged.addListener(i=>{i.fbDeviceName&&a()})})()}catch(c){console.error(c)}}function Ge(t,s){if(typeof window>"u"||!t||!s)return;let u=0,v=0,x=0,l=0;t.addEventListener("mousedown",b=>{t.classList.contains("panel-floating")&&t.classList.contains("minimized")&&y(b)}),s.onmousedown=function(b){t.classList.contains("panel-floating")&&(b.target.id==="vnpost-btn-minimize"||b.target.id==="vnpost-btn-settings"||b.target.id==="vnpost-btn-theme"||b.target.id==="vnpost-btn-dock-toggle"||y(b))};function y(b){b=b||window.event;const p=b.clientX,g=b.clientY;let w=!1;x=b.clientX,l=b.clientY,document.onmouseup=function(_){document.onmouseup=null,document.onmousemove=null,w&&t.classList.contains("minimized")&&(_.stopPropagation(),_.preventDefault()),w&&t.classList.contains("panel-floating")&&ye.set({panel_float_position:{top:t.offsetTop,left:t.offsetLeft}})},document.onmousemove=function(_){_=_||window.event,_.preventDefault(),Math.sqrt(Math.pow(_.clientX-p,2)+Math.pow(_.clientY-g,2))>4&&(w=!0),u=x-_.clientX,v=l-_.clientY,x=_.clientX,l=_.clientY;let r=t.offsetTop-v,d=t.offsetLeft-u;const T=window.innerHeight-50,c=window.innerWidth-50;r<0&&(r=0),r>T&&(r=T),d<0&&(d=0),d>c&&(d=c),t.style.top=r+"px",t.style.left=d+"px",t.style.right="auto"}}}function Ae(t){const s=m("order-readiness-bar"),u=m("readiness-text");if(!s||!u)return;const v=[m("btnFillVNPost"),m("btnFillJT")].filter(Boolean),x=m("btnSaveOrder"),l=m("panel-empty-state"),y=m("panel-validation-error"),b=m("panel-validation-checklist"),p=m("panel-validation-message"),g=h=>{v.forEach(S=>{S.disabled=!h}),x&&(x.disabled=!h)};if(!t){s.className="order-readiness-bar readiness-idle",u.textContent="○ Chờ bóc tách nội dung đơn",g(!1),l&&(l.hidden=!1),y&&(y.hidden=!0);return}const w=!!(t.name&&t.name.trim()&&t.name!=="không tìm thấy"),O=(t.phone||"").replace(/\D/g,"").length>=9,r=!!(t.address&&t.address.trim()&&t.address!=="không tìm thấy"),d=!!m("rev-phone-warn"),T=t&&t.rawText||(m("order-raw-input")?m("order-raw-input").value:"");let c=null;typeof OrderValidator<"u"&&typeof OrderValidator.auditCOD=="function"&&(c=OrderValidator.auditCOD(t,T));const P=c?c.canProceed:Number(t.codAmount||0)>0||!!t.codExplicitZero,f=[{label:"Khách hàng",valid:w,target:"rev-name"},{label:"Số điện thoại",valid:O,target:"rev-phone"},{label:"Địa chỉ",valid:r,target:"rev-address"},{label:"COD",valid:P,target:"rev-cod"}],n=f.filter(h=>!h.valid);if(l&&(l.hidden=!0),f.forEach(h=>{var S;return(S=m(h.target))==null?void 0:S.classList.toggle("is-invalid",!h.valid)}),n.length){s.className="order-readiness-bar readiness-error",u.textContent=c&&!P&&n.length===1?c.status==="CRITICAL_MISSING_COD"?"🚨 Đơn thô có COD nhưng chưa nhập COD":"⚠️ Đơn hàng chưa có tiền COD":"⚠ Cần kiểm tra thông tin bắt buộc",g(!1),y&&(y.hidden=!1),b&&(b.innerHTML=f.map(h=>`<span class="${h.valid?"is-valid":"is-missing"}">${h.valid?"✓":"✕"} ${h.label}</span>`).join("")),p&&(c&&c.status==="CRITICAL_MISSING_COD"?p.textContent=`🚨 NGUY HIỂM: Đơn thô có COD ${c.codRaw.toLocaleString("vi-VN")} đ nhưng form đang là 0đ!`:c&&c.status==="NO_COD_WARNING"&&n.length===1?p.textContent="⚠️ Đơn hàng chưa có tiền COD. Vui lòng nhập số tiền hoặc xác nhận đơn 0đ.":p.textContent=n.map(h=>h.label).join(", ")+" chưa được nhận diện.");return}if(y&&(y.hidden=!0),g(!0),d){s.className="order-readiness-bar readiness-warn",u.textContent="⚠️ CẢNH BÁO: SĐT BOM HÀNG";return}w&&O&&r?(s.className="order-readiness-bar readiness-ready",u.textContent="🟢 SẴN SÀNG NHẬP ĐƠN"):!O||!r?(s.className="order-readiness-bar readiness-error",u.textContent="🔴 THIẾU THÔNG TIN: "+(O?"Địa chỉ":"SĐT")):(s.className="order-readiness-bar readiness-warn",u.textContent="🟡 CẦN KIỂM TRA LẠI THÔNG TIN")}function wt(){requestAnimationFrame(()=>{const t=m("rev-name");t&&(t.innerHTML='<span class="skeleton" style="width: 70%; height: 14px;">&nbsp;</span>');const s=m("rev-phone");s&&(s.innerHTML='<span class="skeleton" style="width: 50%; height: 14px;">&nbsp;</span>');const u=m("rev-phone-warn");u&&u.remove();const v=m("rev-code");v&&(v.innerHTML='<span class="skeleton" style="width: 55%; height: 14px;">&nbsp;</span>');const x=m("rev-address");x&&(x.innerHTML='<span class="skeleton" style="width: 90%; height: 14px;">&nbsp;</span>');const l=m("rev-cod");l&&(l.innerHTML='<span class="skeleton" style="width: 40%; height: 18px;">&nbsp;</span>');const y=m("rev-fee");y&&(y.innerHTML='<span class="skeleton" style="width: 35%; height: 14px;">&nbsp;</span>');const b=m("review-panel");b&&(b.style.display="none");const p=m("panel-empty-state"),g=m("panel-validation-error");p&&(p.hidden=!0),g&&(g.hidden=!0),[m("btnFillVNPost"),m("btnFillJT"),m("btnSaveOrder")].filter(Boolean).forEach(O=>{O.disabled=!0});const w=m("order-readiness-bar"),_=m("readiness-text");w&&_&&(w.className="order-readiness-bar readiness-idle",_.textContent="⏳ Đang phân tích dữ liệu...")})}function Ct(t={}){return new Promise(s=>{const{carrierData:u=null,panelData:v=null,orderData:x={},rawText:l="",platform:y="vnpost",onConfirm:b,onCancel:p,onUpdateCOD:g}=t;let w=je();if(!w||w===document){let k=document.getElementById("vnpost-autofill-shadow-host");k&&k.shadowRoot&&(w=k.shadowRoot)}if(!w){s({confirmed:!0,orderData:u||x});return}const _=w.getElementById("af-order-approval-modal");_&&_.remove();const O=u||x||{},r=v||globalThis.parsedDataStore||globalThis.__AF_LAST_FILLED_ORDER__||{};let d={...O},T=!!(d.codExplicitZero||r.codExplicitZero),c=!1;function P(){const k=Number(d.codAmount||0),L=Number(r.codAmount!==void 0?r.codAmount:0),A=!!(r&&(r.name||r.phone||r.codAmount!==void 0||r.orderCode));let M=typeof OrderValidator<"u"&&OrderValidator.readVietnameseCurrency?OrderValidator.readVietnameseCurrency(k):k.toLocaleString("vi-VN")+" đ";return A&&(L>0||r.codExplicitZero)?k===L?{status:"MATCH",level:"success",badge:"✓ KHỚP HOÀN TOÀN",title:"Khớp hoàn toàn với Panel Auto Fill",message:`Tiền COD trên Form Bưu Điện trùng khớp 100% với Panel Auto Fill (${k.toLocaleString("vi-VN")} đ).`,canProceed:!0,suggestedCod:null,codForm:k,codPanel:L,spelledOutWords:M,hasPanelData:!0}:{status:"MISMATCH",level:"danger",badge:"🚨 LỆCH TIỀN COD",title:"CẢNH BÁO LỆCH TIỀN COD",message:`Trên Form Bưu Điện đang là ${k.toLocaleString("vi-VN")} đ, nhưng trên Panel Auto Fill là ${L.toLocaleString("vi-VN")} đ! Hãy đồng bộ hoặc sửa lại trước khi gửi.`,canProceed:T,suggestedCod:L,codForm:k,codPanel:L,spelledOutWords:M,hasPanelData:!0}:k===0&&!T?{status:"NO_COD_WARNING",level:"warning",badge:"⚠️ CHƯA CÓ TIỀN COD",title:"Đơn hàng chưa có tiền thu hộ (0đ)",message:"Form bưu điện đang có COD = 0đ. Nếu khách đã chuyển khoản trước hoặc quà tặng, hãy bấm Xác nhận đơn 0đ.",canProceed:!1,suggestedCod:L>0?L:null,codForm:0,codPanel:L,spelledOutWords:"Không đồng (0 đ)",hasPanelData:A}:typeof OrderValidator<"u"&&typeof OrderValidator.auditCOD=="function"?{...OrderValidator.auditCOD(d,l,{userConfirmedZero:T}),codPanel:L,hasPanelData:A}:{status:"VALID_MATCH",level:"success",badge:"✓ COD HỢP LỆ",title:"Số tiền COD hợp lệ",message:`Đã nhập tiền COD hợp lệ (${k.toLocaleString("vi-VN")} đ).`,canProceed:!0,suggestedCod:null,codForm:k,codPanel:L,spelledOutWords:M,hasPanelData:A}}function f(k,L,A="text"){const M=String(k||"").trim(),D=String(L||"").trim();if(!M||!D||M==="—"||D==="—"||M==="không tìm thấy"||D==="không tìm thấy")return!0;if(A==="phone"){const V=M.replace(/\D/g,""),z=D.replace(/\D/g,"");return V===z||V.length>=9&&z.length>=9&&(V.endsWith(z)||z.endsWith(V))}if(A==="code")return M.toLowerCase().replace(/[^a-z0-9]/g,"")===D.toLowerCase().replace(/[^a-z0-9]/g,"");if(A==="address"){const V=M.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/đ/g,"d"),z=D.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/đ/g,"d");return V===z||V.includes(z)||z.includes(V)}const Y=M.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/đ/g,"d"),q=D.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/đ/g,"d");return Y===q}function n(k,L,A,M,D=!1){return`
          <div class="af-compare-row ${M?"is-match":"is-mismatch"}">
            <div class="af-compare-row-top">
              <span>${k}</span>
              ${M?'<span class="af-compare-pill-match">✓ Khớp</span>':'<span class="af-compare-pill-mismatch">⚠️ Khác biệt</span>'}
            </div>
            <div class="af-compare-row-grid">
              <div class="af-compare-cell cell-carrier ${D?"highlight-address":""}" title="Form Bưu Điện">${L&&L!=="không tìm thấy"?L:"—"}</div>
              <div class="af-compare-cell cell-panel ${D?"highlight-address":""}" title="Panel Auto Fill">${A&&A!=="không tìm thấy"?A:"—"}</div>
            </div>
          </div>
        `}let h=P();const S=document.createElement("div");S.id="af-order-approval-modal",S.className="af-approval-overlay";function I(){h=P();const k=Oe(y),L=typeof detectCarrierAccount=="function"?detectCarrierAccount(k.id):"",A=d.shopName||(typeof _lastShopName<"u"?_lastShopName:"")||"",M=Number(d.codAmount||0).toLocaleString("vi-VN")+" đ",D=h.hasPanelData?h.codPanel>0?Number(h.codPanel).toLocaleString("vi-VN")+" đ":r.codExplicitZero?"0 đ (Xác nhận)":"0 đ":h.codRaw>0?Number(h.codRaw).toLocaleString("vi-VN")+" đ":"Chưa có",Y=f(d.name,r.name,"name"),q=f(d.phone,r.phone,"phone"),V=f(d.address,r.address,"address"),z=f(d.orderCode,r.orderCode,"code");S.innerHTML=`
          <div class="af-approval-card" role="dialog" aria-modal="true" aria-labelledby="af-approval-title">
            <div class="af-approval-header">
              <div class="af-approval-title-group">
                <h3 id="af-approval-title">🛡️ XÉT DUYỆT & ĐỐI CHIẾU ĐƠN HÀNG</h3>
                <div class="af-approval-meta-row">
                  <span class="af-approval-pill" style="color: ${k.themeColor||"#6366f1"}; border-color: ${k.themeColor||"#6366f1"}40;">${k.title||"Bưu cục"}</span>
                  ${A?`<span class="af-approval-pill">Shop: ${A}</span>`:""}
                  ${L?`<span class="af-approval-pill">Tài khoản: ${L}</span>`:""}
                  ${d.orderCode?`<span class="af-approval-pill">Mã đơn: ${d.orderCode}</span>`:""}
                </div>
              </div>
              <button type="button" class="af-approval-close-btn" id="modal-close-icon-btn" title="Đóng (Esc)">✕</button>
            </div>

            <!-- HERO COD CARD (TIÊU ĐIỂM ĐỐI CHIẾU SỐ 1) -->
            <div class="af-hero-cod level-${h.level}">
              <div class="af-hero-cod-top">
                <span class="af-hero-cod-label">💰 TIỀN THU HỘ (COD) - TIÊU ĐIỂM ĐỐI CHIẾU</span>
                <span class="af-hero-cod-badge">${h.badge}</span>
              </div>

              <div class="af-hero-cod-center">
                <div class="af-hero-cod-amount" id="modal-hero-cod-amount">${M}</div>
                <div class="af-hero-cod-words" id="modal-hero-cod-words">${h.spelledOutWords}</div>
              </div>

              <div class="af-cod-compare-grid">
                <div class="af-cod-compare-col">
                  <span class="af-cod-compare-title">📝 Trên Form Bưu Điện</span>
                  <span class="af-cod-compare-val" style="color: ${h.level==="danger"?"#f87171":h.level==="warning"?"#fbbf24":"#34d399"};">${M}</span>
                </div>
                <div class="af-cod-compare-col">
                  <span class="af-cod-compare-title">⚡ Trên Panel Auto Fill</span>
                  <span class="af-cod-compare-val" style="color: ${h.codPanel>0?"#38bdf8":"#94a3b8"};">${D}</span>
                </div>
              </div>

              <div class="af-cod-alert-box" id="modal-cod-alert-box">
                <span style="font-size: 16px; line-height: 1;">${h.level==="danger"?"🚨":h.level==="warning"?"⚠️":h.level==="info"?"ℹ️":"✓"}</span>
                <div>
                  <strong style="display: block; margin-bottom: 2px;">${h.title}</strong>
                  <span>${h.message}</span>
                </div>
              </div>

              ${c?`
                <div class="af-inline-cod-edit">
                  <input type="text" class="af-inline-cod-input" id="modal-inline-cod-input" placeholder="Nhập số tiền COD (ví dụ: 350000)" value="${d.codAmount||""}" />
                  <button type="button" class="af-quick-btn af-quick-btn-apply" id="modal-inline-cod-save-btn">Lưu số tiền</button>
                  <button type="button" class="af-quick-btn af-quick-btn-edit" id="modal-inline-cod-cancel-btn">Hủy</button>
                </div>
              `:`
                <div class="af-cod-quick-actions">
                  ${h.suggestedCod&&h.suggestedCod>0&&h.suggestedCod!==Number(d.codAmount||0)?`
                    <button type="button" class="af-quick-btn af-quick-btn-apply" id="modal-quick-apply-panel-btn">
                      ⚡ Đồng bộ ${h.suggestedCod.toLocaleString("vi-VN")} đ từ Panel sang Form
                    </button>
                  `:""}

                  ${(Number(d.codAmount||0)===0||h.status==="NO_COD_WARNING")&&!T?`
                    <button type="button" class="af-quick-btn af-quick-btn-zero" id="modal-quick-confirm-zero-btn">
                      ✓ Xác nhận đơn 0đ (Khách đã chuyển khoản / Quà tặng)
                    </button>
                  `:""}

                  <button type="button" class="af-quick-btn af-quick-btn-edit" id="modal-quick-edit-btn">
                    ✏️ Sửa số tiền COD
                  </button>
                </div>
              `}
            </div>

            <!-- BẢNG ĐỐI CHIẾU 2 CỘT CHI TIẾT (FORM BƯU ĐIỆN VS PANEL AUTO FILL) -->
            <div class="af-review-section-title">
              <span>📋</span> BẢNG ĐỐI CHIẾU CHI TIẾT ĐƠN HÀNG (Form bưu điện ⟷ Panel Auto Fill)
            </div>
            <div class="af-compare-container">
              <div class="af-compare-header">
                <div class="af-compare-header-col carrier">
                  <span>🏢</span> Form Bưu Điện (${k.title||"VNPost"})
                </div>
                <div class="af-compare-header-col panel">
                  <span>⚡</span> Panel Auto Fill (Dữ Liệu Nhận Diện)
                </div>
              </div>

              ${n("👤 Họ và tên người nhận",d.name,r.name,Y)}
              ${n("📞 Số điện thoại người nhận",d.phone,r.phone,q)}
              ${n("📍 Địa chỉ giao hàng chi tiết",d.address,r.address,V,!0)}
              
              ${r.province||r.district||r.ward?`
                <div class="af-compare-row is-match">
                  <div class="af-compare-row-top">
                    <span>🗺️ Địa giới hành chính nhận diện (Panel)</span>
                    <span class="af-compare-pill-match">✓ Chuẩn hóa</span>
                  </div>
                  <div class="af-compare-row-grid">
                    <div class="af-compare-cell cell-carrier" style="font-size:12.5px; color:#94a3b8;">Hệ thống bưu điện tự đối chiếu theo địa chỉ giao hàng</div>
                    <div class="af-compare-cell cell-panel">
                      <div class="af-address-breakdown">
                        ${r.province?`<span class="af-address-sub-pill">🏙️ Tỉnh/TP: ${r.province}</span>`:""}
                        ${r.district?`<span class="af-address-sub-pill">🏢 Quận/Huyện: ${r.district}</span>`:""}
                        ${r.ward?`<span class="af-address-sub-pill">🏘️ Phường/Xã: ${r.ward}</span>`:""}
                      </div>
                    </div>
                  </div>
                </div>
              `:""}

              ${d.orderCode||r.orderCode?n("🔖 Mã đơn hàng (SKU Shop)",d.orderCode,r.orderCode,z):""}
              
              ${n("📦 Tên hàng hóa / Bưu kiện",d.goodsName||d.productItem||"Hàng hóa thời trang",r.goodsName||r.productItem||"Hàng hóa thời trang",f(d.goodsName||d.productItem,r.goodsName||r.productItem))}
              
              ${n("⚖️ Khối lượng bưu kiện",d.weightGrams?d.weightGrams+" g":d.weight?d.weight+(Number(d.weight)<50?" kg":" g"):"200 g",r.weightGrams?r.weightGrams+" g":r.weight?r.weight+(Number(r.weight)<50?" kg":" g"):"200 g",!0)}
              
              ${n("💵 Người trả tiền cước vận chuyển",d.collectFee?"Người nhận trả cước":"Shop trả cước",r.collectFee?"Người nhận trả cước":"Shop trả cước",!!d.collectFee==!!r.collectFee)}
              
              ${n("📝 Ghi chú giao hàng / Chỉ dẫn phát",d.notes||d.extraNote||"—",r.notes||r.extraNote||"Cho xem hàng / Không thử",f(d.notes||d.extraNote,r.notes||r.extraNote))}

              ${n("⚡ Nguồn gốc tạo đơn",d.source==="MANUAL"?"✍️ Nhập thủ công":"⚡ Tách đơn AI (Auto Fill)","⚡ Tách đơn AI (Auto Fill)",!0)}
            </div>

            <!-- NỘI DUNG ĐƠN THÔ (ĐỐI CHIẾU MẮT BỔ SUNG) -->
            ${l?`
              <details class="af-raw-preview-details">
                <summary>📄 Xem lại toàn văn nội dung đơn thô gốc để đối chiếu mắt</summary>
                <div class="af-raw-preview-content">${l}</div>
              </details>
            `:""}

            <!-- FOOTER NÚT BẤM TO RÕ RÀNG -->
            <div class="af-modal-actions">
              <button type="button" class="af-modal-btn-cancel" id="modal-cancel-btn">
                ✏️ Quay lại Form bưu điện để sửa (Esc)
              </button>
              <button type="button" class="af-modal-btn-confirm" id="modal-confirm-btn" ${h.canProceed?"":"disabled"} title="${h.canProceed?"Xác nhận tạo đơn và gửi lên bưu điện":"Cần xử lý tiền COD trước khi tạo đơn"}">
                🚀 Xác Nhận Gửi Lên Hệ Thống Bưu Điện (Enter)
              </button>
            </div>
          </div>
        `,ce()}function ce(){const k=S.querySelector("#modal-close-icon-btn"),L=S.querySelector("#modal-cancel-btn"),A=S.querySelector("#modal-confirm-btn"),M=S.querySelector("#modal-quick-edit-btn"),D=S.querySelector("#modal-quick-apply-panel-btn"),Y=S.querySelector("#modal-quick-confirm-zero-btn"),q=S.querySelector("#modal-inline-cod-save-btn"),V=S.querySelector("#modal-inline-cod-cancel-btn"),z=S.querySelector("#modal-inline-cod-input"),re=Q=>{document.removeEventListener("keydown",K,!0),S.remove(),Q?(typeof b=="function"&&b(d),s({confirmed:!0,orderData:d,carrierData:d})):(typeof p=="function"&&p(),s({confirmed:!1,orderData:d,carrierData:d}))};if(k&&(k.onclick=()=>re(!1)),L&&(L.onclick=()=>re(!1)),A&&(A.onclick=()=>{if(!h.canProceed){typeof showVnpostToast=="function"&&showVnpostToast("⚠️ Vui lòng kiểm tra hoặc xác nhận tiền COD trước khi lên đơn!","warning");return}re(!0)}),M&&(M.onclick=()=>{c=!0,I();const Q=S.querySelector("#modal-inline-cod-input");Q&&(Q.focus(),Q.select())}),V&&(V.onclick=()=>{c=!1,I()}),q&&z){const Q=()=>{const F=parseInt(z.value.replace(/\D/g,""),10)||0;d.codAmount=F,F===0?T=!0:T=!1,c=!1,typeof g=="function"&&g(F),I()};q.onclick=Q,z.onkeydown=F=>{F.key==="Enter"?(F.preventDefault(),Q()):F.key==="Escape"&&(F.preventDefault(),c=!1,I())}}D&&h.suggestedCod!==null&&(D.onclick=()=>{d.codAmount=h.suggestedCod,T=h.suggestedCod===0,typeof g=="function"&&g(h.suggestedCod),I(),typeof showVnpostToast=="function"&&showVnpostToast(`✓ Đã đồng bộ COD ${h.suggestedCod.toLocaleString("vi-VN")} đ từ Panel sang Form!`,"success")}),Y&&(Y.onclick=()=>{d.codAmount=0,d.codExplicitZero=!0,T=!0,typeof g=="function"&&g(0),I(),typeof showVnpostToast=="function"&&showVnpostToast("✓ Đã xác nhận đơn 0đ (Khách chuyển khoản/Quà tặng)!","info")})}function K(k){if(k.key==="Escape")k.preventDefault(),k.stopPropagation(),document.removeEventListener("keydown",K,!0),S.remove(),typeof p=="function"&&p(),s({confirmed:!1,orderData:d});else if(k.key==="Enter"&&!k.shiftKey&&!k.ctrlKey&&!k.metaKey){const L=w.activeElement||document.activeElement;if(L&&L.id==="modal-inline-cod-input")return;h.canProceed?(k.preventDefault(),k.stopPropagation(),document.removeEventListener("keydown",K,!0),S.remove(),typeof b=="function"&&b(d),s({confirmed:!0,orderData:d})):typeof showVnpostToast=="function"&&showVnpostToast("⚠️ Vui lòng kiểm tra tiền COD hoặc xác nhận đơn 0đ trước khi lên đơn!","warning")}}document.addEventListener("keydown",K,!0),S.addEventListener("click",k=>{k.target===S&&(document.removeEventListener("keydown",K,!0),S.remove(),typeof p=="function"&&p(),s({confirmed:!1,orderData:d}))}),I(),w.appendChild(S)})}function $e(t){requestAnimationFrame(()=>{const s=m("rev-name");s&&(s.textContent=t.name?t.name.trim():"không tìm thấy");const u=m("rev-phone");u&&(u.textContent=t.phone?t.phone.trim():"không tìm thấy",u.style.color="",u.style.fontWeight="",u.title="");const v=m("rev-phone-warn");if(v&&v.remove(),t.phone){const r=t.phone.replace(/\D/g,"");if(typeof OrderStorage<"u"){const T=(OrderStorage.getCacheValue("blacklistPhones")||[]).find(c=>c.phone===r);if(T&&u){u.style.color="#dc2626",u.style.fontWeight="700",u.title="SĐT nằm trong danh sách đen! Lý do: "+T.reason;const c=document.createElement("span");c.id="rev-phone-warn",c.innerHTML=" "+N.warn,c.style.color="#dc2626",c.style.cursor="help",c.style.display="inline-flex",c.style.alignItems="center",c.title="Lịch sử bom hàng: "+T.reason,u.parentElement.appendChild(c),showVnpostToast("⚠️ CẢNH BÁO: Khách hàng này có lịch sử BOM HÀNG! Lý do: "+T.reason,"error")}}}const x=m("rev-code");x&&(x.textContent=t.orderCode?t.orderCode.trim():"Lũa Thuỷ Sinh");const l=m("rev-address");l&&(l.textContent=t.address?t.address.trim():"không tìm thấy");const y=m("rev-raw-address");if(y&&(y.textContent=t.address||"---"),t.addressLevel){const r=m("address-status-badge");r&&(r.textContent=t.addressLevel===2?"🎯 Địa chỉ 2 Cấp":"✓ Đã tối ưu",r.title=t.addressLevel===2?"Địa chỉ được nhận diện theo chuẩn 2 cấp (không chèn quận).":"Địa chỉ chuẩn hóa 3 cấp đầy đủ.");const d=m("btn-switch-clean"),T=m("btn-switch-2level");d&&T&&(d.classList.toggle("active",t.addressLevel!==2),T.classList.toggle("active",t.addressLevel===2))}const b=m("rev-cod"),p=m("rev-cod-status"),g=t&&t.rawText||(m("order-raw-input")?m("order-raw-input").value:"");let w=null;typeof OrderValidator<"u"&&typeof OrderValidator.auditCOD=="function"&&(w=OrderValidator.auditCOD(t,g)),b&&(b.textContent=t.codAmount?Number(t.codAmount).toLocaleString("vi-VN")+" đ":"0 đ",w&&(w.status==="CRITICAL_MISSING_COD"?b.style.color="#ef4444":w.status==="NO_COD_WARNING"||w.status==="MISMATCH"?b.style.color="#f59e0b":w.status==="EXPLICIT_ZERO"?b.style.color="#0284c7":b.style.color="#10b981")),p&&(w?(p.textContent=w.badge,p.title=w.message,p.className="cod-status-badge "+(w.level==="danger"?"cod-badge-danger":w.level==="warning"?"cod-badge-warning":w.level==="info"?"cod-badge-info":"cod-badge-success")):p.textContent=t.codAmount&&t.codAmount>0?"✓ COD hợp lệ":"⚠️ Chưa có COD");const _=m("rev-fee");if(_){const r=!!t.collectFee;_.textContent=r?"CÓ":"KHÔNG",_.classList.toggle("fee-status--yes",r),_.classList.toggle("fee-status--no",!r)}const O=m("review-panel");O&&(O.style.display="flex"),Ae(t),typeof globalThis.lookupPanelCustomerHistory=="function"&&globalThis.lookupPanelCustomerHistory(t.phone||t.name||""),tt(t)})}async function tt(t){const s=m("panel-duplicate-alert");if(!s)return null;if(!t||!t.orderCode&&!t.phone)return s.style.display="none",null;try{if(typeof OrderStorage>"u"||typeof OrderStorage.getSubmittedOrders!="function")return s.style.display="none",null;const u=await OrderStorage.getSubmittedOrders().catch(()=>[]);if(!Array.isArray(u)||u.length===0)return s.style.display="none",null;const v=new Date().toISOString().slice(0,10),x=new Date().toLocaleDateString("vi-VN"),l=String(t.orderCode||"").trim().toLowerCase(),y=String(t.phone||"").replace(/\D/g,""),b=String(t.name||"").trim().toLowerCase();let p=null;for(const g of u){const w=g.submittedAt||g.createdAt||g.updatedAt||"";let _=!1;if(w){const n=new Date(w).toISOString().slice(0,10),h=new Date(w).toLocaleDateString("vi-VN");(n===v||h===x)&&(_=!0)}else _=!0;if(!_)continue;const O=String(g.orderCode||g.order_code||"").trim().toLowerCase(),r=String(g.phone||"").replace(/\D/g,""),d=String(g.name||g.customer_name||"").trim().toLowerCase();if(!!(l&&l!=="—"&&l!=="-"&&O&&O!=="—"&&O!=="-")&&l!==O)continue;const c=!!(l&&l!=="—"&&l!=="-"&&O&&l===O),P=!!(y&&y.length>=9&&r&&y===r);if(c||P||!!(y&&b&&y===r&&b===d)){p={order:g,matchCode:c,matchPhone:P,trackingCode:g.trackingCode||g.tracking_code||"",carrierAccount:g.carrierAccount||g.carrier_account||"",orderCode:g.orderCode||g.order_code||"",customerName:g.name||g.customer_name||"",phone:g.phone||"",submittedTime:w?new Date(w).toLocaleTimeString("vi-VN",{hour:"2-digit",minute:"2-digit"}):"Hôm nay"};break}}if(p){const g=m("panel-duplicate-time"),w=m("panel-duplicate-message"),_=m("panel-duplicate-details");g&&(g.textContent=`Lên đơn lúc ${p.submittedTime}`);let O="";return p.matchCode&&p.matchPhone?O=`Trùng mã đơn hàng <strong>${p.orderCode}</strong> và SĐT <strong>${p.phone}</strong>`:p.matchCode?O=`Trùng mã đơn hàng <strong>${p.orderCode}</strong>`:O=`Trùng người nhận/SĐT <strong>${p.phone}</strong> (${p.customerName||"Khách hàng"})`,w&&(w.innerHTML=`⚠️ Đơn này đã được lên đơn thành công hôm nay! (${O})`),_&&(_.innerHTML=`
            ${p.orderCode?`<span class="duplicate-detail-tag">Mã đơn: <strong>${p.orderCode}</strong></span>`:""}
            ${p.customerName?`<span class="duplicate-detail-tag">Khách: <strong>${p.customerName}</strong></span>`:""}
            ${p.trackingCode?`<span class="duplicate-detail-tag">Mã VĐ: <code class="duplicate-detail-code">${p.trackingCode}</code></span>`:""}
            ${p.carrierAccount?`<span class="duplicate-detail-tag">Người gửi: <strong>${p.carrierAccount}</strong></span>`:""}
          `),s.style.display="flex",showVnpostToast(`⚠️ CẢNH BÁO: Đơn (${p.orderCode||p.phone}) đã được lên hôm nay lúc ${p.submittedTime}${p.trackingCode?` (Mã VĐ: ${p.trackingCode})`:""}!`,"warning",6e3),p}else return s.style.display="none",null}catch(u){return console.warn("[checkAndDisplayDuplicateAlert] Error:",u),s.style.display="none",null}}globalThis.getVnpostPanelRoot=je,globalThis.getVnpostEl=m,globalThis.createInputPanel=et,globalThis.showPanelSkeleton=wt,globalThis.displayParsedData=$e,globalThis.checkAndDisplayDuplicateAlert=tt;function xt(t,s){try{if(typeof document>"u")return;De(!1);const u=Oe(t);let v=document.getElementById("vnpost-autofill-shadow-host");const x=v?m("vnpost-autofill-panel"):null;if(x&&x.dataset&&x.dataset.panelType==="login")return;v||(v=document.createElement("div"),v.id="vnpost-autofill-shadow-host",document.body.appendChild(v));const l=v.shadowRoot||v.attachShadow({mode:"open"}),y=l.querySelector("#vnpost-autofill-panel");y&&y.remove();const b=l.querySelector("#vnpost-dock-toggle-tab");if(b&&b.remove(),!l.querySelector("#vnpost-shadow-style")){const C=document.createElement("style");C.id="vnpost-shadow-style",C.textContent=typeof PANEL_CSS<"u"?PANEL_CSS:"",l.appendChild(C)}const p=document.createElement("div");if(p.id="vnpost-autofill-panel",p.dataset.panelType="login",p.classList.add("panel-floating"),Ke(p),typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id&&chrome.storage&&chrome.storage.local)try{chrome.storage.local.get(["antigravity_ui_theme"],C=>{if(!chrome.runtime.lastError){if(C&&C.antigravity_ui_theme==="dark"){p.classList.remove("light-mode");try{localStorage.setItem("antigravity_ui_theme","dark")}catch{}}else if(C&&C.antigravity_ui_theme==="light"){p.classList.add("light-mode");try{localStorage.setItem("antigravity_ui_theme","light")}catch{}}}})}catch{}const g=u.themeColor||(u.id==="vnpost"?"#0056b3":"#4f46e5");p.style.setProperty("--theme-color",g);let w="v1";try{typeof chrome<"u"&&chrome.runtime&&chrome.runtime.getManifest&&(w="v"+(chrome.runtime.getManifest().version||"1"))}catch{}p.innerHTML=`
        <div class="minimized-icon">${N.user}</div>
        <div id="vnpost-panel-header">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span id="vnpost-panel-header-text"></span>
            <span class="badge-version">${w} (Xác thực)</span>
          </div>
          <div style="display: flex; align-items: center; gap: 6px;">
            <button id="vnpost-btn-theme" title="Chuyển chế độ Sáng/Tối">${N.theme}</button>
            <button id="vnpost-btn-minimize">${N.minimize}</button>
          </div>
        </div>

        <div id="vnpost-panel-body">
          <div class="panel-login-box">
            <div class="panel-login-title">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="color: var(--theme-color, #16a34a);"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
              Đăng Nhập Máy Trạm
            </div>
            
            <!-- TABS CHỌN ĐĂNG NHẬP -->
            <div class="panel-login-tabs">
              <button type="button" id="panel-tab-btn-pin" class="panel-login-tab active">🔑 Nhân Viên (PIN)</button>
              <button type="button" id="panel-tab-btn-owner" class="panel-login-tab">👑 Chủ Shop / Admin</button>
            </div>

            <div id="panel-login-subtitle" class="panel-login-subtitle">
              Xác thực nhanh bằng mã PIN 6 số cho nhân viên
            </div>

            <div id="panel-login-error" class="panel-login-error"></div>

            <!-- CONTAINER 1: NHÂN VIÊN PIN -->
            <div id="panel-pin-container">
              <!-- View 1.1: Máy Tin Cậy (Chỉ gõ 6 số PIN) -->
              <form id="panel-trusted-pin-form" style="display: none; flex-direction: column; gap: 10px;">
                <div style="background: rgba(0,0,0,0.04); border: 1px solid var(--input-border, #cbd5e1); border-radius: 8px; padding: 8px 10px; display: flex; align-items: center; justify-content: space-between;">
                  <div>
                    <div id="panel-trusted-staff-name" style="font-weight: 700; font-size: 12px; color: var(--text-primary, #0f172a);">Nhân viên</div>
                    <div id="panel-trusted-shop-name" style="font-size: 10.5px; color: var(--text-muted, #64748b);">Shop: LTS</div>
                  </div>
                  <button type="button" id="panel-btn-switch-account" style="background: none; border: none; color: #16a34a; font-size: 11px; font-weight: 700; cursor: pointer;">Đổi</button>
                </div>

                <div class="panel-login-group">
                  <label class="panel-login-label" style="text-align: center;">Nhập mã PIN 6 số vào ca</label>
                  <input type="password" id="panel-input-trusted-pin" class="panel-login-input" maxlength="6" inputmode="numeric" pattern="[0-9]*" placeholder="• • • • • •" required autocomplete="off" style="font-size: 18px; text-align: center; letter-spacing: 8px; font-weight: 800;" />
                </div>

                <button type="submit" id="panel-btn-submit-trusted-pin" class="panel-login-btn">
                  Đăng Nhập Vào Ca
                </button>
              </form>

              <!-- View 1.2: Máy Mới (Nhập Shop Code + Username + PIN tùy chọn) -->
              <form id="panel-new-pin-form" style="display: flex; flex-direction: column; gap: 8px;">
                <div class="panel-login-group">
                  <label class="panel-login-label" for="panel-input-shopcode">Mã Cửa Hàng (Shop Code / Key)</label>
                  <input type="text" id="panel-input-shopcode" class="panel-login-input" placeholder="VD: SHOPLA, KEY-SHOP-..." required autocomplete="off" style="font-weight: 700; text-transform: uppercase;" />
                </div>

                <div class="panel-login-group">
                  <label class="panel-login-label" for="panel-input-loginname">Tên của bạn / Tên nhân viên</label>
                  <input type="text" id="panel-input-loginname" class="panel-login-input" placeholder="VD: Tài, Kho 1, Hằng Sales..." required autocomplete="username" />
                </div>

                <div class="panel-login-group">
                  <label class="panel-login-label" for="panel-input-pin">Mã PIN 6 Số (Tùy chọn)</label>
                  <input type="password" id="panel-input-pin" class="panel-login-input" maxlength="6" inputmode="numeric" pattern="[0-9]*" placeholder="6 chữ số PIN (nếu có)" autocomplete="off" style="letter-spacing: 4px; font-weight: 700;" />
                </div>

                <div class="panel-login-group">
                  <label class="panel-login-label" for="panel-input-devicename">Tên Máy Trạm Này</label>
                  <input type="text" id="panel-input-devicename" class="panel-login-input" placeholder="VD: Chrome Profile 1, Máy bàn..." />
                </div>

                <button type="submit" id="panel-btn-submit-new-pin" class="panel-login-btn" style="margin-top: 4px;">
                  🚀 Vào Ca Lên Đơn (1-Click)
                </button>
              </form>

              <!-- View 1.3: Chờ Chủ Shop Duyệt Máy -->
              <div id="panel-pending-approval-box" style="display: none; text-align: center; padding: 12px 6px;">
                <div style="font-size: 24px; margin-bottom: 6px;">⏳</div>
                <div style="font-weight: 700; font-size: 13px; color: #b45309; margin-bottom: 4px;">Thiết Bị Đang Chờ Phê Duyệt</div>
                <div style="font-size: 11px; color: var(--text-muted, #64748b); line-height: 1.4; margin-bottom: 12px;">
                  Vui lòng liên hệ Chủ Shop duyệt máy trong mục <strong>Quản Lý Thiết Bị</strong>.
                </div>
                <button type="button" id="panel-btn-check-pending" class="panel-login-btn" style="background: #16a34a; margin-bottom: 6px;">
                  🔄 Kiểm tra lại trạng thái duyệt
                </button>
                <button type="button" id="panel-btn-pending-switch" style="background: none; border: 1px solid var(--input-border, #cbd5e1); color: var(--text-muted, #64748b); border-radius: 6px; padding: 6px; width: 100%; font-size: 11px; font-weight: 600; cursor: pointer;">
                  Đăng nhập Shop khác
                </button>
              </div>
            </div>

            <!-- CONTAINER 2: CHỦ SHOP / ADMIN -->
            <form id="panel-owner-form" style="display: none; flex-direction: column; gap: 10px;">
              <div class="panel-login-group">
                <label class="panel-login-label" for="panel-input-owner-email">Email hoặc Tên đăng nhập</label>
                <input type="text" id="panel-input-owner-email" class="panel-login-input" placeholder="admin@shop.com" autocomplete="username" />
              </div>

              <div class="panel-login-group">
                <label class="panel-login-label" for="panel-input-owner-password">Mật khẩu</label>
                <input type="password" id="panel-input-owner-password" class="panel-login-input" placeholder="••••••••" autocomplete="current-password" />
              </div>

              <button type="submit" id="panel-btn-submit-owner" class="panel-login-btn" style="margin-top: 4px;">
                🔑 Đăng Nhập Quản Trị
              </button>
            </form>

            <div class="panel-login-footer" style="display:flex;flex-direction:column;gap:4px;margin-top:6px;">
              <a id="panel-link-register" class="panel-login-link">⚙️ Mở Options (Cài đặt / Quản lý)</a>
              <a id="panel-link-admin-login" class="panel-login-link" style="font-size:11px;">🌐 Mở Trang Quản Trị</a>
            </div>
          </div>
        </div>
      `,l.appendChild(p);const _=l.getElementById("vnpost-panel-header-text");_&&(_.textContent=u.title||""),Ge(p,l.getElementById("vnpost-panel-header"));const O=l.getElementById("vnpost-btn-theme");O&&O.addEventListener("click",C=>{C.stopPropagation();const X=p.classList.toggle("light-mode");Ue(X),showVnpostToast(X?"☀️ Đã chuyển sang giao diện Sáng":"🌙 Đã chuyển sang giao diện Tối","success")}),l.getElementById("vnpost-btn-minimize").addEventListener("click",()=>{p.classList.toggle("minimized")});const r=l.getElementById("panel-tab-btn-pin"),d=l.getElementById("panel-tab-btn-owner"),T=l.getElementById("panel-pin-container"),c=l.getElementById("panel-owner-form"),P=l.getElementById("panel-login-subtitle"),f=l.getElementById("panel-login-error"),n=l.getElementById("panel-trusted-pin-form"),h=l.getElementById("panel-new-pin-form"),S=l.getElementById("panel-pending-approval-box"),I=l.getElementById("panel-trusted-staff-name"),ce=l.getElementById("panel-trusted-shop-name"),K=l.getElementById("panel-input-trusted-pin"),k=l.getElementById("panel-btn-switch-account"),L=l.getElementById("panel-input-shopcode"),A=l.getElementById("panel-input-loginname"),M=l.getElementById("panel-input-pin"),D=l.getElementById("panel-input-devicename"),Y=l.getElementById("panel-btn-check-pending"),q=l.getElementById("panel-btn-pending-switch"),V=l.getElementById("panel-input-owner-email"),z=l.getElementById("panel-input-owner-password"),re=l.getElementById("panel-link-register"),Q=l.getElementById("panel-link-admin-login");let F="",ae="";const be=()=>{typeof chrome<"u"&&chrome.storage&&chrome.storage.local&&chrome.storage.local.get(["last_shop_code","last_login_name","staff_name","shop_name","fbDeviceName","device_pending_approval"],C=>{if(F=(C==null?void 0:C.last_shop_code)||"",ae=(C==null?void 0:C.last_login_name)||"",C!=null&&C.device_pending_approval&&F){S&&(S.style.display="block"),n&&(n.style.display="none"),h&&(h.style.display="none");return}F&&ae?(I&&(I.textContent=C.staff_name||ae),ce&&(ce.textContent="Shop: "+(C.shop_name||F)),n&&(n.style.display="flex"),h&&(h.style.display="none"),S&&(S.style.display="none"),K&&K.focus()):(n&&(n.style.display="none"),h&&(h.style.display="flex"),S&&(S.style.display="none"))})};be(),r&&d&&(r.addEventListener("click",()=>{r.classList.add("active"),d.classList.remove("active"),T&&(T.style.display="block"),c&&(c.style.display="none"),P&&(P.textContent="Xác thực nhanh bằng mã PIN 6 số cho nhân viên."),f&&(f.style.display="none"),be()}),d.addEventListener("click",()=>{d.classList.add("active"),r.classList.remove("active"),T&&(T.style.display="none"),c&&(c.style.display="flex"),P&&(P.textContent="Đăng nhập tài khoản Chủ shop / Quản lý với Email và Mật khẩu."),f&&(f.style.display="none")}));const _e=C=>{C&&C.preventDefault(),n&&(n.style.display="none"),S&&(S.style.display="none"),h&&(h.style.display="flex"),f&&(f.style.display="none"),L&&L.focus()};k&&k.addEventListener("click",_e),q&&q.addEventListener("click",_e),n&&(n.addEventListener("submit",async C=>{C.preventDefault();const X=((K==null?void 0:K.value)||"").trim();if(!X||X.length!==6){f&&(f.textContent="⚠️ Vui lòng nhập đúng mã PIN gồm 6 chữ số!",f.style.display="block");return}f&&(f.style.display="none");const j=l.getElementById("panel-btn-submit-trusted-pin");j&&(j.disabled=!0,j.innerHTML="⏳ Đang vào ca...");try{if(typeof AuthService<"u"&&typeof AuthService.loginWithPin=="function")await AuthService.loginWithPin({shopCode:F,loginName:ae,pin:X}),showVnpostToast("🎉 Đăng nhập ca làm việc thành công!","success"),setTimeout(()=>{const U=typeof globalThis<"u"&&globalThis.checkUrlAndInject||typeof window<"u"&&window.checkUrlAndInject;typeof U=="function"&&U()},80);else throw new Error("Hệ thống xác thực PIN chưa sẵn sàng.")}catch(U){f&&(f.textContent=`❌ ${U.message||"Mã PIN không chính xác!"}`,f.style.display="block")}finally{j&&(j.disabled=!1,j.innerHTML="Đăng Nhập Vào Ca")}}),K&&K.addEventListener("input",C=>{K.value=K.value.replace(/[^0-9]/g,""),K.value.length===6&&n.dispatchEvent(new Event("submit"))})),h&&h.addEventListener("submit",async C=>{C.preventDefault();const X=((L==null?void 0:L.value)||"").trim().toUpperCase(),j=((A==null?void 0:A.value)||"").trim().toLowerCase(),U=((M==null?void 0:M.value)||"").trim(),le=((D==null?void 0:D.value)||"").trim();if(!X||!j){f&&(f.textContent="⚠️ Vui lòng nhập đầy đủ Mã Shop và Tên của bạn!",f.style.display="block");return}if(U&&U.length!==6){f&&(f.textContent="⚠️ Mã PIN phải bao gồm đúng 6 chữ số!",f.style.display="block");return}f&&(f.style.display="none");const ie=l.getElementById("panel-btn-submit-new-pin");ie&&(ie.disabled=!0,ie.innerHTML="⏳ Đang vào ca...");try{if(typeof AuthService<"u"&&typeof AuthService.loginWithPin=="function")await AuthService.loginWithPin({shopCode:X,loginName:j,pin:U||null,deviceName:le}),showVnpostToast("🎉 Vào ca làm việc thành công!","success"),setTimeout(()=>{const de=typeof globalThis<"u"&&globalThis.checkUrlAndInject||typeof window<"u"&&window.checkUrlAndInject;typeof de=="function"&&de()},80);else throw new Error("Hệ thống xác thực chưa sẵn sàng.")}catch(de){de.code==="DEVICE_PENDING_APPROVAL"?(h&&(h.style.display="none"),S&&(S.style.display="block"),f&&(f.style.display="none")):f&&(f.textContent=`❌ ${de.message||"Đăng nhập thất bại!"}`,f.style.display="block")}finally{ie&&(ie.disabled=!1,ie.innerHTML="🚀 Vào Ca Lên Đơn (1-Click)")}}),Y&&Y.addEventListener("click",async()=>{Y.disabled=!0,Y.innerHTML="⏳ Đang kiểm tra...";try{typeof AuthService<"u"&&typeof AuthService.loginWithPin=="function"&&await AuthService.loginWithPin({shopCode:F||(L==null?void 0:L.value),loginName:ae||(A==null?void 0:A.value),pin:"000000"})}catch(C){C.code==="DEVICE_PENDING_APPROVAL"?f&&(f.textContent="Máy trạm vẫn đang chờ Chủ Shop duyệt trong mục Quản Lý Thiết Bị.",f.style.display="block"):C.message&&C.message.includes("PIN")?(showVnpostToast("✅ Thiết bị đã được duyệt! Vui lòng nhập mã PIN 6 số.","success"),S&&(S.style.display="none"),be()):f&&(f.textContent=`❌ ${C.message}`,f.style.display="block")}finally{Y.disabled=!1,Y.innerHTML="🔄 Kiểm tra lại trạng thái duyệt"}}),c&&c.addEventListener("submit",async C=>{C.preventDefault();const X=((V==null?void 0:V.value)||"").trim(),j=((z==null?void 0:z.value)||"").trim();if(!X||!j){f&&(f.textContent="⚠️ Vui lòng nhập đầy đủ Email và Mật khẩu!",f.style.display="block");return}f&&(f.style.display="none");const U=l.getElementById("panel-btn-submit-owner");U&&(U.disabled=!0,U.innerHTML="⏳ Đang xác thực...");try{if(typeof AuthService<"u"&&typeof AuthService.login=="function")await AuthService.login(X,j),showVnpostToast("🎉 Đăng nhập Chủ Shop thành công!","success"),setTimeout(()=>{const le=typeof globalThis<"u"&&globalThis.checkUrlAndInject||typeof window<"u"&&window.checkUrlAndInject;typeof le=="function"&&le()},80);else throw new Error("Hệ thống xác thực chưa sẵn sàng.")}catch(le){f&&(f.textContent=`❌ ${le.message||"Đăng nhập thất bại!"}`,f.style.display="block")}finally{U&&(U.disabled=!1,U.innerHTML="🔑 Đăng Nhập Quản Trị")}}),re&&s&&re.addEventListener("click",C=>{C.preventDefault(),s()}),Q&&Q.addEventListener("click",C=>{C.preventDefault(),typeof chrome<"u"&&chrome.runtime&&chrome.runtime.sendMessage?chrome.runtime.sendMessage({action:"openAdmin"}):window.open("https://xlgovgynbsahuykyjzcx.supabase.co/","_blank")})}catch(u){console.warn("Lỗi tạo panel đăng nhập:",u)}}function kt(t,s,u){try{if(typeof document>"u")return;De(!1);const v=Oe(t);let x=document.getElementById("vnpost-autofill-shadow-host");const l=x?m("vnpost-autofill-panel"):null;if(l&&l.dataset&&l.dataset.panelType==="device-limit")return;x||(x=document.createElement("div"),x.id="vnpost-autofill-shadow-host",document.body.appendChild(x));const y=x.shadowRoot||x.attachShadow({mode:"open"}),b=y.querySelector("#vnpost-autofill-panel");b&&b.remove();const p=y.querySelector("#vnpost-dock-toggle-tab");if(p&&p.remove(),!y.querySelector("#vnpost-shadow-style")){const c=document.createElement("style");c.id="vnpost-shadow-style",c.textContent=typeof PANEL_CSS<"u"?PANEL_CSS:"",y.appendChild(c)}const g=document.createElement("div");if(g.id="vnpost-autofill-panel",g.dataset.panelType="device-limit",g.classList.add("panel-floating"),Ke(g),typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id&&chrome.storage&&chrome.storage.local)try{chrome.storage.local.get(["antigravity_ui_theme"],c=>{if(!chrome.runtime.lastError){if(c&&c.antigravity_ui_theme==="dark"){g.classList.remove("light-mode");try{localStorage.setItem("antigravity_ui_theme","dark")}catch{}}else if(c&&c.antigravity_ui_theme==="light"){g.classList.add("light-mode");try{localStorage.setItem("antigravity_ui_theme","light")}catch{}}}})}catch{}const w=v.themeColor||(v.id==="vnpost"?"#0056b3":"#4f46e5");g.style.setProperty("--theme-color",w);let _="v1";try{typeof chrome<"u"&&chrome.runtime&&chrome.runtime.getManifest&&(_="v"+(chrome.runtime.getManifest().version||"1"))}catch{}g.innerHTML=`
        <div class="minimized-icon">${N.user}</div>
        <div id="vnpost-panel-header">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span id="vnpost-panel-header-text"></span>
            <span class="badge-version">${_} (Hạn ngạch)</span>
          </div>
          <div style="display: flex; align-items: center; gap: 6px;">
            <button id="vnpost-btn-theme" title="Chuyển chế độ Sáng/Tối">${N.theme}</button>
            <button id="vnpost-btn-minimize">${N.minimize}</button>
          </div>
        </div>

        <div id="vnpost-panel-body">
          <div class="panel-login-box">
            <div class="panel-login-title" style="color: #ef4444; display: flex; align-items: center; gap: 6px;">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color: #ef4444;"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
              Vượt Giới Hạn Thiết Bị
            </div>
            <div class="panel-login-subtitle" style="margin-bottom: 12px; font-size: 12px;">
              Cửa hàng của bạn đã đạt giới hạn tối đa <strong>${s}</strong> thiết bị hoạt động đồng thời.
            </div>

            <div class="panel-login-error" style="display: block; margin-bottom: 12px; font-size: 11px;">
              Vui lòng mở Options (Cài đặt) để xem danh sách máy đang kết nối hoặc liên hệ với Chủ Shop/Quản trị viên để nâng cấp hạn ngạch.
            </div>

            <button type="button" id="panel-btn-open-settings" class="panel-login-btn" style="background-color: var(--theme-color, #4f46e5); color: #fff; margin-top: 4px;">
              💻 Quản lý thiết bị (Options)
            </button>
            
            <button type="button" id="panel-btn-logout-limit" class="panel-login-btn" style="background-color: #ef4444; color: #fff; margin-top: 8px;">
              🚪 Đăng xuất tài khoản
            </button>
          </div>
        </div>
      `,y.appendChild(g);const O=y.getElementById("vnpost-panel-header-text");O&&(O.textContent=v.title||""),Ge(g,y.getElementById("vnpost-panel-header"));const r=y.getElementById("vnpost-btn-theme");r&&r.addEventListener("click",c=>{c.stopPropagation();const P=g.classList.toggle("light-mode");Ue(P)}),y.getElementById("vnpost-btn-minimize").addEventListener("click",()=>{g.classList.toggle("minimized")});const d=y.getElementById("panel-btn-open-settings");d&&u&&d.addEventListener("click",c=>{c.preventDefault(),u()});const T=y.getElementById("panel-btn-logout-limit");T&&T.addEventListener("click",async c=>{c.preventDefault(),T.disabled=!0,T.textContent="⏳ Đang đăng xuất...";try{typeof AuthService<"u"&&typeof AuthService.logout=="function"&&(await AuthService.logout(),setTimeout(()=>{const P=typeof globalThis<"u"&&globalThis.checkUrlAndInject||typeof window<"u"&&window.checkUrlAndInject;typeof P=="function"&&P()},80))}catch(P){alert("Lỗi đăng xuất: "+P.message)}finally{T.disabled=!1,T.textContent="🚪 Đăng xuất tài khoản"}})}catch(v){console.warn("Lỗi tạo panel giới hạn thiết bị:",v)}}globalThis.createInputPanel=et,globalThis.createLoginRequiredPanel=xt,globalThis.createDeviceLimitExceededPanel=kt,globalThis.showOrderApprovalModal=Ct,globalThis.displayParsedData=$e})();
})()