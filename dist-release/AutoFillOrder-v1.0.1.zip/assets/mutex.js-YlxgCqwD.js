(function(){(()=>{const s=new Set,t={async acquire(e){return s.has(e)?!1:(s.add(e),!0)},release(e){s.delete(e)},isLocked(e){return s.has(e)}};globalThis.Mutex=t})();
})()