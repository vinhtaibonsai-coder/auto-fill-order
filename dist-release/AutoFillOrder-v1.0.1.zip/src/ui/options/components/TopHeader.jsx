import React, { useState, useRef, useEffect } from 'react';
import {
  Search, Globe, Moon, Sun, Bell, Shield, Store, Database,
  LogOut, ExternalLink, Check, Clock, AlertCircle
} from 'lucide-react';
import { AuthService } from '../../../domain/auth/auth.service.esm.js';

export default function TopHeader({
  currentUser,
  userRole,
  uiRole,
  shopName,
  appVersion,
  isDbConnected = true,
  activeTab,
  onOpenAdmin,
  onSearch,
  onLogout
}) {
  const [searchValue, setSearchValue] = useState('');
  const [isDarkMode, setIsDarkMode] = useState(() => {
    try {
      return localStorage.getItem('af_theme') === 'dark' ||
        document.documentElement.getAttribute('data-theme') === 'dark';
    } catch (_) {
      return false;
    }
  });
  const [showNotifications, setShowNotifications] = useState(false);
  const [showAvatarMenu, setShowAvatarMenu] = useState(false);
  const [currentLang, setCurrentLang] = useState('VN');

  const notifRef = useRef(null);
  const avatarRef = useRef(null);

  // Sync theme to document element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.setAttribute('data-theme', 'dark');
      try { localStorage.setItem('af_theme', 'dark'); } catch (_) {}
    } else {
      document.documentElement.removeAttribute('data-theme');
      try { localStorage.setItem('af_theme', 'light'); } catch (_) {}
    }
  }, [isDarkMode]);

  // Click outside listener
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (notifRef.current && !notifRef.current.contains(event.target)) {
        setShowNotifications(false);
      }
      if (avatarRef.current && !avatarRef.current.contains(event.target)) {
        setShowAvatarMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchChange = (e) => {
    const val = e.target.value;
    setSearchValue(val);
    if (onSearch) {
      onSearch(val);
    }
  };

  const toggleTheme = () => {
    setIsDarkMode(prev => !prev);
  };

  const toggleLanguage = () => {
    setCurrentLang(prev => (prev === 'VN' ? 'EN' : 'VN'));
  };

  const getRoleTitle = (role) => {
    const r = String(role || '').toUpperCase();
    if (['SYSTEM_ADMIN', 'SUPER_ADMIN', 'ADMIN'].includes(r)) return 'Quản trị viên';
    if (['OWNER', 'SHOP_OWNER'].includes(r)) return 'Chủ cửa hàng';
    if (['MANAGER', 'SHOP_MANAGER'].includes(r)) return 'Quản lý';
    if (['STAFF', 'SHOP_STAFF'].includes(r)) return 'Nhân viên';
    return 'Quản trị viên';
  };

  const displayName = currentUser?.full_name || getRoleTitle(userRole);
  const email = currentUser?.email || 'admin@af-store.vn';
  const avatarUrl = currentUser?.avatar_url || currentUser?.avatarUrl;

  const getAdminDashboardUrl = () => {
    if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.getURL === 'function') {
      return chrome.runtime.getURL('admin-dashboard/admin.html');
    }
    return '/admin';
  };

  return (
    <header className="topbar-container">
      {/* SEARCH CAPSULE BAR (LEFT/CENTER) */}
      <div className="topbar-search-wrapper">
        <div className="search-capsule">
          <Search size={16} className="search-icon" />
          <input
            type="text"
            className="search-input"
            value={searchValue}
            onChange={handleSearchChange}
            placeholder="Tìm kiếm đơn hàng, khách hàng..."
            aria-label="Tìm kiếm đơn hàng, khách hàng"
          />
          {searchValue && (
            <button
              className="search-clear-btn"
              onClick={() => {
                setSearchValue('');
                if (onSearch) onSearch('');
              }}
              title="Xóa tìm kiếm"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* RIGHT ACTION CONTROLS */}
      <div className="topbar-actions">
        {/* APP VERSION BADGE */}
        <div
          className="topbar-version-badge"
          title={`Phiên bản Auto Fill Order đang chạy: v${appVersion || '1.0.1'}`}
        >
          <span className="version-pill-dot"></span>
          <span className="version-text">v{appVersion || '1.0.1'}</span>
        </div>

        {/* DATABASE CONNECTION STATUS BADGE */}
        <div
          className={`topbar-db-badge ${isDbConnected ? 'connected' : 'disconnected'}`}
          title={isDbConnected ? 'Cơ sở dữ liệu Supabase: Đã kết nối' : 'Cơ sở dữ liệu: Mất kết nối'}
        >
          <span className={`db-status-dot ${isDbConnected ? 'live' : ''}`}></span>
          <Database size={13} className="db-icon" />
          <span className="db-text">{isDbConnected ? 'Đã kết nối DB' : 'Mất kết nối'}</span>
        </div>

        {/* SHOP NAME BADGE */}
        <div className="topbar-shop-badge" title={`Cửa hàng đang hoạt động: ${shopName || 'Cửa hàng của tôi'}`}>
          <Store size={14} className="shop-badge-icon" />
          <span className="shop-badge-text">{shopName || 'Cửa hàng của tôi'}</span>
        </div>

        {/* LANGUAGE SWITCH */}
        <button
          className="topbar-action-btn lang-btn"
          onClick={toggleLanguage}
          title={`Đổi ngôn ngữ (Hiện tại: ${currentLang === 'VN' ? 'Tiếng Việt' : 'English'})`}
        >
          <span className="lang-text">{currentLang}</span>
          <Globe size={16} className="action-icon" />
        </button>

        {/* DARK / LIGHT MODE TOGGLE */}
        <button
          className="topbar-action-btn theme-toggle-btn"
          onClick={toggleTheme}
          title={isDarkMode ? 'Chuyển sang chế độ Sáng' : 'Chuyển sang chế độ Tối'}
        >
          {isDarkMode ? (
            <Sun size={17} className="action-icon theme-sun" />
          ) : (
            <Moon size={17} className="action-icon theme-moon" />
          )}
        </button>

        {/* NOTIFICATIONS BELL */}
        <div className="notif-wrapper" ref={notifRef}>
          <button
            className={`topbar-action-btn notif-btn ${showNotifications ? 'active' : ''}`}
            onClick={() => setShowNotifications(!showNotifications)}
            title="Thông báo hệ thống"
          >
            <Bell size={18} className="action-icon" />
            <span className="unread-dot" title="Có thông báo mới"></span>
          </button>

          {showNotifications && (
            <div className="header-dropdown-menu notif-dropdown">
              <div className="dropdown-header">
                <span className="dropdown-title">Thông Báo Hệ Thống</span>
                <span className="dropdown-badge">Mới</span>
              </div>
              <div className="notif-list">
                <div className="notif-item unread">
                  <div className="notif-icon-box success">
                    <Check size={14} />
                  </div>
                  <div className="notif-content">
                    <div className="notif-title">Đồng bộ hoàn tất</div>
                    <div className="notif-desc">Dữ liệu đơn hàng & từ điển địa chỉ đã được cập nhật.</div>
                    <div className="notif-time">5 phút trước</div>
                  </div>
                </div>

                <div className="notif-item">
                  <div className="notif-icon-box info">
                    <AlertCircle size={14} />
                  </div>
                  <div className="notif-content">
                    <div className="notif-title">Kết nối bưu điện ổn định</div>
                    <div className="notif-desc">Cổng kết nối VNPost & J&T sẵn sàng tự động điền đơn.</div>
                    <div className="notif-time">1 giờ trước</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* VERTICAL DIVIDER */}
        <div className="topbar-divider"></div>

        {/* USER AVATAR WITH DROPDOWN */}
        <div className="avatar-wrapper" ref={avatarRef}>
          <button
            className={`avatar-button ${showAvatarMenu ? 'active' : ''}`}
            onClick={() => setShowAvatarMenu(!showAvatarMenu)}
            title={`${displayName} (${email})`}
          >
            {avatarUrl ? (
              <img src={avatarUrl} alt={displayName} className="header-avatar-img" />
            ) : (
              <div className="header-avatar-placeholder">
                {displayName.charAt(0).toUpperCase()}
              </div>
            )}
          </button>

          {showAvatarMenu && (
            <div className="header-dropdown-menu avatar-dropdown">
              <div className="avatar-dropdown-user">
                <div className="avatar-dropdown-img-box">
                  {avatarUrl ? (
                    <img src={avatarUrl} alt={displayName} />
                  ) : (
                    <div className="avatar-placeholder-sm">
                      {displayName.charAt(0).toUpperCase()}
                    </div>
                  )}
                </div>
                <div className="avatar-dropdown-details">
                  <div className="avatar-dropdown-name">{displayName}</div>
                  <div className="avatar-dropdown-email">{email}</div>
                  <div className="avatar-dropdown-role">{getRoleTitle(userRole)}</div>
                </div>
              </div>

              <div className="dropdown-divider"></div>

              <div className="avatar-dropdown-links">
                {uiRole === 'master_admin' && (
                  <button
                    className="dropdown-link-btn"
                    onClick={() => {
                      setShowAvatarMenu(false);
                      if (onOpenAdmin) {
                        onOpenAdmin();
                      } else {
                        window.open(getAdminDashboardUrl(), '_blank');
                      }
                    }}
                  >
                    <Shield size={14} />
                    <span>Bảng quản trị Master Admin</span>
                    <ExternalLink size={12} style={{ marginLeft: 'auto', opacity: 0.6 }} />
                  </button>
                )}

                <button
                  className="dropdown-link-btn logout"
                  onClick={async () => {
                    setShowAvatarMenu(false);
                    if (window.confirm('Bạn có chắc chắn muốn đăng xuất?')) {
                      if (onLogout) {
                        onLogout();
                      } else {
                        await AuthService.logout();
                        window.location.reload();
                      }
                    }
                  }}
                >
                  <LogOut size={14} />
                  <span>Đăng xuất</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
