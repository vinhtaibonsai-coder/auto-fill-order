import React, { useState, useEffect, useMemo } from 'react';
import { Plus, Trash2, Search, BookOpen, AlertCircle, Check, X, Sparkles } from 'lucide-react';
import { AuthSession } from '../../../../domain/auth/auth.session.esm.js';
import Pagination from '../../components/Pagination';

const SUGGESTIONS = [
  { original: 'q1', mapping: 'Quận 1, TP Hồ Chí Minh' },
  { original: 'qbt', mapping: 'Quận Bình Thạnh, TP Hồ Chí Minh' },
  { original: 'td', mapping: 'TP Thủ Đức, TP Hồ Chí Minh' },
  { original: 'hn', mapping: 'Thành phố Hà Nội' },
  { original: 'dn', mapping: 'Thành phố Đà Nẵng' }
];

export default function AddressEngine() {
  const [aliases, setAliases] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [status, setStatus] = useState({ type: '', text: '' });
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  // Modal State
  const [showAddModal, setShowAddModal] = useState(false);
  const [newOriginal, setNewOriginal] = useState('');
  const [newMapping, setNewMapping] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [formError, setFormError] = useState('');

  // Delete Confirm State
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const showToast = (text, type = 'success') => {
    setStatus({ type, text });
    setTimeout(() => setStatus({ type: '', text: '' }), 3500);
  };

  useEffect(() => {
    loadAliases();
  }, []);

  const getClient = async () => {
    const configRes = await globalThis.SupabaseCloud.loadConfig();
    const sess = await AuthSession.getSession();
    return { configRes, sess };
  };

  const loadAliases = async () => {
    try {
      const { configRes, sess } = await getClient();
      if (!sess || !sess.active_shop_id || !sess.access_token) {
        setIsLoading(false);
        return;
      }
      const res = await fetch(
        `${configRes.url}/rest/v1/shop_address_aliases?shop_id=eq.${sess.active_shop_id}&order=created_at.desc&select=id,original,mapping`,
        {
          headers: {
            'apikey': configRes.anonKey,
            'Authorization': `Bearer ${sess.access_token}`
          }
        }
      );
      if (res.ok) {
        const rows = await res.json();
        setAliases(rows || []);
      }
    } catch (err) {
      console.error('Lỗi tải từ điển địa chỉ:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveNew = async (e) => {
    if (e) e.preventDefault();
    const orig = newOriginal.trim().toLowerCase();
    const map = newMapping.trim();

    if (!orig || !map) {
      setFormError('Vui lòng điền đầy đủ cả từ viết tắt và địa chỉ chuẩn xác.');
      return;
    }

    setFormError('');
    setIsSaving(true);

    try {
      const { configRes, sess } = await getClient();
      if (!sess || !sess.active_shop_id || !sess.access_token) {
        setFormError('Phiên đăng nhập không hợp lệ.');
        return;
      }

      const res = await fetch(`${configRes.url}/rest/v1/shop_address_aliases`, {
        method: 'POST',
        headers: {
          'apikey': configRes.anonKey,
          'Authorization': `Bearer ${sess.access_token}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          shop_id: sess.active_shop_id,
          original: orig,
          mapping: map
        })
      });

      if (res.ok) {
        const row = await res.json();
        setAliases(prev => [row[0] || { id: Date.now(), original: orig, mapping: map }, ...prev]);
        setShowAddModal(false);
        setNewOriginal('');
        setNewMapping('');
        showToast('✅ Đã thêm từ khóa vào Từ điển Cloud!');
      } else {
        const data = await res.json();
        setFormError(data.message || 'Không thể lưu (từ khóa có thể đã tồn tại).');
      }
    } catch (err) {
      setFormError('Lỗi kết nối: ' + err.message);
    } finally {
      setIsSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      const { configRes, sess } = await getClient();
      if (!sess || !sess.access_token) return;
      const res = await fetch(`${configRes.url}/rest/v1/shop_address_aliases?id=eq.${deleteTarget.id}`, {
        method: 'DELETE',
        headers: {
          'apikey': configRes.anonKey,
          'Authorization': `Bearer ${sess.access_token}`
        }
      });
      if (res.ok) {
        setAliases(prev => prev.filter(a => a.id !== deleteTarget.id));
        setDeleteTarget(null);
        showToast('✅ Đã xóa từ khóa khỏi từ điển.');
      } else {
        showToast('❌ Không thể xóa từ khóa.', 'error');
      }
    } catch (err) {
      showToast('❌ Lỗi: ' + err.message, 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const filteredAliases = useMemo(() => {
    if (!searchQuery.trim()) return aliases;
    const q = searchQuery.toLowerCase().trim();
    return aliases.filter(a =>
      (a.original && a.original.toLowerCase().includes(q)) ||
      (a.mapping && a.mapping.toLowerCase().includes(q))
    );
  }, [aliases, searchQuery]);

  const paginatedAliases = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredAliases.slice(start, start + pageSize);
  }, [filteredAliases, page, pageSize]);

  return (
    <div>
      {/* Header Bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px', marginBottom: '8px' }}>
        <div>
          <h2 className="page-title" style={{ margin: 0 }}>Từ Điển Địa Chỉ (Address Engine)</h2>
          <p style={{ color: 'var(--text-muted)', margin: '4px 0 0 0', fontSize: '13px' }}>
            Dạy AI hiểu các từ lóng, viết tắt địa phương để chuẩn hóa địa chỉ tự động. Dữ liệu lưu trên Cloud đồng bộ mọi máy trạm.
          </p>
        </div>
        <button
          onClick={() => {
            setFormError('');
            setShowAddModal(true);
          }}
          className="btn-primary"
          style={{
            background: 'var(--primary)',
            color: '#fff',
            border: 'none',
            padding: '9px 18px',
            borderRadius: '8px',
            fontWeight: 700,
            fontSize: '13px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            boxShadow: '0 2px 6px rgba(37, 99, 235, 0.25)'
          }}
        >
          <Plus size={15} /> Thêm Từ Khóa
        </button>
      </div>

      {/* Toast Alert */}
      {status.text && (
        <div style={{
          padding: '10px 14px',
          borderRadius: '8px',
          fontSize: '13px',
          fontWeight: 600,
          marginBottom: '16px',
          background: status.type === 'error' ? 'var(--color-danger-bg)' : 'var(--color-success-bg)',
          color: status.type === 'error' ? 'var(--color-danger-text)' : 'var(--color-success-text)',
          border: `1px solid ${status.type === 'error' ? 'rgba(239, 68, 68, 0.2)' : 'rgba(16, 185, 129, 0.2)'}`
        }}>
          {status.text}
        </div>
      )}

      {/* Search Bar */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '16px' }}>
        <div style={{ position: 'relative', flex: 1, maxWidth: '400px' }}>
          <Search size={15} color="var(--text-muted)" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)' }} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => { setSearchQuery(e.target.value); setPage(1); }}
            placeholder="Tìm theo từ viết tắt hoặc địa chỉ chuẩn..."
            style={{
              width: '100%',
              boxSizing: 'border-box',
              padding: '9px 12px 9px 34px',
              borderRadius: '8px',
              border: '1px solid var(--border)',
              background: 'var(--card)',
              color: 'var(--text-main)',
              fontSize: '13px',
              outline: 'none'
            }}
          />
        </div>
      </div>

      {/* Table Card */}
      <div className="card" style={{ padding: 0, overflow: 'hidden', border: '1px solid var(--border)', background: 'var(--card)' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ background: 'var(--bg)', borderBottom: '1px solid var(--border)' }}>
              <th style={{ padding: '14px 18px', color: 'var(--text-muted)', fontSize: '11.5px', textTransform: 'uppercase', fontWeight: 700, letterSpacing: '0.5px', width: '220px' }}>
                Từ Khóa Viết Tắt
              </th>
              <th style={{ padding: '14px 18px', color: 'var(--text-muted)', fontSize: '11.5px', textTransform: 'uppercase', fontWeight: 700, letterSpacing: '0.5px' }}>
                Địa Chỉ Chuẩn Hóa
              </th>
              <th style={{ padding: '14px 18px', color: 'var(--text-muted)', fontSize: '11.5px', textTransform: 'uppercase', fontWeight: 700, letterSpacing: '0.5px', width: '100px', textAlign: 'right' }}>
                Thao Tác
              </th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan="3" style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)' }}>
                  <div style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', fontSize: '13px' }}>
                    <div className="db-status-dot live"></div> Đang tải từ điển địa chỉ...
                  </div>
                </td>
              </tr>
            ) : paginatedAliases.map(alias => (
              <tr key={alias.id} style={{ borderBottom: '1px solid var(--border)', transition: 'background 0.1s ease' }}>
                <td style={{ padding: '14px 18px' }}>
                  <span style={{
                    fontFamily: 'monospace',
                    fontWeight: 700,
                    fontSize: '13px',
                    background: 'var(--primary-light)',
                    color: 'var(--primary)',
                    padding: '4px 8px',
                    borderRadius: '6px',
                    border: '1px solid rgba(37, 99, 235, 0.2)'
                  }}>
                    {alias.original}
                  </span>
                </td>
                <td style={{ padding: '14px 18px', color: 'var(--text-main)', fontSize: '13px', fontWeight: 500 }}>
                  {alias.mapping}
                </td>
                <td style={{ padding: '14px 18px', textAlign: 'right' }}>
                  <button
                    onClick={() => setDeleteTarget(alias)}
                    style={{
                      background: 'transparent',
                      border: 'none',
                      color: 'var(--danger)',
                      cursor: 'pointer',
                      padding: '4px 8px',
                      borderRadius: '6px',
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '4px',
                      fontSize: '12px',
                      fontWeight: 600
                    }}
                    title="Xóa từ khóa"
                  >
                    <Trash2 size={14} /> Xóa
                  </button>
                </td>
              </tr>
            ))}
            {!isLoading && filteredAliases.length === 0 && (
              <tr>
                <td colSpan="3" style={{ padding: '48px 20px', textAlign: 'center', color: 'var(--text-muted)' }}>
                  <BookOpen size={32} color="var(--text-muted)" style={{ opacity: 0.5, marginBottom: '8px' }} />
                  <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-main)' }}>
                    {searchQuery ? 'Không tìm thấy từ khóa phù hợp' : 'Chưa có từ điển địa chỉ nào'}
                  </div>
                  <div style={{ fontSize: '12.5px', marginTop: '4px' }}>
                    {searchQuery ? 'Thử tìm với từ khóa khác.' : 'Bấm "+ Thêm Từ Khóa" để tạo từ khóa viết tắt đầu tiên.'}
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>

        {/* PAGINATION */}
        {!isLoading && filteredAliases.length > 0 && (
          <Pagination
            page={page}
            pageSize={pageSize}
            total={filteredAliases.length}
            onPageChange={setPage}
            onPageSizeChange={(newSize) => {
              setPageSize(newSize);
              setPage(1);
            }}
            pageSizeOptions={[10, 25, 50]}
            itemLabel="từ khóa"
          />
        )}
      </div>

      {/* MODAL THÊM TỪ KHÓA MỚI */}
      {showAddModal && (
        <div style={{
          position: 'fixed',
          inset: 0,
          background: 'rgba(15, 23, 42, 0.5)',
          backdropFilter: 'blur(3px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          padding: '16px'
        }}>
          <div style={{
            background: 'var(--card)',
            border: '1px solid var(--border)',
            borderRadius: '14px',
            width: '100%',
            maxWidth: '520px',
            boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.15)',
            overflow: 'hidden',
            animation: 'fadeInPop 0.15s ease-out'
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '16px 20px',
              borderBottom: '1px solid var(--border)'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Sparkles size={18} color="var(--primary)" />
                <h3 style={{ margin: 0, fontSize: '15px', fontWeight: 800, color: 'var(--text-main)' }}>
                  Thêm Từ Khóa Viết Tắt Địa Chỉ
                </h3>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveNew} style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
              {formError && (
                <div style={{
                  padding: '8px 12px',
                  borderRadius: '6px',
                  background: 'var(--color-danger-bg)',
                  color: 'var(--color-danger-text)',
                  fontSize: '12.5px',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px'
                }}>
                  <AlertCircle size={14} /> {formError}
                </div>
              )}

              <div>
                <label style={{ display: 'block', fontSize: '12.5px', fontWeight: 700, color: 'var(--text-main)', marginBottom: '6px' }}>
                  Từ Khóa Viết Tắt <span style={{ color: 'var(--danger)' }}>*</span>
                </label>
                <input
                  type="text"
                  value={newOriginal}
                  onChange={e => setNewOriginal(e.target.value)}
                  placeholder="Ví dụ: q1, qbt, td, hn, dn..."
                  autoFocus
                  style={{
                    width: '100%',
                    boxSizing: 'border-box',
                    padding: '10px 12px',
                    borderRadius: '8px',
                    border: '1px solid var(--border)',
                    background: 'var(--bg)',
                    color: 'var(--text-main)',
                    fontSize: '13px',
                    outline: 'none',
                    fontFamily: 'monospace'
                  }}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '12.5px', fontWeight: 700, color: 'var(--text-main)', marginBottom: '6px' }}>
                  Địa Chỉ Chuẩn Hóa Đầy Đủ <span style={{ color: 'var(--danger)' }}>*</span>
                </label>
                <input
                  type="text"
                  value={newMapping}
                  onChange={e => setNewMapping(e.target.value)}
                  placeholder="Ví dụ: Quận 1, Thành phố Hồ Chí Minh"
                  style={{
                    width: '100%',
                    boxSizing: 'border-box',
                    padding: '10px 12px',
                    borderRadius: '8px',
                    border: '1px solid var(--border)',
                    background: 'var(--bg)',
                    color: 'var(--text-main)',
                    fontSize: '13px',
                    outline: 'none'
                  }}
                />
              </div>

              {/* Suggestions chips */}
              <div>
                <div style={{ fontSize: '11.5px', color: 'var(--text-muted)', marginBottom: '6px', fontWeight: 600 }}>Gợi ý mẫu phổ biến:</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                  {SUGGESTIONS.map((sug, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setNewOriginal(sug.original);
                        setNewMapping(sug.mapping);
                      }}
                      style={{
                        padding: '3px 8px',
                        borderRadius: '6px',
                        border: '1px solid var(--border)',
                        background: 'var(--bg)',
                        color: 'var(--text-main)',
                        fontSize: '11.5px',
                        cursor: 'pointer'
                      }}
                    >
                      <strong>{sug.original}</strong> → {sug.mapping.split(',')[0]}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '10px', borderTop: '1px solid var(--border)', paddingTop: '14px' }}>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  style={{
                    padding: '9px 16px',
                    borderRadius: '8px',
                    border: '1px solid var(--border)',
                    background: 'var(--bg)',
                    color: 'var(--text-main)',
                    fontSize: '13px',
                    fontWeight: 600,
                    cursor: 'pointer'
                  }}
                >
                  Hủy Bỏ
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  style={{
                    padding: '9px 18px',
                    borderRadius: '8px',
                    border: 'none',
                    background: 'var(--primary)',
                    color: '#fff',
                    fontSize: '13px',
                    fontWeight: 700,
                    cursor: isSaving ? 'not-allowed' : 'pointer',
                    boxShadow: '0 2px 6px rgba(37, 99, 235, 0.25)'
                  }}
                >
                  {isSaving ? 'Đang lưu...' : 'Lưu Vào Từ Điển'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL XÁC NHẬN XÓA */}
      {deleteTarget && (
        <div style={{
          position: 'fixed',
          inset: 0,
          background: 'rgba(15, 23, 42, 0.5)',
          backdropFilter: 'blur(3px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          padding: '16px'
        }}>
          <div style={{
            background: 'var(--card)',
            border: '1px solid var(--border)',
            borderRadius: '14px',
            width: '100%',
            maxWidth: '420px',
            padding: '20px',
            boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.15)',
            animation: 'fadeInPop 0.15s ease-out'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: 'var(--danger)', marginBottom: '12px' }}>
              <AlertCircle size={22} />
              <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 800 }}>Xác Nhận Xóa Từ Khóa</h3>
            </div>
            <p style={{ margin: '0 0 16px 0', fontSize: '13px', color: 'var(--text-muted)', lineHeight: '1.5' }}>
              Bạn có chắc chắn muốn xóa từ khóa <strong>"{deleteTarget.original}"</strong> ({deleteTarget.mapping}) khỏi từ điển địa chỉ?
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
              <button
                onClick={() => setDeleteTarget(null)}
                style={{
                  padding: '8px 14px',
                  borderRadius: '8px',
                  border: '1px solid var(--border)',
                  background: 'var(--bg)',
                  color: 'var(--text-main)',
                  fontSize: '13px',
                  fontWeight: 600,
                  cursor: 'pointer'
                }}
              >
                Hủy
              </button>
              <button
                onClick={confirmDelete}
                disabled={isDeleting}
                style={{
                  padding: '8px 16px',
                  borderRadius: '8px',
                  border: 'none',
                  background: 'var(--danger)',
                  color: '#fff',
                  fontSize: '13px',
                  fontWeight: 700,
                  cursor: isDeleting ? 'not-allowed' : 'pointer'
                }}
              >
                {isDeleting ? 'Đang xóa...' : 'Xác Nhận Xóa'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
