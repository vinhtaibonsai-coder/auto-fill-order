import React, { useEffect, useMemo, useState } from 'react';
import {
  Package, Search, Calendar, Filter, Download, Copy,
  Check, ExternalLink, RefreshCw, Truck, DollarSign,
  User, Phone, Clock, FileSpreadsheet, AlertCircle, Cloud, HardDrive
} from 'lucide-react';
import { OrderStorage } from '../../../../application/storage.esm.js';
import { AuthSession } from '../../../../domain/auth/auth.session.esm.js';
import Pagination from '../../components/Pagination';

const removeVietnameseTones = (str) => {
  if (!str) return '';
  return String(str)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .toLowerCase()
    .trim();
};

const normalizePhone = (value) => String(value || '').replace(/\D/g, '');

const valueOf = (order, ...keys) => {
  for (const key of keys) {
    const value = order?.[key] ?? order?.parsedData?.[key];
    if (value !== undefined && value !== null && value !== '') return value;
  }
  return '';
};

const formatDate = (value) => {
  if (!value) return '-';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleString('vi-VN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

const normalizeCarrierValue = (value) => {
  if (!value) return '';
  if (typeof value === 'object') {
    return normalizeCarrierValue(
      value.id || value.ID || value.code || value.carrier_id || value.carrierId ||
      value.title || value.TITLE || value.name || value.label || ''
    );
  }
  const raw = String(value).trim();
  if (!raw) return '';
  if (raw.startsWith('{')) {
    try {
      return normalizeCarrierValue(JSON.parse(raw));
    } catch (_) {}
  }
  return raw;
};

const carrierLabel = (value) => {
  const raw = normalizeCarrierValue(value);
  const v = raw.toLowerCase().replace(/\s+/g, '');
  if (!v) return '-';
  if (v.includes('vnpost') || v.includes('vietnampost') || v.includes('buudien')) return 'VNPost';
  if (v === 'jt' || v.includes('j&t') || v.includes('jtexpress')) return 'J&T Express';
  if (v.includes('viettel')) return 'Viettel Post';
  if (v.includes('ghtk') || v.includes('giaohangtietkiem')) return 'GHTK';
  return raw;
};

const getCarrierTrackingUrl = (platform, trackingCode) => {
  if (!trackingCode || trackingCode === '-' || trackingCode === '—') return null;
  const p = String(platform || '').toLowerCase();
  if (p.includes('jt') || p.includes('j&t')) {
    return `https://jtexpress.vn/vi/tracking?billcode=${encodeURIComponent(trackingCode)}`;
  }
  if (p.includes('viettel')) {
    return `https://viettelpost.vn/tra-cuu-hanh-trinh-don/?order=${encodeURIComponent(trackingCode)}`;
  }
  if (p.includes('ghtk')) {
    return `https://khachhang.ghtk.vn/tra-cuu-don-hang?code=${encodeURIComponent(trackingCode)}`;
  }
  return `http://www.vnpost.vn/vi-vn/dinh-vi/buu-pham?key=${encodeURIComponent(trackingCode)}`;
};

const isRecipientPayingFee = (order) => {
  const payerValue = valueOf(order, 'shipping_fee_payer', 'collect_fee', 'collectFee', 'shippingFeePayer');
  if (payerValue === true || payerValue === 'true' || payerValue === 1 || payerValue === '1') return true;
  const payer = String(payerValue || '').toUpperCase();
  if (payer === 'RECIPIENT' || payer === 'BUYER' || payer === 'KHÁCH' || payer === 'NGƯỜI NHẬN') return true;
  return false;
};

const getCarrierAccount = (order) => {
  const acc = valueOf(order, 'carrierAccount', 'carrier_account', 'senderAccount', 'sender_account');
  if (acc && acc !== '-' && acc !== '—') return acc;

  const rawName = valueOf(order, 'name', 'customer_name', 'customerName');
  const match = String(rawName).match(/\((?:acc|tài khoản|tk)?\s*([^\)]+)\)/i);
  if (match && match[1]) return match[1].trim();

  const user = valueOf(order, 'userName', 'userEmail', 'deviceName');
  if (user && user !== '-' && user !== '—') return user;

  return 'Mặc định';
};

const getCleanCustomerName = (order) => {
  const raw = valueOf(order, 'name', 'customer_name', 'customerName') || '-';
  return raw.replace(/\s*\([^\)]*\)\s*/g, ' ').trim() || raw;
};

const getStorageSource = (order) => order?.isCloud === true ? 'cloud' : 'local';

export default function SubmittedOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [datePreset, setDatePreset] = useState('all'); // all, today, yesterday, 7days, thisMonth, lastMonth, custom
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');
  const [carrierFilter, setCarrierFilter] = useState('all'); // all, vnpost, jt
  const [feeFilter, setFeeFilter] = useState('all'); // all, recipient, sender
  const [statusFilter, setStatusFilter] = useState('all'); // all, has_tracking, no_tracking
  const [copiedId, setCopiedId] = useState('');
  const [error, setError] = useState('');
  
  // Pagination state
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  // Reset to page 1 whenever search or filters change
  useEffect(() => {
    setPage(1);
  }, [search, datePreset, carrierFilter, feeFilter, statusFilter, customStart, customEnd]);

  const loadOrders = async (silent = false) => {
    if (!silent) {
      setLoading(true);
      setError('');
    }
    try {
      const activeShop = typeof OrderStorage !== 'undefined' ? await OrderStorage.getActiveShop().catch(() => null) : null;
      const sess = typeof AuthSession !== 'undefined' ? await AuthSession.getSession().catch(() => null) : null;
      const targetShopId = activeShop ? String(activeShop.id || activeShop) : (sess?.active_shop_id ? String(sess.active_shop_id) : null);

      let rows = [];
      let cloudLoaded = false;

      // 1. Ưu tiên gọi qua SupabaseCloud.fetchSubmittedOrders (đã tối ưu hóa cho cả JWT & PIN Device Session)
      if (typeof globalThis.SupabaseCloud !== 'undefined' && typeof globalThis.SupabaseCloud.fetchSubmittedOrders === 'function') {
        try {
          rows = await globalThis.SupabaseCloud.fetchSubmittedOrders(targetShopId);
          cloudLoaded = true;
        } catch (scErr) {
          console.warn('[SubmittedOrders] SupabaseCloud.fetchSubmittedOrders failed, trying direct fetch:', scErr);
        }
      }

      // Fallback: fetch trực tiếp nếu SupabaseCloud chưa sẵn sàng
      if (!cloudLoaded) {
        const config = typeof globalThis.SupabaseCloud !== 'undefined' ? await globalThis.SupabaseCloud.loadConfig().catch(() => null) : null;

        if (config?.url && config?.anonKey) {
          const isJwt = typeof sess?.access_token === 'string' && sess.access_token.split('.').length === 3;
          const headers = {
            'apikey': config.anonKey,
            'Authorization': `Bearer ${isJwt ? sess.access_token : config.anonKey}`,
            'Content-Type': 'application/json'
          };
          const base = `${String(config.url).replace(/\/$/, '')}/rest/v1/`;
          const shopFilter = targetShopId ? `shop_id=eq.${encodeURIComponent(targetShopId)}&` : '';

          const res = await fetch(`${base}submitted_orders?${shopFilter}order=submitted_at.desc&limit=1000&select=*`, { headers });
          if (res.ok) {
            rows = await res.json();
            cloudLoaded = true;
          } else {
            const errText = await res.text().catch(() => '');
            let msg = `HTTP ${res.status}: ${res.statusText}`;
            try {
              const errObj = JSON.parse(errText);
              msg = errObj.message || errObj.hint || msg;
            } catch (_) {}
            throw new Error(`Không thể tải dữ liệu đơn từ Supabase Cloud (${msg})`);
          }
        }
      }

      let cloudData = (Array.isArray(rows) ? rows : []).map(o => ({
        isCloud: true,
        id: o.id,
        shopId: o.shop_id || o.shopId || targetShopId,
        savedOrderId: o.saved_order_id || o.savedOrderId || '',
        name: o.name || o.customer_name || '',
        phone: o.phone || '',
        address: o.address || '',
        orderCode: o.order_code || o.orderCode || '',
        codAmount: Number(o.cod_amount) || 0,
        collectFee: o.collect_fee === true || o.shipping_fee_payer === 'RECIPIENT',
        platform: o.platform || '',
        trackingCode: o.tracking_code || o.trackingCode || '',
        submittedAt: o.submitted_at || o.submittedAt || '',
        submittedDate: o.submitted_date || o.submittedDate || '',
        deviceName: o.device_name || o.deviceName || '',
        carrierAccount: o.carrier_account || o.carrierAccount || '',
        productNote: o.product_note || o.productNote || '',
        weight: Number(o.weight) || 0
      }));

      // 2. Lấy dữ liệu lưu tạm ở local (fallback hoặc đơn vừa lưu ở extension offline)
      let localOrders = [];
      try {
        if (typeof OrderStorage !== 'undefined' && typeof OrderStorage.getSubmittedOrders === 'function') {
          localOrders = await OrderStorage.getSubmittedOrders();
        }
      } catch (localErr) {
        console.warn('[SubmittedOrders] Local fetch error:', localErr);
      }

      // 3. Kết hợp và khử trùng lặp (Dedup) giữa Cloud và Local
      const combined = [
        ...cloudData,
        ...(Array.isArray(localOrders) ? localOrders.map(l => ({ ...l, isCloud: false })) : [])
      ];

      const targetFilterShop = targetShopId ? combined.filter(o => {
        if (!o) return false;
        const sId = String(o.shopId || o.shop_id || '');
        return !sId || sId === targetShopId;
      }) : combined;

      const seenKeys = new Set();
      const dedupeList = [];
      targetFilterShop.forEach(o => {
        if (!o) return;
        const keys = [];
        const id = String(o.id || '').trim();
        const savedId = String(o.savedOrderId || o.saved_order_id || '').trim();
        const tracking = String(o.trackingCode || o.tracking_code || '').trim().toLowerCase();
        const orderCode = String(o.orderCode || o.order_code || '').trim().toLowerCase();
        const phone = String(o.phone || '').replace(/\D/g, '');

        if (id) keys.push('id_' + id);
        if (savedId && savedId !== '—' && savedId !== '-') keys.push('id_' + savedId);
        if (tracking && tracking !== '—' && tracking !== '-' && tracking !== 'chờ cập nhật mã') {
          keys.push('tr_' + tracking);
        }
        if (phone && phone.length >= 9 && orderCode && orderCode !== '—' && orderCode !== '-') {
          keys.push('oc_' + phone + '_' + orderCode);
        }

        const isSeen = keys.some(k => seenKeys.has(k));
        if (!isSeen) {
          keys.forEach(k => seenKeys.add(k));
          dedupeList.push(o);
        }
      });

      const sorted = dedupeList.sort((a, b) => {
        const timeA = new Date(valueOf(a, 'submittedAt', 'submitted_at', 'createdAt', 'created_at') || 0).getTime();
        const timeB = new Date(valueOf(b, 'submittedAt', 'submitted_at', 'createdAt', 'created_at') || 0).getTime();
        return timeB - timeA;
      });

      setOrders(sorted);
      if (silent) {
        setError('');
      }
    } catch (err) {
      console.error('[SubmittedOrders] Load failed:', err);
      if (!silent) {
        setError(err.message || 'Không thể tải danh sách đơn từ Supabase Cloud.');
      }

      // Fallback hiển thị dữ liệu lưu tạm nếu có
      try {
        const localBackup = typeof OrderStorage !== 'undefined' ? await OrderStorage.getSubmittedOrders().catch(() => []) : [];
        if (Array.isArray(localBackup) && localBackup.length > 0) {
          setOrders(localBackup.map(l => ({ ...l, isCloud: false })));
        }
      } catch (_) {}
    } finally {
      if (!silent) setLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();

    // Tự động tải lại khi có đơn mới được lưu vào storage (không cần F5 thủ công)
    const handleStorageChange = (changes, areaName) => {
      if (areaName === 'local') {
        const hasRelevantKey = Object.keys(changes).some(k => 
          k.includes('submitted') || k.includes('order') || k === 'last_submitted_order' || k === 'activeShopId'
        );
        if (hasRelevantKey) {
          loadOrders(true);
        }
      }
    };

    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener(handleStorageChange);
    }

    const handleRuntimeMessage = (msg) => {
      if (msg && (msg.type === 'cloud_sync_update' || msg.type === 'order_submitted' || msg.action === 'refresh_orders')) {
        loadOrders(true);
      }
    };
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
      chrome.runtime.onMessage.addListener(handleRuntimeMessage);
    }

    const handleWindowStorage = (e) => {
      if (e.key && (e.key.includes('submitted') || e.key.includes('order'))) {
        loadOrders(true);
      }
    };
    window.addEventListener('storage', handleWindowStorage);

    const handleCustomOrderEvent = () => {
      loadOrders(true);
    };
    window.addEventListener('order-saved-db', handleCustomOrderEvent);
    window.addEventListener('submitted-orders-updated', handleCustomOrderEvent);

    return () => {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
        chrome.storage.onChanged.removeListener(handleStorageChange);
      }
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
        chrome.runtime.onMessage.removeListener(handleRuntimeMessage);
      }
      window.removeEventListener('storage', handleWindowStorage);
      window.removeEventListener('order-saved-db', handleCustomOrderEvent);
      window.removeEventListener('submitted-orders-updated', handleCustomOrderEvent);
    };
  }, []);

  const dateRange = useMemo(() => {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
    const todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

    if (datePreset === 'today') {
      return { start: todayStart, end: todayEnd };
    }
    if (datePreset === 'yesterday') {
      const yestStart = new Date(todayStart);
      yestStart.setDate(yestStart.getDate() - 1);
      const yestEnd = new Date(todayEnd);
      yestEnd.setDate(yestEnd.getDate() - 1);
      return { start: yestStart, end: yestEnd };
    }
    if (datePreset === '7days') {
      const past7 = new Date(todayStart);
      past7.setDate(past7.getDate() - 6);
      return { start: past7, end: todayEnd };
    }
    if (datePreset === 'thisMonth') {
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
      return { start: monthStart, end: todayEnd };
    }
    if (datePreset === 'lastMonth') {
      const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
      const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
      return { start: lastMonthStart, end: lastMonthEnd };
    }
    if (datePreset === 'custom' && (customStart || customEnd)) {
      const s = customStart ? new Date(customStart + 'T00:00:00') : new Date(0);
      const e = customEnd ? new Date(customEnd + 'T23:59:59') : new Date(8640000000000000);
      return { start: s, end: e };
    }
    return null;
  }, [datePreset, customStart, customEnd]);

  const filtered = useMemo(() => {
    const q = search.trim();
    const cleanQ = removeVietnameseTones(q);
    const qDigits = normalizePhone(q);

    return orders.filter(order => {
      // 1. Lọc theo thời gian
      if (dateRange) {
        const orderTime = new Date(valueOf(order, 'submittedAt', 'submitted_at', 'createdAt', 'created_at') || 0);
        if (!Number.isNaN(orderTime.getTime())) {
          if (orderTime < dateRange.start || orderTime > dateRange.end) return false;
        }
      }

      // 2. Lọc theo Hãng
      if (carrierFilter !== 'all') {
        const p = String(valueOf(order, 'platform')).toLowerCase();
        if (carrierFilter === 'vnpost' && !p.includes('vnpost') && !p.includes('vietnam')) return false;
        if (carrierFilter === 'jt' && !p.includes('jt') && !p.includes('j&t')) return false;
      }

      // 3. Lọc theo Người trả cước
      if (feeFilter !== 'all') {
        const isRecipient = isRecipientPayingFee(order);
        if (feeFilter === 'recipient' && !isRecipient) return false;
        if (feeFilter === 'sender' && isRecipient) return false;
      }

      // 4. Lọc theo tình trạng Vận đơn
      if (statusFilter !== 'all') {
        const tracking = String(valueOf(order, 'trackingCode', 'tracking_code')).trim();
        const hasTracking = tracking && tracking !== '-' && tracking !== '—';
        if (statusFilter === 'has_tracking' && !hasTracking) return false;
        if (statusFilter === 'no_tracking' && hasTracking) return false;
      }

      // 5. Tìm kiếm đa năng
      if (q) {
        const rawName = String(valueOf(order, 'name', 'customerName', 'customer_name'));
        const nameNorm = removeVietnameseTones(rawName);
        const rawPhone = normalizePhone(valueOf(order, 'phone'));
        const rawOrderCode = String(valueOf(order, 'orderCode', 'order_code')).toLowerCase();
        const rawTracking = String(valueOf(order, 'trackingCode', 'tracking_code')).toLowerCase();
        const rawAcc = removeVietnameseTones(getCarrierAccount(order));
        const rawAddress = removeVietnameseTones(valueOf(order, 'address'));

        const matchName = nameNorm.includes(cleanQ);
        const matchPhone = qDigits ? (rawPhone.includes(qDigits) || rawPhone.endsWith(qDigits)) : false;
        const matchOrderCode = rawOrderCode.includes(q.toLowerCase());
        const matchTracking = rawTracking.includes(q.toLowerCase());
        const matchAccount = rawAcc.includes(cleanQ);
        const matchAddress = rawAddress.includes(cleanQ);

        if (!matchName && !matchPhone && !matchOrderCode && !matchTracking && !matchAccount && !matchAddress) {
          return false;
        }
      }

      return true;
    });
  }, [orders, dateRange, carrierFilter, feeFilter, statusFilter, search]);

  const paginatedOrders = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, page, pageSize]);

  const stats = useMemo(() => {
    let totalCod = 0;
    let recipientFeeCount = 0;
    let senderFeeCount = 0;
    let hasTrackingCount = 0;

    filtered.forEach(o => {
      totalCod += Number(valueOf(o, 'codAmount', 'cod_amount')) || 0;
      if (isRecipientPayingFee(o)) recipientFeeCount++;
      else senderFeeCount++;

      const tr = String(valueOf(o, 'trackingCode', 'tracking_code')).trim();
      if (tr && tr !== '-' && tr !== '—') hasTrackingCount++;
    });

    return {
      totalCount: filtered.length,
      totalCod,
      recipientFeeCount,
      senderFeeCount,
      hasTrackingCount
    };
  }, [filtered]);

  const copyText = (text, id) => {
    if (!text || text === '-' || text === '—') return;
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(''), 2000);
  };

  const exportToCsv = () => {
    if (filtered.length === 0) return;

    const headers = [
      'Thời gian gửi',
      'Tên người nhận',
      'Số điện thoại',
      'Mã đơn hàng',
      'Mã vận đơn',
      'Nguồn lưu trữ',
      'Tiền thu hộ COD (VNĐ)',
      'Người trả cước',
      'Hãng vận chuyển',
      'Tài khoản bưu điện lên đơn',
      'Địa chỉ giao hàng'
    ];

    const rows = filtered.map(o => [
      `"${formatDate(valueOf(o, 'submittedAt', 'submitted_at', 'createdAt', 'created_at'))}"`,
      `"${getCleanCustomerName(o).replace(/"/g, '""')}"`,
      `"\t${valueOf(o, 'phone')}"`,
      `"${valueOf(o, 'orderCode', 'order_code').replace(/"/g, '""')}"`,
      `"\t${valueOf(o, 'trackingCode', 'tracking_code')}"`,
      `"${getStorageSource(o) === 'cloud' ? 'Đã lên Cloud' : 'Chỉ lưu Local'}"`,
      `"${Number(valueOf(o, 'codAmount', 'cod_amount') || 0)}"`,
      `"${isRecipientPayingFee(o) ? 'Người nhận trả' : 'Shop trả'}"`,
      `"${carrierLabel(valueOf(o, 'platform'))}"`,
      `"${getCarrierAccount(o).replace(/"/g, '""')}"`,
      `"${String(valueOf(o, 'address')).replace(/"/g, '""')}"`
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Don_Hang_Da_Gui_${new Date().toISOString().substring(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div style={{ width: '100%', maxWidth: '100%', minWidth: 0, boxSizing: 'border-box' }}>
      {/* HEADER SECTION */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '16px', marginBottom: '20px', flexWrap: 'wrap', width: '100%', maxWidth: '100%', boxSizing: 'border-box' }}>
        <div>
          <h2 className="page-title" style={{ marginBottom: '6px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Package size={22} color="var(--primary)" /> Đơn Hàng Đã Gửi
          </h2>
          <p style={{ margin: 0, color: 'var(--text-muted)', fontSize: '13px' }}>
            Quản lý, tra cứu người trả cước, tài khoản bưu điện lên đơn và xuất báo cáo đối soát COD.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
          <button
            type="button"
            onClick={exportToCsv}
            disabled={filtered.length === 0}
            style={{
              background: '#f0fdf4',
              color: '#166534',
              border: '1px solid #bbf7d0',
              padding: '8px 14px',
              borderRadius: '8px',
              fontWeight: 600,
              fontSize: '13px',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              cursor: filtered.length === 0 ? 'not-allowed' : 'pointer'
            }}
          >
            <FileSpreadsheet size={15} /> Xuất Excel ({filtered.length})
          </button>
          <button
            type="button"
            onClick={loadOrders}
            disabled={loading}
            style={{
              background: 'white',
              color: '#334155',
              border: '1px solid var(--border)',
              padding: '8px 14px',
              borderRadius: '8px',
              fontWeight: 600,
              fontSize: '13px',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              cursor: loading ? 'default' : 'pointer'
            }}
          >
            <RefreshCw size={14} className={loading ? 'spin' : ''} /> {loading ? 'Đang tải...' : 'Làm mới'}
          </button>
        </div>
      </div>

      {/* ERROR ALERT BANNER */}
      {error && (
        <div style={{
          background: '#fef2f2',
          border: '1px solid #f87171',
          borderRadius: '10px',
          padding: '14px 18px',
          marginBottom: '20px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '12px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: '#b91c1c', fontWeight: 600, fontSize: '13.5px' }}>
            <AlertCircle size={20} color="#dc2626" style={{ flexShrink: 0 }} />
            <div>
              <div style={{ fontWeight: 800 }}>⚠️ Lỗi đồng bộ dữ liệu Supabase Cloud:</div>
              <div style={{ fontWeight: 500, fontSize: '12.5px', marginTop: '2px', color: '#7f1d1d' }}>{error}</div>
            </div>
          </div>
          <button
            type="button"
            onClick={loadOrders}
            disabled={loading}
            style={{
              background: '#dc2626',
              color: '#ffffff',
              border: 'none',
              padding: '8px 16px',
              borderRadius: '6px',
              fontWeight: 700,
              fontSize: '12.5px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            <RefreshCw size={14} className={loading ? 'spin' : ''} /> Thử lại
          </button>
        </div>
      )}

      {/* KPI SUMMARY CARDS */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '12px', marginBottom: '20px', width: '100%', maxWidth: '100%', boxSizing: 'border-box' }}>
        <div className="card" style={{ padding: '14px 16px', background: 'white', border: '1px solid var(--border)', borderRadius: '10px' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', marginBottom: '4px' }}>Tổng đơn hiển thị</div>
          <div style={{ fontSize: '22px', fontWeight: 800, color: 'var(--text-main)' }}>{stats.totalCount} <span style={{ fontSize: '13px', fontWeight: 500, color: 'var(--text-muted)' }}>đơn</span></div>
        </div>

        <div className="card" style={{ padding: '14px 16px', background: 'white', border: '1px solid var(--border)', borderRadius: '10px' }}>
          <div style={{ fontSize: '12px', color: '#059669', fontWeight: 600, textTransform: 'uppercase', marginBottom: '4px' }}>Tổng tiền thu hộ (COD)</div>
          <div style={{ fontSize: '22px', fontWeight: 800, color: '#059669' }}>{stats.totalCod.toLocaleString('vi-VN')} <span style={{ fontSize: '13px', fontWeight: 500 }}>đ</span></div>
        </div>

        <div className="card" style={{ padding: '14px 16px', background: 'white', border: '1px solid var(--border)', borderRadius: '10px' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', marginBottom: '4px' }}>Người trả cước</div>
          <div style={{ fontSize: '13px', fontWeight: 600, display: 'flex', gap: '8px', marginTop: '6px' }}>
            <span style={{ background: '#ecfdf5', color: '#047857', padding: '2px 8px', borderRadius: '4px' }}>🟢 Khách: {stats.recipientFeeCount}</span>
            <span style={{ background: '#eff6ff', color: '#1d4ed8', padding: '2px 8px', borderRadius: '4px' }}>🔵 Shop: {stats.senderFeeCount}</span>
          </div>
        </div>

        <div className="card" style={{ padding: '14px 16px', background: 'white', border: '1px solid var(--border)', borderRadius: '10px' }}>
          <div style={{ fontSize: '12px', color: '#2563eb', fontWeight: 600, textTransform: 'uppercase', marginBottom: '4px' }}>Mã vận đơn</div>
          <div style={{ fontSize: '14px', fontWeight: 700, color: '#2563eb', marginTop: '6px' }}>
            {stats.hasTrackingCount} / {stats.totalCount} <span style={{ fontSize: '12px', fontWeight: 500, color: 'var(--text-muted)' }}>đã có mã</span>
          </div>
        </div>
      </div>

      {/* FILTER CONTROLS BAR */}
      <div className="card" style={{ padding: '16px', marginBottom: '16px', background: 'white', border: '1px solid var(--border)', borderRadius: '10px', width: '100%', maxWidth: '100%', boxSizing: 'border-box' }}>
        {/* ROW 1: SEARCH & DATE PRESETS */}
        <div style={{ display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap', marginBottom: '12px', width: '100%', maxWidth: '100%', boxSizing: 'border-box' }}>
          <div style={{ flex: '1 1 300px', position: 'relative', minWidth: '240px' }}>
            <Search size={16} color="var(--text-muted)" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)' }} />
            <input
              type="text"
              placeholder="Tìm theo Tên khách, SĐT (đầy đủ hoặc 4 số cuối), Mã đơn, Vận đơn, Tài khoản bưu điện..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{
                width: '100%',
                padding: '9px 12px 9px 36px',
                border: '1px solid var(--border)',
                borderRadius: '8px',
                fontSize: '13px',
                outline: 'none',
                boxSizing: 'border-box'
              }}
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', fontSize: '14px' }}
              >
                ✕
              </button>
            )}
          </div>

          {/* DATE PRESETS TABS */}
          <div style={{ display: 'flex', gap: '4px', background: 'var(--bg)', border: '1px solid var(--border)', padding: '3px', borderRadius: '8px', flexWrap: 'wrap' }}>
            {[
              { id: 'all', label: 'Tất cả' },
              { id: 'today', label: 'Hôm nay' },
              { id: 'yesterday', label: 'Hôm qua' },
              { id: '7days', label: '7 ngày qua' },
              { id: 'thisMonth', label: 'Tháng này' },
              { id: 'lastMonth', label: 'Tháng trước' },
              { id: 'custom', label: 'Tùy chỉnh 🗓️' }
            ].map(tab => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setDatePreset(tab.id)}
                style={{
                  padding: '6px 12px',
                  borderRadius: '6px',
                  border: 'none',
                  fontSize: '12px',
                  fontWeight: datePreset === tab.id ? 700 : 500,
                  background: datePreset === tab.id ? 'var(--card)' : 'transparent',
                  color: datePreset === tab.id ? 'var(--primary)' : 'var(--text-muted)',
                  boxShadow: datePreset === tab.id ? '0 1px 3px rgba(0,0,0,0.06)' : 'none',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease'
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* ROW 2: CUSTOM DATE RANGE & SECONDARY FILTERS */}
        <div style={{ display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap', paddingTop: '10px', borderTop: '1px solid var(--border)', width: '100%', maxWidth: '100%', boxSizing: 'border-box' }}>
          {datePreset === 'custom' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px' }}>
              <Calendar size={15} color="var(--text-muted)" />
              <input
                type="date"
                value={customStart}
                onChange={(e) => setCustomStart(e.target.value)}
                style={{ padding: '5px 8px', border: '1px solid var(--border)', background: 'var(--card)', color: 'var(--text-main)', borderRadius: '6px', fontSize: '12px' }}
              />
              <span>đến</span>
              <input
                type="date"
                value={customEnd}
                onChange={(e) => setCustomEnd(e.target.value)}
                style={{ padding: '5px 8px', border: '1px solid var(--border)', background: 'var(--card)', color: 'var(--text-main)', borderRadius: '6px', fontSize: '12px' }}
              />
            </div>
          )}

          {/* Lọc Hãng */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px' }}>
            <span style={{ color: 'var(--text-muted)' }}>Hãng:</span>
            <select
              value={carrierFilter}
              onChange={(e) => setCarrierFilter(e.target.value)}
              style={{ padding: '5px 10px', border: '1px solid var(--border)', borderRadius: '6px', fontSize: '12px', background: 'var(--card)', color: 'var(--text-main)' }}
            >
              <option value="all">Tất cả hãng</option>
              <option value="vnpost">VNPost (Bưu điện)</option>
              <option value="jt">J&T Express</option>
            </select>
          </div>

          {/* Lọc Trả cước */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px' }}>
            <span style={{ color: 'var(--text-muted)' }}>Cước phí:</span>
            <select
              value={feeFilter}
              onChange={(e) => setFeeFilter(e.target.value)}
              style={{ padding: '5px 10px', border: '1px solid var(--border)', borderRadius: '6px', fontSize: '12px', background: 'var(--card)', color: 'var(--text-main)' }}
            >
              <option value="all">Tất cả hình thức</option>
              <option value="recipient">Khách (Người nhận) trả</option>
              <option value="sender">Shop (Người gửi) trả</option>
            </select>
          </div>

          {/* Lọc Trạng thái mã vận đơn */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px' }}>
            <span style={{ color: 'var(--text-muted)' }}>Vận đơn:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              style={{ padding: '5px 10px', border: '1px solid var(--border)', borderRadius: '6px', fontSize: '12px', background: 'var(--card)', color: 'var(--text-main)' }}
            >
              <option value="all">Tất cả</option>
              <option value="has_tracking">Đã có mã vận đơn</option>
              <option value="no_tracking">Chưa có mã vận đơn</option>
            </select>
          </div>
        </div>
      </div>

      {error && (
        <div style={{ background: '#fef2f2', border: '1px solid #fecaca', color: '#991b1b', padding: '12px 16px', borderRadius: '8px', marginBottom: '16px', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '8px', width: '100%', maxWidth: '100%', boxSizing: 'border-box' }}>
          <AlertCircle size={16} /> {error}
        </div>
      )}

      {/* ORDERS TABLE */}
      <div className="card" style={{ padding: 0, overflow: 'hidden', background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '12px', width: '100%', maxWidth: '100%', boxSizing: 'border-box' }}>
        {loading ? (
          <div style={{ padding: '50px', textAlign: 'center', color: 'var(--text-muted)' }}>
            <RefreshCw size={24} className="spin" style={{ margin: '0 auto 10px' }} />
            <div>Đang tải dữ liệu đơn hàng...</div>
          </div>
        ) : filtered.length === 0 ? (
          <div style={{ padding: '50px', textAlign: 'center', color: 'var(--text-muted)' }}>
            <Package size={36} color="var(--text-muted)" style={{ margin: '0 auto 12px', opacity: 0.5 }} />
            <div style={{ fontWeight: 600, fontSize: '15px', color: 'var(--text-main)' }}>Không tìm thấy đơn hàng nào</div>
            <div style={{ fontSize: '13px', marginTop: '4px' }}>Thử thay đổi bộ lọc thời gian hoặc từ khóa tìm kiếm.</div>
          </div>
        ) : (
          <div style={{ overflowX: 'auto', width: '100%', maxWidth: '100%', WebkitOverflowScrolling: 'touch' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', minWidth: '1120px' }}>
              <thead>
                <tr style={{ background: 'var(--bg)', borderBottom: '1px solid var(--border)', position: 'sticky', top: 0, zIndex: 2 }}>
                  <th style={{ padding: '12px 16px', color: 'var(--text-muted)', fontWeight: 700, fontSize: '11.5px', textTransform: 'uppercase' }}>Thời gian</th>
                  <th style={{ padding: '12px 16px', color: 'var(--text-muted)', fontWeight: 700, fontSize: '11.5px', textTransform: 'uppercase' }}>Người nhận (Khách hàng)</th>
                  <th style={{ padding: '12px 16px', color: 'var(--text-muted)', fontWeight: 700, fontSize: '11.5px', textTransform: 'uppercase' }}>Mã đơn</th>
                  <th style={{ padding: '12px 16px', color: 'var(--text-muted)', fontWeight: 700, fontSize: '11.5px', textTransform: 'uppercase' }}>Mã vận đơn</th>
                  <th style={{ padding: '12px 16px', color: 'var(--text-muted)', fontWeight: 700, fontSize: '11.5px', textTransform: 'uppercase' }}>Lưu trữ</th>
                  <th style={{ padding: '12px 16px', color: 'var(--text-muted)', fontWeight: 700, fontSize: '11.5px', textTransform: 'uppercase' }}>Tiền COD</th>
                  <th style={{ padding: '12px 16px', color: 'var(--text-muted)', fontWeight: 700, fontSize: '11.5px', textTransform: 'uppercase' }}>Trả cước</th>
                  <th style={{ padding: '12px 16px', color: 'var(--text-muted)', fontWeight: 700, fontSize: '11.5px', textTransform: 'uppercase' }}>Hãng / Tài khoản gửi</th>
                  <th style={{ padding: '12px 16px', color: 'var(--text-muted)', fontWeight: 700, fontSize: '11.5px', textTransform: 'uppercase' }}>Địa chỉ giao</th>
                </tr>
              </thead>
              <tbody>
                {paginatedOrders.map((order, idx) => {
                  const tracking = valueOf(order, 'trackingCode', 'tracking_code');
                  const phone = valueOf(order, 'phone');
                  const customerName = getCleanCustomerName(order);
                  const isRecipientFee = isRecipientPayingFee(order);
                  const carrier = carrierLabel(valueOf(order, 'platform'));
                  const carrierAccount = getCarrierAccount(order);
                  const trackingUrl = getCarrierTrackingUrl(order.platform, tracking);
                  const orderCode = valueOf(order, 'orderCode', 'order_code');
                  const storageSource = getStorageSource(order);

                  return (
                    <tr
                      key={order.id || tracking || orderCode || idx}
                      style={{
                        borderBottom: '1px solid var(--border)',
                        background: 'var(--card)',
                        transition: 'background 0.15s ease'
                      }}
                    >
                      {/* THỜI GIAN */}
                      <td style={{ padding: '12px 16px', fontSize: '13px', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                          <Clock size={13} color="var(--text-muted)" />
                          <span>{formatDate(valueOf(order, 'submittedAt', 'submitted_at', 'createdAt', 'created_at'))}</span>
                        </div>
                      </td>

                      {/* KHÁCH HÀNG */}
                      <td style={{ padding: '12px 16px' }}>
                        <div style={{ fontWeight: 700, color: 'var(--text-main)', fontSize: '14px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <span>{customerName || '-'}</span>
                          {customerName && customerName !== '-' && (
                            <button
                              type="button"
                              title="Sao chép tên khách"
                              onClick={() => copyText(customerName, `name_${idx}`)}
                              style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', color: 'var(--text-muted)' }}
                            >
                              {copiedId === `name_${idx}` ? <Check size={13} color="var(--success)" /> : <Copy size={13} />}
                            </button>
                          )}
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '3px' }}>
                          <span style={{ color: 'var(--primary)', fontSize: '13px', fontWeight: 600, fontFamily: 'monospace' }}>{phone || '-'}</span>
                          {phone && (
                            <button
                              type="button"
                              title="Sao chép số điện thoại"
                              onClick={() => copyText(phone, `phone_${idx}`)}
                              style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', color: 'var(--text-muted)' }}
                            >
                              {copiedId === `phone_${idx}` ? <Check size={13} color="var(--success)" /> : <Copy size={13} />}
                            </button>
                          )}
                        </div>
                      </td>

                      {/* MÃ ĐƠN HÀNG */}
                      <td style={{ padding: '12px 16px', fontSize: '13px', fontFamily: 'monospace', color: '#475569' }}>
                        {orderCode ? (
                          <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                            <span>{orderCode}</span>
                            <button
                              type="button"
                              title="Sao chép mã đơn"
                              onClick={() => copyText(orderCode, `code_${idx}`)}
                              style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', color: '#94a3b8' }}
                            >
                              {copiedId === `code_${idx}` ? <Check size={13} color="#16a34a" /> : <Copy size={13} />}
                            </button>
                          </div>
                        ) : '-'}
                      </td>

                      {/* MÃ VẬN ĐƠN */}
                      <td style={{ padding: '12px 16px', fontSize: '13px' }}>
                        {tracking && tracking !== '-' && tracking !== '—' ? (
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <span style={{ fontWeight: 800, color: '#2563eb', fontFamily: 'monospace', letterSpacing: '0.5px' }}>
                              {tracking}
                            </span>
                            <button
                              type="button"
                              title="Sao chép mã vận đơn"
                              onClick={() => copyText(tracking, `tr_${idx}`)}
                              style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', color: '#94a3b8' }}
                            >
                              {copiedId === `tr_${idx}` ? <Check size={13} color="#16a34a" /> : <Copy size={13} />}
                            </button>
                            {trackingUrl && (
                              <a
                                href={trackingUrl}
                                target="_blank"
                                rel="noreferrer"
                                title="Tra cứu hành trình bưu phẩm trên trang hãng"
                                style={{ color: '#2563eb', display: 'flex', alignItems: 'center' }}
                              >
                                <ExternalLink size={13} />
                              </a>
                            )}
                          </div>
                        ) : (
                          <span style={{ color: '#94a3b8', fontStyle: 'italic', fontSize: '12px' }}>Chờ cập nhật mã</span>
                        )}
                      </td>

                      {/* NGUỒN LƯU TRỮ */}
                      <td style={{ padding: '12px 16px', fontSize: '12px', whiteSpace: 'nowrap' }}>
                        {storageSource === 'cloud' ? (
                          <span
                            title="Đơn đã được đồng bộ lên Cloud"
                            style={{ background: '#dcfce7', color: '#15803d', border: '1px solid #bbf7d0', padding: '4px 8px', borderRadius: '999px', fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: '5px' }}
                          >
                            <Cloud size={13} /> Đã lên Cloud
                          </span>
                        ) : (
                          <span
                            title="Đơn hiện chỉ được lưu trên thiết bị này"
                            style={{ background: '#fff7ed', color: '#c2410c', border: '1px solid #fed7aa', padding: '4px 8px', borderRadius: '999px', fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: '5px' }}
                          >
                            <HardDrive size={13} /> Chỉ lưu Local
                          </span>
                        )}
                      </td>

                      {/* TIỀN COD */}
                      <td style={{ padding: '12px 16px', fontSize: '14px', fontWeight: 700, color: '#059669', whiteSpace: 'nowrap' }}>
                        {Number(valueOf(order, 'codAmount', 'cod_amount') || 0).toLocaleString('vi-VN')}đ
                      </td>

                      {/* TRẢ CƯỚC */}
                      <td style={{ padding: '12px 16px', fontSize: '12px', whiteSpace: 'nowrap' }}>
                        {isRecipientFee ? (
                          <span style={{
                            background: '#dcfce7',
                            color: '#15803d',
                            padding: '4px 8px',
                            borderRadius: '6px',
                            fontWeight: 700,
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '4px'
                          }}>
                            🟢 Người nhận trả
                          </span>
                        ) : (
                          <span style={{
                            background: '#dbeafe',
                            color: '#1d4ed8',
                            padding: '4px 8px',
                            borderRadius: '6px',
                            fontWeight: 700,
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '4px'
                          }}>
                            🔵 Shop trả cước
                          </span>
                        )}
                      </td>

                      {/* HÃNG & TÀI KHOẢN GỬI */}
                      <td style={{ padding: '12px 16px', fontSize: '13px' }}>
                        <div style={{ fontWeight: 700, color: '#334155' }}>{carrier}</div>
                        <div style={{ color: '#64748b', fontSize: '12px', marginTop: '2px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                          <User size={11} color="#94a3b8" />
                          <span title="Tên tài khoản / Bưu cục lên đơn">{carrierAccount}</span>
                        </div>
                      </td>

                      {/* ĐỊA CHỈ */}
                      <td style={{ padding: '12px 16px', fontSize: '13px', color: '#475569', minWidth: '220px', lineHeight: '1.4' }}>
                        {valueOf(order, 'address') || '-'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* PAGINATION */}
        {!loading && filtered.length > 0 && (
          <Pagination
            page={page}
            pageSize={pageSize}
            total={filtered.length}
            onPageChange={setPage}
            onPageSizeChange={(newSize) => {
              setPageSize(newSize);
              setPage(1);
            }}
            pageSizeOptions={[10, 25, 50, 100]}
            itemLabel="đơn hàng"
          />
        )}
      </div>
    </div>
  );
}
