import React, { useState, useEffect } from 'react';
import { Truck, CheckCircle2, AlertTriangle, ShieldCheck, Key, Lock, User, RefreshCw, Unlink } from 'lucide-react';
import { AuthSession } from '../../../../domain/auth/auth.session.esm.js';

const CARRIERS_METADATA = {
  vnpost: {
    id: 'vnpost',
    name: 'Vietnam Post (VNPost)',
    badgeColor: '#eab308',
    portalUrl: 'https://my.vnpost.vn',
    desc: 'Hỗ trợ tự động điền đơn, chọn dịch vụ TMĐT, quản lý mã vận đơn bưu điện.'
  },
  jt: {
    id: 'jt',
    name: 'J&T Express',
    badgeColor: '#ef4444',
    portalUrl: 'https://khachhang.jtexpress.vn',
    desc: 'Hỗ trợ tự động điền đơn VIP J&T Express, đồng bộ cước và cập nhật mã vận đơn.'
  },
  viettel: {
    id: 'viettel',
    name: 'Viettel Post',
    badgeColor: '#ea580c',
    portalUrl: 'https://viettelpost.vn',
    desc: 'Hỗ trợ tự động điền đơn Viettel Post, đối soát tiền thu hộ COD và tra cứu hành trình.'
  },
  ghtk: {
    id: 'ghtk',
    name: 'Giao Hàng Tiết Kiệm (GHTK)',
    badgeColor: '#16a34a',
    portalUrl: 'https://khachhang.ghtk.vn',
    desc: 'Hỗ trợ tự động điền đơn GHTK, phân loại hàng hóa và tra cứu hành trình nhanh.'
  }
};

export default function Carriers() {
  const [carriers, setCarriers] = useState([
    { id: 'vnpost', name: 'VNPost', connected: false, account: '' },
    { id: 'jt', name: 'J&T Express', connected: false, account: '' },
    { id: 'viettel', name: 'Viettel Post', connected: false, account: '' },
    { id: 'ghtk', name: 'GHTK', connected: false, account: '' }
  ]);
  const [carrierForms, setCarrierForms] = useState({
    vnpost: { username: '', password: '' },
    jt: { username: '', password: '' },
    viettel: { username: '', password: '' },
    ghtk: { username: '', password: '' }
  });
  const [isConnecting, setIsConnecting] = useState({ vnpost: false, jt: false, viettel: false, ghtk: false });
  const [isLoading, setIsLoading] = useState(true);
  const [status, setStatus] = useState({ type: '', text: '' });

  const showToast = (text, type = 'success') => {
    setStatus({ type, text });
    setTimeout(() => setStatus({ type: '', text: '' }), 4000);
  };

  useEffect(() => {
    loadCarriers();
  }, []);

  const getClient = async () => {
    const configRes = await globalThis.SupabaseCloud.loadConfig();
    const sess = await AuthSession.getSession();
    return { configRes, sess };
  };

  const loadCarriers = async () => {
    try {
      const { configRes, sess } = await getClient();
      if (!sess || !sess.active_shop_id || !sess.access_token) {
        setIsLoading(false);
        return;
      }
      const res = await fetch(
        `${configRes.url}/rest/v1/carrier_configs?shop_id=eq.${sess.active_shop_id}&select=carrier_id,is_connected,account_username`,
        {
          headers: {
            'apikey': configRes.anonKey,
            'Authorization': `Bearer ${sess.access_token}`
          }
        }
      );
      if (res.ok) {
        const rows = await res.json();
        if (rows && rows.length > 0) {
          const byId = {};
          rows.forEach(r => { byId[r.carrier_id] = r; });
          setCarriers(prev => prev.map(c => {
            const db = byId[c.id];
            return db ? { ...c, connected: !!db.is_connected, account: db.account_username || '' } : c;
          }));
        }
      }
    } catch (err) {
      console.error('Lỗi tải cấu hình carrier:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const saveState = async (carrierId, connected, account) => {
    const { configRes, sess } = await getClient();
    if (!sess || !sess.active_shop_id || !sess.access_token) {
      throw new Error('Phiên đăng nhập không hợp lệ.');
    }
    const baseHeaders = {
      'apikey': configRes.anonKey,
      'Authorization': `Bearer ${sess.access_token}`,
      'Content-Type': 'application/json'
    };
    const payload = {
      shop_id: sess.active_shop_id,
      carrier_id: carrierId,
      is_connected: connected,
      account_username: account || null
    };

    const patchRes = await fetch(
      `${configRes.url}/rest/v1/carrier_configs?shop_id=eq.${sess.active_shop_id}&carrier_id=eq.${carrierId}`,
      {
        method: 'PATCH',
        headers: { ...baseHeaders, 'Prefer': 'return=representation' },
        body: JSON.stringify(payload)
      }
    );
    if (patchRes.ok) {
      const rows = await patchRes.json();
      if (rows && rows.length > 0) return;
    }

    const postRes = await fetch(`${configRes.url}/rest/v1/carrier_configs`, {
      method: 'POST',
      headers: { ...baseHeaders, 'Prefer': 'return=representation' },
      body: JSON.stringify(payload)
    });
    if (!postRes.ok) {
      const data = await postRes.json();
      throw new Error(data.message || 'Không cập nhật được cấu hình carrier (cần quyền OWNER).');
    }
  };

  const handleInputChange = (carrierId, field, value) => {
    setCarrierForms(prev => ({
      ...prev,
      [carrierId]: {
        ...prev[carrierId],
        [field]: value
      }
    }));
  };

  const handleConnect = async (carrierId) => {
    const form = carrierForms[carrierId];
    if (!form.username || !form.password) {
      showToast('Vui lòng nhập đầy đủ Tên đăng nhập và Mật khẩu', 'error');
      return;
    }

    setIsConnecting(prev => ({ ...prev, [carrierId]: true }));

    try {
      if (carrierId === 'vnpost' && typeof chrome !== 'undefined' && chrome.runtime?.sendMessage) {
        try {
          const res = await new Promise(resolve => {
            chrome.runtime.sendMessage({ action: 'autoLoginVnpost', ...form }, resolve);
          });
          if (res && res.ok === false) {
            console.warn('AutoLogin background:', res.error);
          }
        } catch (_) {}
      }

      await saveState(carrierId, true, form.username);
      setCarriers(prev => prev.map(c => c.id === carrierId ? { ...c, connected: true, account: form.username } : c));
      setCarrierForms(prev => ({
        ...prev,
        [carrierId]: { ...prev[carrierId], password: '' }
      }));
      showToast(`✅ Đã liên kết tài khoản ${form.username} (${carrierId.toUpperCase()}) thành công!`);
    } catch (err) {
      showToast('❌ Lỗi liên kết: ' + err.message, 'error');
    } finally {
      setIsConnecting(prev => ({ ...prev, [carrierId]: false }));
    }
  };

  const handleDisconnect = async (carrierId) => {
    if (!confirm(`Bạn có chắc muốn ngắt kết nối tài khoản ${carrierId.toUpperCase()}?`)) return;
    try {
      await saveState(carrierId, false, '');
      setCarriers(prev => prev.map(c => c.id === carrierId ? { ...c, connected: false, account: '' } : c));
      showToast('✅ Đã ngắt kết nối hãng vận chuyển.');
    } catch (err) {
      showToast('❌ Lỗi: ' + err.message, 'error');
    }
  };

  return (
    <div>
      <div style={{ marginBottom: '20px' }}>
        <h2 className="page-title" style={{ margin: 0 }}>Cấu Hình Hãng Vận Chuyển</h2>
        <p style={{ color: 'var(--text-muted)', margin: '4px 0 0 0', fontSize: '13px' }}>
          Liên kết tài khoản VNPost và J&T Express để tiện ích tự động điền đơn và đồng bộ dữ liệu cước phí theo thời gian thực.
        </p>
      </div>

      {status.text && (
        <div style={{
          padding: '10px 14px',
          borderRadius: '8px',
          fontSize: '13px',
          fontWeight: 600,
          marginBottom: '16px',
          background: status.type === 'error' ? 'var(--color-danger-bg)' : 'var(--color-success-bg)',
          color: status.type === 'error' ? 'var(--color-danger-text)' : 'var(--color-success-text)',
          border: `1px solid ${status.type === 'error' ? 'rgba(239, 68, 68, 0.2)' : 'rgba(16, 185, 129, 0.2)'}`
        }}>
          {status.text}
        </div>
      )}

      {isLoading ? (
        <div className="card" style={{ textAlign: 'center', padding: '50px', color: 'var(--text-muted)' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '8px' }}>
            <div className="db-status-dot live"></div> Đang tải danh sách hãng vận chuyển...
          </div>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '16px' }}>
          {carriers.map(carrier => {
            const meta = CARRIERS_METADATA[carrier.id] || { name: carrier.name, desc: '', portalUrl: '' };
            const form = carrierForms[carrier.id] || { username: '', password: '' };
            const connecting = isConnecting[carrier.id];

            return (
              <div
                key={carrier.id}
                className="card"
                style={{
                  background: 'var(--card)',
                  border: '1px solid var(--border)',
                  borderRadius: '12px',
                  padding: '20px',
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                  boxShadow: '0 1px 3px rgba(0,0,0,0.03)'
                }}
              >
                <div>
                  {/* Card Header */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <div style={{
                        width: '36px',
                        height: '36px',
                        borderRadius: '8px',
                        background: carrier.connected ? 'var(--primary-light)' : 'var(--bg)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: carrier.connected ? 'var(--primary)' : 'var(--text-muted)'
                      }}>
                        <Truck size={20} />
                      </div>
                      <div>
                        <h3 style={{ margin: 0, fontSize: '15px', fontWeight: 800, color: 'var(--text-main)' }}>
                          {meta.name}
                        </h3>
                        <a
                          href={meta.portalUrl}
                          target="_blank"
                          rel="noreferrer"
                          style={{ fontSize: '11px', color: 'var(--primary)', textDecoration: 'none' }}
                        >
                          {meta.portalUrl.replace('https://', '')} ↗
                        </a>
                      </div>
                    </div>

                    <span style={{
                      padding: '4px 10px',
                      borderRadius: '999px',
                      fontSize: '11.5px',
                      fontWeight: 700,
                      background: carrier.connected ? 'var(--color-success-bg)' : 'var(--bg)',
                      color: carrier.connected ? 'var(--color-success-text)' : 'var(--text-muted)',
                      border: `1px solid ${carrier.connected ? 'rgba(16, 185, 129, 0.25)' : 'var(--border)'}`,
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px'
                    }}>
                      {carrier.connected && <CheckCircle2 size={12} />}
                      {carrier.connected ? 'Đã liên kết' : 'Chưa kết nối'}
                    </span>
                  </div>

                  <p style={{ color: 'var(--text-muted)', fontSize: '12.5px', margin: '0 0 16px 0', lineHeight: '1.4' }}>
                    {meta.desc}
                  </p>
                </div>

                {/* Body Content */}
                {carrier.connected ? (
                  <div style={{ background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: '10px', padding: '14px', marginTop: 'auto' }}>
                    <div style={{ fontSize: '11.5px', color: 'var(--text-muted)', fontWeight: 600 }}>TÀI KHOẢN LIÊN KẾT</div>
                    <div style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-main)', marginTop: '2px', marginBottom: '12px', wordBreak: 'break-all' }}>
                      👤 {carrier.account || 'Mặc định'}
                    </div>
                    <button
                      onClick={() => handleDisconnect(carrier.id)}
                      style={{
                        background: 'transparent',
                        color: 'var(--danger)',
                        border: '1px solid rgba(239, 68, 68, 0.3)',
                        padding: '8px 14px',
                        borderRadius: '8px',
                        fontWeight: 700,
                        fontSize: '12.5px',
                        cursor: 'pointer',
                        width: '100%',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '6px',
                        transition: 'all 0.15s ease'
                      }}
                    >
                      <Unlink size={14} /> Ngắt Kết Nối
                    </button>
                  </div>
                ) : (
                  <div style={{ background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: '10px', padding: '14px', marginTop: 'auto' }}>
                    <div style={{ marginBottom: '10px' }}>
                      <label style={{ display: 'block', fontSize: '11.5px', fontWeight: 700, color: 'var(--text-main)', marginBottom: '4px' }}>
                        Tên đăng nhập {carrier.name}
                      </label>
                      <input
                        type="text"
                        placeholder="Số điện thoại / Email / Mã KH..."
                        value={form.username}
                        onChange={e => handleInputChange(carrier.id, 'username', e.target.value)}
                        style={{
                          width: '100%',
                          boxSizing: 'border-box',
                          padding: '8px 10px',
                          border: '1px solid var(--border)',
                          borderRadius: '6px',
                          background: 'var(--card)',
                          color: 'var(--text-main)',
                          fontSize: '13px',
                          outline: 'none'
                        }}
                      />
                    </div>

                    <div style={{ marginBottom: '14px' }}>
                      <label style={{ display: 'block', fontSize: '11.5px', fontWeight: 700, color: 'var(--text-main)', marginBottom: '4px' }}>
                        Mật khẩu
                      </label>
                      <input
                        type="password"
                        placeholder="Mật khẩu đăng nhập portal..."
                        value={form.password}
                        onChange={e => handleInputChange(carrier.id, 'password', e.target.value)}
                        style={{
                          width: '100%',
                          boxSizing: 'border-box',
                          padding: '8px 10px',
                          border: '1px solid var(--border)',
                          borderRadius: '6px',
                          background: 'var(--card)',
                          color: 'var(--text-main)',
                          fontSize: '13px',
                          outline: 'none'
                        }}
                      />
                    </div>

                    <button
                      onClick={() => handleConnect(carrier.id)}
                      disabled={connecting}
                      style={{
                        background: 'var(--primary)',
                        color: '#fff',
                        border: 'none',
                        padding: '9px 16px',
                        borderRadius: '8px',
                        fontWeight: 700,
                        fontSize: '13px',
                        cursor: connecting ? 'not-allowed' : 'pointer',
                        width: '100%',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '6px',
                        boxShadow: '0 2px 6px rgba(37, 99, 235, 0.25)'
                      }}
                    >
                      {connecting ? <RefreshCw size={14} className="spin" /> : <Key size={14} />}
                      {connecting ? 'Đang kết nối...' : `Liên kết ${carrier.name}`}
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
