import React, { useState, useEffect, useCallback, useRef } from 'react';
import { AuthSession } from '../../domain/auth/auth.session.esm.js';
import Overview from './pages/Overview/Overview';

import ShopProfile from './pages/General/ShopProfile';
import OrderSettings from './pages/General/OrderSettings';
import SyncSettings from './pages/Sync/SyncSettings';
import Notifications from './pages/Notifications/Notifications';
import Security from './pages/Security/Security';
import AuditLogs from './pages/Audit/AuditLogs';
import Subscription from './pages/Subscription/Subscription';

import AddressEngine from './pages/AddressEngine/AddressEngine';
import Team from './pages/Team/Team';
import PermissionMatrix from './pages/Team/PermissionMatrix';
import DeviceManagement from './pages/Security/DeviceManagement';
import AISettings from './pages/AISettings/AISettings';
import Carriers from './pages/Carriers/Carriers';
import Login from './pages/Auth/Login';
import DatabaseManager from './pages/Database/DatabaseManager';
import ServerSettings from './pages/Server/ServerSettings';
import SubmittedOrders from './pages/Orders/SubmittedOrders';
import CustomerHub from './pages/Customers/CustomerHub';
import SupportCenter from './pages/Support/SupportCenter';
import OrderList from './pages/Workspace/OrderList';
import { AuthService } from '../../domain/auth/auth.service.esm.js';

import TopHeader from './components/TopHeader';
import UserProfileCard from './components/UserProfileCard';

const ComingSoon = ({ title }) => (
  <div className="card" style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--text-muted)' }}>
    <h2 style={{ color: 'var(--text-main)' }}>{title}</h2>
    <p>Chức năng này đang được phát triển và sẽ sớm ra mắt trong bản cập nhật tới.</p>
  </div>
);

const TAB_TITLES = {
  'overview': 'Tổng Quan Cửa Hàng',
  'customers': 'Sổ Bạ Khách Hàng (Customer 360)',
  'orders': 'Đơn Hàng Đã Gửi',
  'submitted-orders': 'Đơn Hàng Đã Gửi',
  'drafts': 'Hàng Đợi Đơn Nháp',
  'shop-profile': 'Hồ Sơ Cửa Hàng',
  'team': 'Nhân Viên & Đội Ngũ',
  'permission-matrix': 'Ma Trận Phân Quyền (RBAC)',
  'ai-settings': 'Cấu Hình AI Bóc Tách',
  'address': 'Từ Điển Địa Chỉ (Address Engine)',
  'carriers': 'Kết Nối Hãng Vận Chuyển',
  'devices': 'Quản Lý Thiết Bị',
  'order-settings': 'Cài Đặt Mặc Định Đơn Hàng',
  'sync': 'Trung Tâm Đồng Bộ',
  'notifications': 'Thông Báo Hệ Thống',
  'security': 'Bảo Mật Tài Khoản',
  'audit': 'Nhật Ký Hoạt Động (Audit Logs)',
  'subscription': 'Gói Cước & Bản Quyền',
  'database': 'Bộ Nhớ Cục Bộ (Local Storage)',
  'support': 'Trung Tâm Hỗ Trợ & Báo Lỗi',
  'server': 'Kết Nối Máy Chủ Supabase'
};

const getRoleDisplay = (role) => {
  const roleMap = {
    'OWNER': 'Chủ cửa hàng (Owner)',
    'SHOP_OWNER': 'Chủ cửa hàng (Owner)',
    'MANAGER': 'Quản lý (Manager)',
    'SHOP_MANAGER': 'Quản lý (Manager)',
    'STAFF': 'Nhân viên (Staff)',
    'SHOP_STAFF': 'Nhân viên (Staff)',
    'VIEWER': 'Người xem (Viewer)',
    'SYSTEM_ADMIN': 'Quản trị hệ thống (Admin)'
  };
  return roleMap[role] || role;
};

const getAdminDashboardUrl = () => {
  if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.getURL === 'function') {
    return chrome.runtime.getURL('admin-dashboard/admin.html');
  }
  return '/admin';
};

export default function App() {
  const [activeTab, setActiveTabState] = useState(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      return params.get('tab') || 'overview';
    } catch (_) {
      return 'overview';
    }
  });

  const setActiveTab = (tab) => {
    setActiveTabState(tab);
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('tab', tab);
      window.history.replaceState(null, '', url.toString());
    } catch (_) {}
  };
  const [userRole, setUserRole] = useState('VIEWER'); // real_role từ resolve_dashboard_role
  const [uiRole, setUiRole] = useState('viewer'); // tier: master_admin / admin / shop_admin / viewer
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [shopName, setShopName] = useState('Đang tải...');
  const [currentUser, setCurrentUser] = useState(null);
  const [updateStatus, setUpdateStatus] = useState(null);
  const [appVersion, setAppVersion] = useState(() => {
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime?.getManifest) {
        return chrome.runtime.getManifest()?.version || '1.0.1';
      }
    } catch (_) {}
    return '1.0.1';
  });

  const isConfigAllowed = uiRole !== 'viewer';

  const isInitializingAuth = useRef(false);

  const initAuth = useCallback(async () => {
    if (isInitializingAuth.current) return;
    isInitializingAuth.current = true;
    try {
      const isAuth = await AuthService.isAuthenticated();
      setIsAuthenticated(isAuth);

      if (isAuth) {
        try {
          const configRes = await globalThis.SupabaseCloud.loadConfig();
          if (globalThis.ShopService && typeof globalThis.ShopService.syncShopsFromCloud === 'function') {
            await globalThis.ShopService.syncShopsFromCloud();
          }
          const sess = await AuthSession.getSession();
          const token = sess ? sess.access_token : configRes.anonKey;
          let resolvedUiRole = 'viewer';

          // Set user profile info
          setCurrentUser({
            id: sess?.user?.id || sess?.id || 'AF-USER',
            full_name: sess?.user?.user_metadata?.full_name || sess?.user?.full_name || sess?.full_name || 'Quản trị viên',
            email: sess?.user?.email || sess?.email || 'admin@af-store.vn',
            avatar_url: sess?.user?.user_metadata?.avatar_url || sess?.avatar_url || '',
            role: sess?.role || 'SYSTEM_ADMIN'
          });

          if (sess && sess.active_shop_id) {
            const res = await fetch(`${configRes.url}/rest/v1/shops?select=name&id=eq.${sess.active_shop_id}`, {
              headers: {
                'apikey': configRes.anonKey,
                'Authorization': `Bearer ${token}`
              }
            });
            if (res.ok) {
              const data = await res.json();
              if (data && data.length > 0 && data[0].name) {
                setShopName(data[0].name);
                if (sess.shop_name !== data[0].name) {
                  sess.shop_name = data[0].name;
                  await AuthSession.saveSession(sess);
                }
              }
              else setShopName(sess.shop_name || 'Cửa hàng của tôi');
            } else {
              setShopName(sess?.shop_name || 'Cửa hàng của tôi');
            }
          } else {
            setShopName(sess?.shop_name || 'Cửa hàng của tôi');
          }

          // RBAC thật: resolve_dashboard_role (2 tầng global + shop)
          if (token && !token.startsWith('local_dev_token_')) {
            try {
              const rpcRes = await fetch(`${configRes.url}/rest/v1/rpc/resolve_dashboard_role`, {
                method: 'POST',
                headers: {
                  'apikey': configRes.anonKey,
                  'Authorization': `Bearer ${token}`,
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify({})
              });
              if (rpcRes.ok) {
                const roleData = await rpcRes.json();
                if (roleData && roleData.length > 0 && roleData[0].ui_role) {
                  setUserRole(roleData[0].real_role || 'VIEWER');
                  resolvedUiRole = roleData[0].ui_role;
                  setUiRole(resolvedUiRole);
                }
              }
            } catch (e) {
              console.warn('resolve_dashboard_role lỗi:', e);
            }
          }

          // Fallback: role đã lưu trong session lúc login
          if (resolvedUiRole === 'viewer' && sess && sess.role) {
            const r = sess.role;
            if (r === 'SYSTEM_ADMIN') {
              setUserRole('SYSTEM_ADMIN');
              setUiRole('master_admin');
            } else if (['OWNER', 'MANAGER', 'SHOP_OWNER', 'SHOP_MANAGER'].includes(r)) {
              setUserRole(r);
              setUiRole('shop_admin');
            }
          }
          if (globalThis.SupabaseCloud && typeof globalThis.SupabaseCloud.syncDeviceRecord === 'function') {
            globalThis.SupabaseCloud.syncDeviceRecord().catch(() => {});
          }
        } catch (e) {
          setShopName('Cửa hàng của tôi');
        }
      } else {
        setUserRole('VIEWER');
        setUiRole('viewer');
        setShopName('Cửa hàng của tôi');
        setCurrentUser(null);
      }
    } catch (e) {
      console.warn('initAuth error:', e);
      setIsAuthenticated(false);
      setCurrentUser(null);
    } finally {
      isInitializingAuth.current = false;
      setIsAuthLoading(false);
    }
  }, []);

  useEffect(() => {
    initAuth();

    // Lắng nghe sự kiện AuthEvents
    const onAuthChanged = (data) => {
      if (data && data.isAuthenticated) {
        initAuth();
      } else {
        setIsAuthenticated(false);
        setUserRole('VIEWER');
        setUiRole('viewer');
        setShopName('Cửa hàng của tôi');
        setCurrentUser(null);
      }
    };

    if (typeof globalThis.AuthEvents !== 'undefined' && typeof globalThis.AuthEvents.on === 'function') {
      globalThis.AuthEvents.on('AUTH_STATE_CHANGED', onAuthChanged);
    }

    // Tự động đồng bộ khi chuyển tab hoặc focus cửa sổ
    const handleWindowFocus = () => {
      if (globalThis.ShopService && typeof globalThis.ShopService.syncShopsFromCloud === 'function') {
        globalThis.ShopService.syncShopsFromCloud(true).then(() => initAuth());
      } else {
        initAuth();
      }
    };
    window.addEventListener('focus', handleWindowFocus);

    // Thiết lập Supabase Realtime Channel cho Extension Options
    let realtimeChannel = null;
    (async () => {
      try {
        const configRes = await globalThis.SupabaseCloud?.loadConfig?.();
        if (configRes?.url && configRes?.anonKey) {
          const { createClient } = await import('@supabase/supabase-js');
          const client = createClient(configRes.url, configRes.anonKey, {
            auth: {
              persistSession: false,
              autoRefreshToken: false,
              detectSessionInUrl: false
            }
          });
          realtimeChannel = client.channel('options-realtime-sync')
            .on('postgres_changes', { event: '*', schema: 'public', table: 'shops' }, () => {
              if (globalThis.ShopService?.syncShopsFromCloud) {
                globalThis.ShopService.syncShopsFromCloud(true).then(() => initAuth());
              }
            })
            .on('postgres_changes', { event: '*', schema: 'public', table: 'shop_members' }, () => {
              if (globalThis.ShopService?.syncShopsFromCloud) {
                globalThis.ShopService.syncShopsFromCloud(true).then(() => initAuth());
              }
            })
            .subscribe();
        }
      } catch (err) {
        console.warn('[OptionsRealtime] Realtime subscription fallback:', err);
      }
    })();

    // Lắng nghe thay đổi storage từ chrome.storage.onChanged
    const handleStorageChange = (changes, namespace) => {
      if (namespace === 'local') {
        if (changes.vnpost_session) {
          const oldSess = changes.vnpost_session.oldValue;
          const newSess = changes.vnpost_session.newValue;
          if (!oldSess !== !newSess || oldSess?.access_token !== newSess?.access_token || oldSess?.user?.id !== newSess?.user?.id) {
            initAuth();
          }
        }
        if (changes.activeShopName?.newValue) {
          setShopName(changes.activeShopName.newValue);
        }
        if (changes.app_update_status) {
          setUpdateStatus(changes.app_update_status.newValue);
        }
      }
    };

    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener(handleStorageChange);
    }

    // Đọc trạng thái update từ storage khi khởi tạo
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['app_update_status'], res => {
        if (res?.app_update_status) setUpdateStatus(res.app_update_status);
      });
    }

    // Yêu cầu Service Worker kiểm tra phiên bản mới từ Supabase
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({ action: 'checkAppUpdate' }, res => {
        if (res?.ok && res?.status) setUpdateStatus(res.status);
      });
    }

    const handleUpdateMsg = (msg) => {
      if (msg && msg.type === 'app_update_changed' && msg.status) {
        setUpdateStatus(msg.status);
      }
    };
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
      chrome.runtime.onMessage.addListener(handleUpdateMsg);
    }

    return () => {
      window.removeEventListener('focus', handleWindowFocus);
      if (realtimeChannel) {
        realtimeChannel.unsubscribe?.();
      }
      if (typeof globalThis.AuthEvents !== 'undefined' && typeof globalThis.AuthEvents.off === 'function') {
        globalThis.AuthEvents.off('AUTH_STATE_CHANGED', onAuthChanged);
      }
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
        chrome.storage.onChanged.removeListener(handleStorageChange);
      }
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
        chrome.runtime.onMessage.removeListener(handleUpdateMsg);
      }
    };
  }, [initAuth]);

  useEffect(() => {
    const navigate = event => {
      const tab = event?.detail?.tab;
      if (tab && Object.prototype.hasOwnProperty.call(TAB_TITLES, tab)) setActiveTab(tab);
    };
    window.addEventListener('options:navigate', navigate);
    return () => window.removeEventListener('options:navigate', navigate);
  }, []);

  useEffect(() => {
    if (!isAuthenticated) return;
    const match = window.location.hash.match(/(?:^#\/join\?token=|[?&]token=)([a-f0-9]+)/i);
    if (!match) return;
    let cancelled = false;
    (async () => {
      try {
        const config = await globalThis.SupabaseCloud.loadConfig();
        const session = await AuthSession.getSession();
        const response = await fetch(`${config.url}/rest/v1/rpc/accept_shop_invite`, {
          method: 'POST',
          headers: { apikey: config.anonKey, Authorization: `Bearer ${session.access_token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ p_token: match[1] })
        });
        const data = await response.json().catch(() => null);
        if (!response.ok || data?.success === false) throw new Error(data?.message || 'Không thể tham gia cửa hàng.');
        if (cancelled) return;
        session.active_shop_id = data.shop_id;
        await AuthSession.saveSession(session);
        window.history.replaceState(null, '', `${window.location.pathname}?tab=overview`);
        setActiveTab('overview');
        await initAuth();
        alert('Đã tham gia cửa hàng thành công.');
      } catch (error) {
        if (!cancelled) alert(error.message);
      }
    })();
    return () => { cancelled = true; };
  }, [isAuthenticated, initAuth]);

  if (isAuthLoading) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100vh', background: 'var(--bg)', color: 'var(--text-main)', gap: '14px' }}>
        <div style={{ width: '38px', height: '38px', borderRadius: '50%', border: '3px solid var(--border)', borderTopColor: 'var(--primary)', animation: 'spin 0.8s linear infinite' }}></div>
        <div style={{ fontSize: '13.5px', fontWeight: 600, color: 'var(--text-muted)' }}>Đang tải dữ liệu cửa hàng...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Login onLoginSuccess={() => initAuth()} />;
  }

  const renderContent = () => {
    if (!isConfigAllowed && ['team', 'permission-matrix', 'ai-settings', 'carriers', 'shop-profile', 'order-settings', 'sync', 'notifications', 'security', 'audit', 'subscription', 'devices', 'database', 'address', 'server'].includes(activeTab)) {
      return (
        <div className="card" style={{ textAlign: 'center', padding: '60px', color: 'var(--danger)' }}>
          <h2>Truy Cập Bị Từ Chối (Access Denied)</h2>
          <p>Bạn không có quyền xem trang này. Cần quyền Chủ cửa hàng (OWNER) hoặc Quản lý (MANAGER).</p>
        </div>
      );
    }

    switch (activeTab) {
      case 'overview':
        return <Overview setActiveTab={setActiveTab} uiRole={uiRole} />;
      case 'customers':
        return <CustomerHub />;
      case 'address':
        return <AddressEngine />;
      case 'team':
        return <Team />;
      case 'permission-matrix':
        return <PermissionMatrix />;
      case 'devices':
        return <DeviceManagement />;
      case 'ai-settings':
        return <AISettings />;
      case 'database':
        return <DatabaseManager />;
      case 'orders':
      case 'submitted-orders':
        return <SubmittedOrders />;
      case 'drafts':
      case 'draft-queue':
        return <OrderList />;
      case 'server':
        if (uiRole !== 'master_admin' && userRole !== 'SYSTEM_ADMIN') {
          return (
            <div className="card" style={{ textAlign: 'center', padding: '60px', color: 'var(--danger)' }}>
              <h2>Truy Cập Bị Từ Chối (Admin Only)</h2>
              <p>Cấu hình máy chủ Supabase Cloud chỉ dành cho Quản trị viên hệ thống (Master Admin / SYSTEM_ADMIN).</p>
            </div>
          );
        }
        return <ServerSettings />;
      case 'carriers':
        return <Carriers />;
      case 'shop-profile':
        return <ShopProfile />;
      case 'order-settings':
        return <OrderSettings />;
      case 'sync':
        return <SyncSettings />;
      case 'notifications':
        return <Notifications />;
      case 'security':
        return <Security />;
      case 'audit':
        return <AuditLogs />;
      case 'subscription':
        return <Subscription />;
      case 'support':
        return <SupportCenter />;
      default:
        return <ComingSoon title="Chức Năng" />;
    }
  };

  const handleLogout = async () => {
    await AuthService.logout();
    setIsAuthenticated(false);
    setCurrentUser(null);
  };

  const handleOpenAdminDashboard = () => {
    window.open(getAdminDashboardUrl());
  };

  return (
    <div className="options-layout">
      {/* SIDEBAR */}
      <aside className="sidebar">
        <div className="nav-brand">
          <div className="nav-brand-badge">AF</div>
          <div className="nav-brand-info">
            <span className="nav-brand-title">Quản Lý Cửa Hàng</span>
            <span className="nav-brand-version-badge" title={`Phiên bản Auto Fill Order: v${appVersion}`}>v{appVersion}</span>
          </div>
        </div>

        <nav className="nav-menu">
          <button className={`nav-item ${activeTab === 'overview' ? 'active' : ''}`} onClick={() => setActiveTab('overview')}>Tổng quan</button>

          <div className="nav-section-title">Khách hàng & Vận hành</div>
          <button className={`nav-item ${activeTab === 'customers' ? 'active' : ''}`} onClick={() => setActiveTab('customers')}>Sổ bạ Khách hàng (CRM)</button>
          <button className={`nav-item ${activeTab === 'submitted-orders' || activeTab === 'orders' ? 'active' : ''}`} onClick={() => setActiveTab('submitted-orders')}>Đơn hàng đã gửi</button>
          <button className={`nav-item ${activeTab === 'drafts' || activeTab === 'draft-queue' ? 'active' : ''}`} onClick={() => setActiveTab('drafts')}>Hàng đợi đơn nháp</button>

          {isConfigAllowed && (
            <>
              <div className="nav-section-title">Cấu hình cửa hàng</div>
              <button className={`nav-item ${activeTab === 'shop-profile' ? 'active' : ''}`} onClick={() => setActiveTab('shop-profile')}>Hồ sơ cửa hàng</button>
              <button className={`nav-item ${activeTab === 'team' ? 'active' : ''}`} onClick={() => setActiveTab('team')}>Nhân viên & Đội ngũ</button>
              <button className={`nav-item ${activeTab === 'permission-matrix' ? 'active' : ''}`} onClick={() => setActiveTab('permission-matrix')}>Ma trận phân quyền</button>
              <button className={`nav-item ${activeTab === 'ai-settings' ? 'active' : ''}`} onClick={() => setActiveTab('ai-settings')}>Cấu hình AI bóc tách</button>
              <button className={`nav-item ${activeTab === 'address' ? 'active' : ''}`} onClick={() => setActiveTab('address')}>Từ điển địa chỉ</button>
              <button className={`nav-item ${activeTab === 'carriers' ? 'active' : ''}`} onClick={() => setActiveTab('carriers')}>Hãng vận chuyển</button>
              <button className={`nav-item ${activeTab === 'devices' ? 'active' : ''}`} onClick={() => setActiveTab('devices')}>Quản lý thiết bị</button>
              <button className={`nav-item ${activeTab === 'order-settings' ? 'active' : ''}`} onClick={() => setActiveTab('order-settings')}>Cài đặt mặc định đơn</button>
              <button className={`nav-item ${activeTab === 'sync' ? 'active' : ''}`} onClick={() => setActiveTab('sync')}>Đồng bộ dữ liệu</button>
              <button className={`nav-item ${activeTab === 'notifications' ? 'active' : ''}`} onClick={() => setActiveTab('notifications')}>Thông báo hệ thống</button>
              <button className={`nav-item ${activeTab === 'security' ? 'active' : ''}`} onClick={() => setActiveTab('security')}>Bảo mật tài khoản</button>
              <button className={`nav-item ${activeTab === 'audit' ? 'active' : ''}`} onClick={() => setActiveTab('audit')}>Nhật ký hoạt động</button>
              <button className={`nav-item ${activeTab === 'subscription' ? 'active' : ''}`} onClick={() => setActiveTab('subscription')}>Gói cước & Bản quyền</button>
              <button className={`nav-item ${activeTab === 'support' ? 'active' : ''}`} onClick={() => setActiveTab('support')}>Hỗ trợ & Báo lỗi (Tickets)</button>
              <button className={`nav-item ${activeTab === 'database' ? 'active' : ''}`} onClick={() => setActiveTab('database')}>Bộ nhớ lưu trữ</button>
              {(uiRole === 'master_admin' || userRole === 'SYSTEM_ADMIN') && (
                <button className={`nav-item ${activeTab === 'server' ? 'active' : ''}`} onClick={() => setActiveTab('server')}>
                  Kết nối máy chủ (Server Connection) <span style={{ fontSize: '10px', padding: '1px 5px', borderRadius: '4px', background: 'var(--color-warning-bg)', color: 'var(--color-warning-text)', marginLeft: '4px' }}>Admin</span>
                </button>
              )}
            </>
          )}
        </nav>

        {/* SIDEBAR FOOTER (USER PROFILE CARD) */}
        <div className="sidebar-footer">
          <UserProfileCard
            currentUser={currentUser}
            userRole={userRole}
            uiRole={uiRole}
            appVersion={appVersion}
            onOpenAdmin={handleOpenAdminDashboard}
            onLogout={handleLogout}
          />
        </div>
      </aside>

      {/* MAIN CONTENT AREA */}
      <div className="main-wrapper">
        {/* TOPBAR */}
        <TopHeader
          currentUser={currentUser}
          userRole={userRole}
          uiRole={uiRole}
          shopName={shopName}
          appVersion={appVersion}
          isDbConnected={isAuthenticated}
          activeTab={activeTab}
          onOpenAdmin={handleOpenAdminDashboard}
          onSearch={(query) => {
            // Optional callback for global search
          }}
          onLogout={handleLogout}
        />

        {/* CONTENT */}
        <main className="main-content">
          <div className="content-container">
            {/* UPDATE ALERT BANNER */}
            {updateStatus?.hasUpdate && (
              <div style={{
                background: updateStatus.isBlocked ? '#fef2f2' : '#eff6ff',
                border: `1px solid ${updateStatus.isBlocked ? '#f87171' : '#bfdbfe'}`,
                borderRadius: '10px',
                padding: '14px 18px',
                marginBottom: '20px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                gap: '12px'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span style={{ fontSize: '20px' }}>{updateStatus.isBlocked ? '⚠️' : '🎉'}</span>
                  <div>
                    <div style={{ fontWeight: 800, fontSize: '13.5px', color: updateStatus.isBlocked ? '#991b1b' : '#1e40af' }}>
                      {updateStatus.isBlocked ? 'YÊU CẦU NÂNG CẤP PHIÊN BẢN (BẮT BUỘC):' : 'ĐÃ CÓ PHIÊN BẢN CẬP NHẬT MỚI:'}
                    </div>
                    <div style={{ fontSize: '12.5px', marginTop: '2px', color: updateStatus.isBlocked ? '#b91c1c' : '#1d4ed8' }}>
                      Đã có phiên bản <strong>v{updateStatus.latestVersion}</strong> (phiên bản đang dùng: v{updateStatus.currentVersion}).
                      {updateStatus.releaseNotes && <span> — {updateStatus.releaseNotes}</span>}
                    </div>
                  </div>
                </div>
                {updateStatus.downloadUrl && (
                  <a
                    href={updateStatus.downloadUrl}
                    target="_blank"
                    rel="noreferrer"
                    style={{
                      background: updateStatus.isBlocked ? '#dc2626' : '#2563eb',
                      color: '#ffffff',
                      textDecoration: 'none',
                      padding: '8px 16px',
                      borderRadius: '6px',
                      fontWeight: 700,
                      fontSize: '12.5px',
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '6px',
                      boxShadow: updateStatus.isBlocked ? '0 2px 4px rgba(220,38,38,0.3)' : '0 2px 4px rgba(37,99,235,0.25)'
                    }}
                  >
                    🚀 Tải Bản Cập Nhật v{updateStatus.latestVersion}
                  </a>
                )}
              </div>
            )}
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
}
