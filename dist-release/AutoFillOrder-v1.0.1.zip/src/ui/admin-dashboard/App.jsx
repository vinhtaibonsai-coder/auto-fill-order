import React, { useEffect, useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import FastOperationsHub from './components/FastOperationsHub';
import ImpersonationBanner from './components/ImpersonationBanner';
import CreateShopModal from './modals/CreateShopModal';
import TopupQuotaModal from './modals/TopupQuotaModal';
import PublishReleaseModal from './modals/PublishReleaseModal';
import InviteAdminModal from './modals/InviteAdminModal';
import Overview from './pages/Overview/Overview';
import ShopList from './pages/Shops/ShopList';
import Quotas from './pages/AIPlatform/Quotas';
import Users from './pages/Users/Users';
import SystemHealth from './pages/SystemHealth/SystemHealth';
import Subscriptions from './pages/Subscriptions/Subscriptions';
import FeatureFlags from './pages/Features/FeatureFlags';
import AddressDataset from './pages/Address/AddressDataset';
import CarrierHealth from './pages/Carriers/CarrierHealth';
import DeviceManagement from './pages/Devices/DeviceManagement';
import SecurityRLS from './pages/Security/SecurityRLS';
import SupportTickets from './pages/Support/SupportTickets';
import ReleaseCenter from './pages/Releases/ReleaseCenter';
import AdminLogin from './pages/Login/AdminLogin';
import { AuthService } from '../../domain/auth/auth.service.esm.js';
import { AdminService } from '../../domain/admin/admin.service.js';

const PAGES = {
  overview: Overview, shops: ShopList, users: Users, subscriptions: Subscriptions,
  'ai-platform': Quotas, features: FeatureFlags, address: AddressDataset,
  carriers: CarrierHealth, devices: DeviceManagement, security: SecurityRLS,
  'system-health': SystemHealth, support: SupportTickets, releases: ReleaseCenter
};

export default function App() {
  const [activeTab, setActiveTabState] = useState(() => new URLSearchParams(window.location.search).get('tab') || 'overview');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authLoading, setAuthLoading] = useState(true);
  const [modal, setModal] = useState(null);
  const [shops, setShops] = useState([]);
  const [impersonation, setImpersonation] = useState(() => { try { return JSON.parse(sessionStorage.getItem('afo_admin_impersonation') || 'null'); } catch (_) { return null; } });

  const setActiveTab = tab => {
    setActiveTabState(PAGES[tab] ? tab : 'overview');
    const url = new URL(window.location.href); url.searchParams.set('tab', tab); window.history.replaceState(null, '', url);
  };

  useEffect(() => {
    (async () => {
      try {
        if (await AuthService.isAuthenticated()) {
          const role = await AuthService.getUserRole();
          if (['ADMIN', 'SUPER_ADMIN', 'SYSTEM_ADMIN'].includes(role)) {
            setIsAuthenticated(true);
            if (globalThis.SupabaseCloud && typeof globalThis.SupabaseCloud.syncDeviceRecord === 'function') {
              globalThis.SupabaseCloud.syncDeviceRecord().catch(() => {});
            }
          } else {
            await AuthService.logout();
          }
        }
      } catch (error) { console.error('Auth Check Error:', error); }
      finally { setAuthLoading(false); }
    })();
  }, []);

  useEffect(() => {
    if (!isAuthenticated) return undefined;
    
    const refreshShops = () => {
      AdminService.getShopsList().then(result => result.success && setShops(result.data || []));
    };
    refreshShops();

    const listener = event => { 
      setImpersonation(event.detail); 
      sessionStorage.setItem('afo_admin_impersonation', JSON.stringify(event.detail)); 
    };
    const refreshListener = () => {
      refreshShops();
    };

    window.addEventListener('admin:impersonate', listener);
    window.addEventListener('admin:refresh_data', refreshListener);

    // Thiết lập Supabase Realtime Channel
    let realtimeChannel = null;
    (async () => {
      try {
        const configRes = await globalThis.SupabaseCloud?.loadConfig?.();
        if (configRes?.url && configRes?.anonKey) {
          const { createClient } = await import('@supabase/supabase-js');
          const client = createClient(configRes.url, configRes.anonKey, {
            auth: {
              persistSession: false,
              autoRefreshToken: false,
              detectSessionInUrl: false
            }
          });
          realtimeChannel = client.channel('admin-dashboard-realtime')
            .on('postgres_changes', { event: '*', schema: 'public', table: 'shops' }, () => {
              window.dispatchEvent(new CustomEvent('admin:refresh_data', { detail: { table: 'shops' } }));
            })
            .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, () => {
              window.dispatchEvent(new CustomEvent('admin:refresh_data', { detail: { table: 'profiles' } }));
            })
            .on('postgres_changes', { event: '*', schema: 'public', table: 'shop_members' }, () => {
              window.dispatchEvent(new CustomEvent('admin:refresh_data', { detail: { table: 'shop_members' } }));
            })
            .on('postgres_changes', { event: '*', schema: 'public', table: 'shop_quotas' }, () => {
              window.dispatchEvent(new CustomEvent('admin:refresh_data', { detail: { table: 'shop_quotas' } }));
            })
            .subscribe();
        }
      } catch (err) {
        console.warn('[AdminRealtime] Realtime subscription fallback to polling/events:', err);
      }
    })();

    return () => {
      window.removeEventListener('admin:impersonate', listener);
      window.removeEventListener('admin:refresh_data', refreshListener);
      if (realtimeChannel) {
        realtimeChannel.unsubscribe?.();
      }
    };
  }, [isAuthenticated]);

  if (authLoading) return <div style={{ display: 'grid', placeItems: 'center', height: '100vh', color: '#64748b', fontWeight: 600 }}>Đang kiểm tra phiên làm việc…</div>;
  if (!isAuthenticated) return <AdminLogin onLoginSuccess={() => setIsAuthenticated(true)} />;

  const logout = async () => { if (window.confirm('Bạn có chắc chắn muốn đăng xuất khỏi Admin Portal?')) { await AuthService.logout(); setIsAuthenticated(false); } };
  const runAction = async (operation, message) => {
    const result = await operation();
    if (!result.success) {
      window.alert(result.error || 'Thao tác thất bại.');
      return result;
    }
    window.alert(message);
    setModal(null);
    AdminService.getShopsList().then(r => r.success && setShops(r.data || []));
    window.dispatchEvent(new CustomEvent('admin:refresh_data', { detail: { action: 'completed' } }));
    return result;
  };
  const Page = PAGES[activeTab] || Overview;

  return <div className="admin-layout">
    <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
    <main className="main-content">
      <Header onLogout={logout} operations={<FastOperationsHub onCreateShop={() => setModal('shop')} onTopupQuota={() => setModal('quota')} onInviteAdmin={() => setModal('admin')} onPublishRelease={() => setModal('release')} />} />
      <ImpersonationBanner session={impersonation} onExit={() => { setImpersonation(null); sessionStorage.removeItem('afo_admin_impersonation'); }} />
      <div className="page-container"><Page /></div>
    </main>
    <CreateShopModal open={modal === 'shop'} onClose={() => setModal(null)} onSubmit={form => runAction(() => AdminService.createShopWithAccount(form), 'Đã tạo Shop và tài khoản chủ Shop.')} />
    <TopupQuotaModal open={modal === 'quota'} shops={shops} onClose={() => setModal(null)} onSubmit={({ shopId, amount }) => runAction(() => AdminService.topupQuota(shopId, amount), `Đã cấp thêm ${amount} lượt AI.`)} />
    <PublishReleaseModal open={modal === 'release'} onClose={() => setModal(null)} onSubmit={data => runAction(() => AdminService.publishRelease(data), 'Đã phát hành phiên bản Extension.')} />
    <InviteAdminModal open={modal === 'admin'} onClose={() => setModal(null)} onSubmit={data => runAction(() => AdminService.createAdminAccount(data), 'Đã tạo tài khoản Admin.')} />
  </div>;
}
