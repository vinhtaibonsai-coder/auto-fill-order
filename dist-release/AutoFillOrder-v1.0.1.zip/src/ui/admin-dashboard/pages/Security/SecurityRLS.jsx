import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ShieldCheck, RefreshCw, Clock, User, Activity } from 'lucide-react';
import { AdminService } from '../../../../domain/admin/admin.service.js';
import FilterBar from '../../components/FilterBar';
import ExportButton from '../../components/ExportButton';

export default function SecurityRLS() {
  const [data, setData] = useState({ total: 0, logs: [] });
  const [actor, setActor] = useState('');
  const [action, setAction] = useState('');
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const r = await AdminService.getSecurityStats();
    if (r.success) {
      setData(r.data || { total: 0, logs: [] });
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const actions = [...new Set((data.logs || []).map(l => l.action).filter(Boolean))];
  const rows = useMemo(() => (data.logs || []).filter(l => (
    (!actor || `${l.actor_id || l.user_id || ''}`.includes(actor)) &&
    (!action || l.action === action)
  )), [data, actor, action]);

  return (
    <div style={{ display: 'grid', gap: 20 }}>
      {/* Header */}
      <div>
        <h2 style={{ fontSize: 20, fontWeight: 800, color: '#0f172a', margin: '0 0 4px 0', display: 'flex', alignItems: 'center', gap: 8 }}>
          <ShieldCheck size={22} color="#2563eb" />
          Bảo Mật & Nhật Ký Kiểm Toán (Audit Logs)
        </h2>
        <p style={{ margin: 0, fontSize: 13, color: '#64748b' }}>
          Ghi nhận toàn bộ thao tác nhạy cảm, thay đổi dữ liệu và định danh người thực hiện (Actor ID)
        </p>
      </div>

      {/* Filter Bar */}
      <FilterBar
        value={actor}
        onSearch={setActor}
        placeholder="Lọc theo Actor ID / User ID..."
        filters={[
          {
            key: 'action',
            label: 'Hành động',
            value: action,
            onChange: setAction,
            options: [
              { value: '', label: 'Tất cả hành động' },
              ...actions.map(value => ({ value, label: value }))
            ]
          }
        ]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              onClick={load}
              style={{
                padding: '7px 12px',
                fontSize: 12,
                background: '#ffffff',
                border: '1px solid #cbd5e1',
                borderRadius: 8,
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                gap: 4
              }}
            >
              <RefreshCw size={13} className={loading ? 'dash-spin' : ''} /> Tải lại
            </button>
            <ExportButton rows={rows} filename="nhat-ky-audit-logs.csv" />
          </div>
        }
      />

      {/* Logs Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden', border: '1px solid #e2e8f0', borderRadius: 12 }}>
        <div style={{ overflowX: 'auto' }}>
          <table>
            <thead>
              <tr>
                <th>Thời điểm</th>
                <th>Người thực hiện (Actor)</th>
                <th>Hành động</th>
                <th>Đối tượng tác động</th>
                <th>Chi tiết dữ liệu (Payload)</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={5} style={{ textAlign: 'center', padding: '36px 20px', color: '#94a3b8' }}>
                    {loading ? 'Đang tải nhật ký kiểm toán...' : 'Không tìm thấy bản ghi nhật ký nào.'}
                  </td>
                </tr>
              ) : (
                rows.map(l => (
                  <tr key={l.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#334155', fontSize: 12.5 }}>
                        <Clock size={13} color="#64748b" />
                        <span>{new Date(l.created_at).toLocaleString('vi-VN')}</span>
                      </div>
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <User size={13} color="#2563eb" />
                        <span style={{ fontWeight: 600, color: '#0f172a', fontSize: 13, fontFamily: 'monospace' }}>
                          {l.actor_id || l.user_id || 'system'}
                        </span>
                      </div>
                    </td>
                    <td>
                      <span
                        style={{
                          background: '#eff6ff',
                          color: '#1d4ed8',
                          border: '1px solid #bfdbfe',
                          padding: '2px 8px',
                          borderRadius: 6,
                          fontSize: 11.5,
                          fontWeight: 700
                        }}
                      >
                        {l.action}
                      </span>
                    </td>
                    <td>
                      <span style={{ color: '#475569', fontSize: 12.5 }}>
                        {l.entity_type || l.target_resource} <small style={{ fontFamily: 'monospace' }}>{l.entity_id || l.target_id}</small>
                      </span>
                    </td>
                    <td>
                      <code style={{ background: '#f8fafc', padding: '4px 8px', borderRadius: 6, fontSize: 11.5, color: '#334155', display: 'block', maxWidth: 360, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', border: '1px solid #e2e8f0' }}>
                        {JSON.stringify(l.details || l.payload || {}).slice(0, 180)}
                      </code>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
