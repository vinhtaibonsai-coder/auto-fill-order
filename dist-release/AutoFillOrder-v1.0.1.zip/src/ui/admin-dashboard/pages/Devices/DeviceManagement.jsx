import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Smartphone, RefreshCw, ShieldAlert, CheckCircle, XCircle } from 'lucide-react';
import { AdminService } from '../../../../domain/admin/admin.service.js';
import FilterBar from '../../components/FilterBar';
import Pagination from '../../components/Pagination';

export default function DeviceManagement() {
  const [rows, setRows] = useState([]);
  const [shop, setShop] = useState('');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  useEffect(() => {
    setPage(1);
  }, [shop, search]);

  const load = useCallback(async () => {
    setLoading(true);
    const r = await AdminService.listDevices();
    if (r.success) {
      setRows(r.data || []);
    } else {
      alert(r.error);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
    const handleRefresh = () => {
      load();
    };
    window.addEventListener('admin:refresh_data', handleRefresh);
    return () => window.removeEventListener('admin:refresh_data', handleRefresh);
  }, [load]);

  const shops = useMemo(() => [
    ...new Map(rows.filter(r => r.shop_id).map(r => [r.shop_id, r.shop_name || r.shop_id])).entries()
  ], [rows]);

  const filtered = useMemo(() => {
    return rows.filter(r => {
      const matchShop = !shop || r.shop_id === shop;
      const matchSearch = `${r.email || ''} ${r.device_name || ''}`.toLowerCase().includes(search.toLowerCase());
      return matchShop && matchSearch;
    });
  }, [rows, shop, search]);

  const paginatedRows = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, page, pageSize]);

  const one = async (d) => {
    const action = d.revoked ? 'Khôi phục' : 'Thu hồi';
    if (!confirm(`Bạn có chắc chắn muốn ${action} thiết bị "${d.device_name}"?`)) return;
    const r = await AdminService.revokeDevice(d.device_id, !d.revoked);
    if (r.success) {
      load();
    } else {
      alert(r.error);
    }
  };

  const all = async () => {
    if (!shop || !confirm('⚠️ CẢNH BÁO: Thu hồi toàn bộ thiết bị đang hoạt động của Shop này?')) return;
    const r = await AdminService.revokeShopDevices(shop);
    if (r.success) {
      alert('Đã thu hồi thành công các thiết bị của Shop.');
      load();
    } else {
      alert(r.error);
    }
  };

  return (
    <div style={{ display: 'grid', gap: 20 }}>
      {/* Header */}
      <div>
        <h2 style={{ fontSize: 20, fontWeight: 800, color: '#0f172a', margin: '0 0 4px 0', display: 'flex', alignItems: 'center', gap: 8 }}>
          <Smartphone size={22} color="#2563eb" />
          Quản Lý Thiết Bị Đăng Nhập (Device Management)
        </h2>
        <p style={{ margin: 0, fontSize: 13, color: '#64748b' }}>
          Kiểm soát các trình duyệt máy tính / Extension đang kết nối vào hệ thống và thu hồi thiết bị khi cần
        </p>
      </div>

      {/* Filter & Bulk Actions */}
      <FilterBar
        onSearch={setSearch}
        placeholder="Tìm theo tên thiết bị, email..."
        filters={[
          {
            key: 'shop',
            label: 'Cửa hàng',
            value: shop,
            onChange: setShop,
            options: [
              { value: '', label: 'Tất cả cửa hàng' },
              ...shops.map(([value, label]) => ({ value, label }))
            ]
          }
        ]}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              disabled={!shop}
              onClick={all}
              style={{
                background: shop ? '#fee2e2' : '#f1f5f9',
                color: shop ? '#dc2626' : '#94a3b8',
                border: shop ? '1px solid #fecaca' : '1px solid #e2e8f0',
                padding: '7px 12px',
                fontSize: 12,
                fontWeight: 700,
                borderRadius: 8,
                cursor: shop ? 'pointer' : 'not-allowed',
                display: 'inline-flex',
                alignItems: 'center',
                gap: 4
              }}
            >
              <ShieldAlert size={14} /> Thu hồi toàn bộ Shop
            </button>
            <button
              onClick={load}
              style={{
                padding: '7px 12px',
                fontSize: 12,
                background: '#ffffff',
                border: '1px solid #cbd5e1',
                borderRadius: 8,
                cursor: 'pointer',
                display: 'inline-flex',
                alignItems: 'center',
                gap: 4
              }}
            >
              <RefreshCw size={13} className={loading ? 'dash-spin' : ''} /> Tải lại
            </button>
          </div>
        }
      />

      {/* Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden', border: '1px solid #e2e8f0', borderRadius: 12 }}>
        <div style={{ overflowX: 'auto' }}>
          <table>
            <thead>
              <tr>
                <th>Thiết bị / Trình duyệt</th>
                <th>Tài khoản người dùng</th>
                <th>Cửa hàng</th>
                <th>Phiên bản</th>
                <th>Hoạt động gần nhất</th>
                <th>Trạng thái</th>
                <th style={{ textAlign: 'right' }}>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} style={{ textAlign: 'center', padding: '36px 20px', color: '#94a3b8' }}>
                    {loading ? 'Đang tải danh sách thiết bị...' : 'Không có thiết bị nào phù hợp.'}
                  </td>
                </tr>
              ) : (
                paginatedRows.map(d => {
                  const meta = d.metadata || {};
                  const browserName = d.browser || meta.browser || d.device_name || 'Google Chrome';
                  const isCocCoc = /coccoc|cốc cốc/i.test(browserName);
                  const isEdge = /edge|edg/i.test(browserName);
                  const isBrave = /brave/i.test(browserName);
                  const isFirefox = /firefox/i.test(browserName);
                  const isOpera = /opera/i.test(browserName);

                  const browserColor = isCocCoc ? '#10b981' : isEdge ? '#0284c7' : isBrave ? '#f97316' : isFirefox ? '#ea580c' : isOpera ? '#ef4444' : '#2563eb';
                  const browserBg = isCocCoc ? '#ecfdf5' : isEdge ? '#f0f9ff' : isBrave ? '#fff7ed' : isFirefox ? '#fff7ed' : isOpera ? '#fef2f2' : '#eff6ff';

                  const osText = d.os_info || meta.os || (d.device_name?.includes('Mac') ? 'macOS' : 'Windows 10/11');
                  const screenRes = meta.screenResolution || '1920 x 1080';

                  // Tính thời gian online
                  const lastDate = d.last_seen || d.last_active_at;
                  let onlineStatus = 'offline';
                  let statusText = 'Offline';
                  let timeAgoText = '—';
                  if (lastDate) {
                    const diffMins = Math.floor((Date.now() - new Date(lastDate).getTime()) / 60000);
                    timeAgoText = new Date(lastDate).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });
                    if (diffMins <= 5) {
                      onlineStatus = 'online';
                      statusText = '● Đang online';
                    } else if (diffMins <= 60) {
                      onlineStatus = 'recent';
                      statusText = `● ${diffMins}p trước`;
                    } else {
                      onlineStatus = 'offline';
                      statusText = '● Offline';
                    }
                  }

                  return (
                    <tr key={d.device_id || d.id}>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <div style={{
                            width: 34, height: 34, borderRadius: 8,
                            background: browserBg, color: browserColor,
                            border: `1px solid ${browserColor}33`,
                            display: 'grid', placeItems: 'center', fontWeight: 800, fontSize: 13
                          }}>
                            🌐
                          </div>
                          <div>
                            <div style={{ fontWeight: 800, fontSize: 13.5, color: '#0f172a' }}>
                              {browserName}
                            </div>
                            <div style={{ fontSize: 11, color: '#64748b', marginTop: 1 }}>
                              💻 {osText} • 🖥️ {screenRes}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td>
                        <div style={{ fontWeight: 600, color: '#1e293b' }}>{d.full_name || d.email}</div>
                        <div style={{ fontSize: 11.5, color: '#64748b' }}>{d.email}</div>
                      </td>
                      <td>
                        <span style={{ fontWeight: 700, color: '#0369a1', background: '#f0f9ff', padding: '2px 8px', borderRadius: 6, fontSize: 12, border: '1px solid #bae6fd' }}>
                          {d.shop_name || 'Chưa gắn Shop'}
                        </span>
                      </td>
                      <td>
                        <span style={{ background: '#f1f5f9', padding: '2px 6px', borderRadius: 4, fontSize: 11, fontWeight: 700, color: '#475569' }}>
                          v{d.version || d.client_version || '2.4'}
                        </span>
                      </td>
                      <td>
                        <div style={{ fontSize: 12, color: '#334155' }}>
                          {d.last_seen ? new Date(d.last_seen).toLocaleString('vi-VN') : '—'}
                        </div>
                        <div style={{ fontSize: 11, color: '#94a3b8' }}>IP: {d.ip_address || '127.0.0.1'}</div>
                      </td>
                      <td>
                        <span style={{
                          display: 'inline-flex', alignItems: 'center', gap: 4,
                          padding: '2px 8px', borderRadius: 999, fontSize: 11, fontWeight: 700,
                          background: d.revoked ? '#fee2e2' : onlineStatus === 'online' ? '#dcfce7' : '#f1f5f9',
                          color: d.revoked ? '#991b1b' : onlineStatus === 'online' ? '#166534' : '#475569'
                        }}>
                          {d.revoked ? <><XCircle size={12} /> Đã thu hồi</> : <><CheckCircle size={12} /> {statusText}</>}
                        </span>
                      </td>
                      <td style={{ textAlign: 'right' }}>
                        <button
                          onClick={() => one(d)}
                          style={{
                            padding: '5px 10px',
                            fontSize: 12,
                            background: d.revoked ? '#dcfce7' : '#fee2e2',
                            color: d.revoked ? '#15803d' : '#b91c1c',
                            border: d.revoked ? '1px solid #bbf7d0' : '1px solid #fecaca',
                            borderRadius: 6,
                            fontWeight: 700,
                            cursor: 'pointer'
                          }}
                        >
                          {d.revoked ? 'Khôi phục' : 'Thu hồi'}
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* PAGINATION */}
        {!loading && filtered.length > 0 && (
          <Pagination
            page={page}
            pageSize={pageSize}
            total={filtered.length}
            onPageChange={setPage}
            onPageSizeChange={(s) => {
              setPageSize(s);
              setPage(1);
            }}
            pageSizeOptions={[10, 25, 50, 100]}
            itemLabel="thiết bị"
          />
        )}
      </div>
    </div>
  );
}
