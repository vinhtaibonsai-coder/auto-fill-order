import React, { useCallback, useEffect, useState } from 'react';
import { CreditCard, Calendar, AlertTriangle, ShieldCheck, RefreshCw } from 'lucide-react';
import { AdminService } from '../../../../domain/admin/admin.service.js';
import OverrideSubscriptionModal from '../../modals/OverrideSubscriptionModal';
import ExportButton from '../../components/ExportButton';
import Pagination from '../../components/Pagination';

export default function Subscriptions() {
  const [rows, setRows] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const load = useCallback(async () => {
    setLoading(true);
    const r = await AdminService.getSubscriptions();
    if (r.success) {
      setRows(r.data || []);
    } else {
      alert(r.error);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
    const handleRefresh = () => {
      load();
    };
    window.addEventListener('admin:refresh_data', handleRefresh);
    return () => window.removeEventListener('admin:refresh_data', handleRefresh);
  }, [load]);

  const save = async (data) => {
    const r = await AdminService.overrideSubscription(data.shopId, data.plan, data.months);
    if (r.success) {
      setSelected(null);
      load();
    } else {
      alert(r.error);
    }
  };

  const paginatedRows = rows.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div style={{ display: 'grid', gap: 20 }}>
      {/* Top Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h2 style={{ fontSize: 20, fontWeight: 800, color: '#0f172a', margin: '0 0 4px 0', display: 'flex', alignItems: 'center', gap: 8 }}>
            <CreditCard size={22} color="#2563eb" />
            Gói Cước & Gia Hạn Thuê Bao (Subscriptions)
          </h2>
          <p style={{ margin: 0, fontSize: 13, color: '#64748b' }}>
            Nâng hạ gói cước, gia hạn +1 / +3 / +12 tháng và theo dõi thời hạn hợp đồng các cửa hàng
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={load}
            style={{
              padding: '7px 12px',
              fontSize: 12,
              background: '#ffffff',
              border: '1px solid #cbd5e1',
              borderRadius: 8,
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: 4
            }}
          >
            <RefreshCw size={13} className={loading ? 'dash-spin' : ''} /> Tải lại
          </button>
          <ExportButton rows={rows} filename="danh-sach-goi-cuoc.csv" />
        </div>
      </div>

      {/* Subscriptions Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden', border: '1px solid #e2e8f0', borderRadius: 12 }}>
        <div style={{ overflowX: 'auto' }}>
          <table>
            <thead>
              <tr>
                <th>Cửa hàng / Doanh nghiệp</th>
                <th>Gói dịch vụ</th>
                <th>Trạng thái thuê bao</th>
                <th>Ngày hết hạn</th>
                <th>Cảnh báo gia hạn</th>
                <th style={{ textAlign: 'right' }}>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={6} style={{ textAlign: 'center', padding: '36px 20px', color: '#94a3b8' }}>
                    {loading ? 'Đang tải dữ liệu thuê bao...' : 'Không có thông tin thuê bao nào.'}
                  </td>
                </tr>
              ) : (
                paginatedRows.map(s => {
                  const days = s.current_period_end ? Math.ceil((new Date(s.current_period_end) - Date.now()) / 86400000) : null;
                  const planCode = String(s.plan_code || s.plan_tier || 'FREE').toUpperCase();
                  const isExpiring = days !== null && days <= 7;
                  const isExpired = days !== null && days < 0;

                  return (
                    <tr key={s.id}>
                      <td>
                        <strong style={{ color: '#0f172a', fontSize: 13.5 }}>{s.shops?.name || s.shop_id}</strong>
                        {s.shops?.id && (
                          <small style={{ color: '#94a3b8', display: 'block', fontSize: 11, fontFamily: 'monospace' }}>
                            {s.shops.id}
                          </small>
                        )}
                      </td>
                      <td>
                        <span
                          style={{
                            background: planCode === 'ENTERPRISE' ? '#f3e8ff' : planCode === 'PRO' ? '#eff6ff' : '#f1f5f9',
                            color: planCode === 'ENTERPRISE' ? '#7e22ce' : planCode === 'PRO' ? '#1d4ed8' : '#475569',
                            border: planCode === 'ENTERPRISE' ? '1px solid #e9d5ff' : planCode === 'PRO' ? '1px solid #bfdbfe' : '1px solid #e2e8f0',
                            padding: '3px 8px',
                            borderRadius: 6,
                            fontSize: 11.5,
                            fontWeight: 700
                          }}
                        >
                          {planCode}
                        </span>
                      </td>
                      <td>
                        <span className={`badge ${s.status === 'active' ? 'badge-success' : 'badge-warning'}`}>
                          {s.status === 'active' ? 'Đang kích hoạt' : (s.status || 'Chờ kích hoạt')}
                        </span>
                      </td>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#334155' }}>
                          <Calendar size={14} color="#64748b" />
                          <span>{s.current_period_end ? new Date(s.current_period_end).toLocaleDateString('vi-VN') : '—'}</span>
                        </div>
                      </td>
                      <td>
                        {days === null ? (
                          <span style={{ color: '#94a3b8', fontSize: 12 }}>Không xác định</span>
                        ) : isExpired ? (
                          <span style={{ color: '#dc2626', fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 12 }}>
                            <AlertTriangle size={14} /> Đã hết hạn ({Math.abs(days)} ngày trước)
                          </span>
                        ) : isExpiring ? (
                          <span style={{ color: '#d97706', fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 12 }}>
                            <AlertTriangle size={14} /> Còn {days} ngày
                          </span>
                        ) : (
                          <span style={{ color: '#16a34a', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 12 }}>
                            <ShieldCheck size={14} /> Còn {days} ngày (An toàn)
                          </span>
                        )}
                      </td>
                      <td style={{ textAlign: 'right' }}>
                        <button
                          onClick={() => setSelected(s)}
                          style={{
                            padding: '6px 12px',
                            fontSize: 12,
                            background: '#ffffff',
                            color: '#2563eb',
                            border: '1px solid #bfdbfe',
                            borderRadius: 6,
                            fontWeight: 700,
                            cursor: 'pointer'
                          }}
                        >
                          Đổi gói / Gia hạn
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {!loading && rows.length > 0 && (
          <Pagination
            page={page}
            pageSize={pageSize}
            total={rows.length}
            onPageChange={setPage}
            onPageSizeChange={(s) => {
              setPageSize(s);
              setPage(1);
            }}
            pageSizeOptions={[10, 25, 50, 100]}
            itemLabel="gói cước"
          />
        )}
      </div>

      <OverrideSubscriptionModal
        open={Boolean(selected)}
        subscription={selected}
        onClose={() => setSelected(null)}
        onSubmit={save}
      />
    </div>
  );
}
