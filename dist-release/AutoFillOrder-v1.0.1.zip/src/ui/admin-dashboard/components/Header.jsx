import React from 'react';
import { Search, Shield, ExternalLink, Store, LogOut } from 'lucide-react';

export default function Header({ onLogout }) {
  const operations = arguments[0]?.operations;
  const openWorkspace = () => {
    if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.getURL === 'function') {
      window.open(chrome.runtime.getURL('index.html'), '_blank');
      return;
    }

    window.location.assign('/workspace');
  };

  const openShopControl = () => {
    if (typeof chrome !== 'undefined' && chrome.runtime?.openOptionsPage) {
      chrome.runtime.openOptionsPage();
      return;
    }

    window.location.assign('/options');
  };

  return (
    <header className="header">
      {/* Left: Quick Search */}
      <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
        <Search size={15} color="#94a3b8" style={{ position: 'absolute', left: 12, pointerEvents: 'none' }} />
        <input
          type="text"
          placeholder="Tìm kiếm shop, người dùng, ticket hỗ trợ..."
          style={{
            background: '#ffffff',
            border: '1px solid #cbd5e1',
            padding: '8px 14px 8px 34px',
            borderRadius: '8px',
            color: '#0f172a',
            fontSize: '13px',
            width: '300px',
            maxWidth: '30vw',
            boxShadow: '0 1px 2px rgba(0,0,0,0.04)',
            outline: 'none',
            transition: 'all 0.2s'
          }}
          onFocus={(e) => {
            e.target.style.borderColor = '#3b82f6';
            e.target.style.boxShadow = '0 0 0 3px rgba(59, 130, 246, 0.15)';
          }}
          onBlur={(e) => {
            e.target.style.borderColor = '#cbd5e1';
            e.target.style.boxShadow = '0 1px 2px rgba(0,0,0,0.04)';
          }}
        />
      </div>

      {/* Right Controls */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        {operations}

        {/* User Role Badge */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '4px 10px', background: '#f8fafc', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
          <Shield size={14} color="#2563eb" />
          <span style={{ fontSize: '12.5px', color: '#334155', fontWeight: 700 }}>Master Admin</span>
          <span
            className="badge badge-success"
            style={{
              background: '#dcfce7',
              color: '#15803d',
              padding: '2px 7px',
              borderRadius: '4px',
              fontSize: '10.5px',
              fontWeight: 800,
              letterSpacing: '0.04em'
            }}
          >
            SYSTEM_ADMIN
          </span>
        </div>

        {/* Action Buttons */}
        <button
          onClick={openWorkspace}
          style={{
            background: '#ffffff',
            color: '#0f172a',
            border: '1px solid #cbd5e1',
            padding: '6px 12px',
            borderRadius: '8px',
            cursor: 'pointer',
            fontSize: '12px',
            fontWeight: 700,
            whiteSpace: 'nowrap',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px'
          }}
        >
          <ExternalLink size={13} color="#64748b" />
          Trang Workspace
        </button>

        <button
          onClick={openShopControl}
          style={{
            background: '#ffffff',
            color: '#0f172a',
            border: '1px solid #cbd5e1',
            padding: '6px 12px',
            borderRadius: '8px',
            cursor: 'pointer',
            fontSize: '12px',
            fontWeight: 700,
            whiteSpace: 'nowrap',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px'
          }}
        >
          <Store size={13} color="#64748b" />
          Quản trị Shop
        </button>

        {onLogout && (
          <>
            <div style={{ width: '1px', height: '22px', background: '#e2e8f0' }} />
            <button
              onClick={onLogout}
              style={{
                background: '#fee2e2',
                color: '#b91c1c',
                border: '1px solid #fecaca',
                padding: '6px 12px',
                borderRadius: '8px',
                cursor: 'pointer',
                fontSize: '12px',
                fontWeight: 700,
                minWidth: '96px',
                whiteSpace: 'nowrap',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px',
                transition: 'all 0.15s ease'
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.background = '#fca5a5';
                e.currentTarget.style.color = '#7f1d1d';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.background = '#fee2e2';
                e.currentTarget.style.color = '#b91c1c';
              }}
            >
              <LogOut size={13} />
              Đăng xuất
            </button>
          </>
        )}
      </div>
    </header>
  );
}
