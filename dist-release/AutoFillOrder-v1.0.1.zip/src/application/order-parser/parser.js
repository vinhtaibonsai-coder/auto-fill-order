// =========================================================================
// MÔ ĐUN BÓC TÁCH ĐƠN HÀNG (PARSER)
// =========================================================================

const OrderProcessor = {
  parseCOD(text) {
    if (!text) return 0;
    let s = text.toLowerCase().replace(/\s+/g, '');

    s = s.replace(/^(?:cod|tiền|tien|thu\s*hộ|thuho|thu\s*ho|tiềncod|tienco|tiềnthu|tienthu)[:\-\s]*/i, '');

    // 1. Dạng Triệu (vd: "1.8tr", "1tr8", "1tr800", "2.5tr", "2tr500k")
    let normalized = s.replace(/,/g, '.');
    if (normalized.includes('tr') || normalized.includes('triệu') || normalized.includes('trieu')) {
      const cleanText = normalized.replace(/(?:triệu|trieu)/g, 'tr');
      const trIndex = cleanText.indexOf('tr');
      const afterTr = cleanText.substring(trIndex + 2).replace(/k/g, '');
      const cleanNormalized = cleanText.substring(0, trIndex + 2) + afterTr;

      let parts = cleanNormalized.split('tr');
      const numBeforeTr = (parts[0].match(/[\d.]+$/) || [''])[0];
      let val = parseFloat(numBeforeTr) || 0;
      if (parts[1]) {
        const suffix = parts[1].replace(/\D/g, '');
        if (suffix.length === 1) {
          val += parseFloat('0.' + suffix);
        } else if (suffix.length === 2) {
          val += parseFloat('0.' + suffix);
        } else if (suffix.length === 3) {
          val += parseFloat('0.' + suffix);
        } else if (suffix.length >= 4) {
          val += parseFloat(suffix) / 1000000;
        }
      }
      return Math.round(val * 1000000);
    }

    // 2. Dạng nghìn có chữ 'k' (vd: "300k", "1.500k", "250k", "50k")
    if (s.includes('k') || s.includes('nghìn') || s.includes('ngan') || s.includes('ngàn')) {
      let raw = s.replace(/(?:k|nghìn|ngan|ngàn)/g, '').replace(/,/g, '.');
      const numMatch = raw.match(/[\d.]+/);
      if (!numMatch) return 0;
      raw = numMatch[0];
      const grouped = /^\d{1,3}(?:\.\d{3})+$/.test(raw);
      if (grouped) {
        const digits = raw.replace(/\./g, '');
        return Number(digits) * 1000;
      }
      const decimal = parseFloat(raw);
      if (!isNaN(decimal)) {
        return Math.round(decimal * 1000);
      }
      const digitsOnly = raw.replace(/\D/g, '');
      return digitsOnly ? parseInt(digitsOnly, 10) * 1000 : 0;
    }

    // 3. Dạng số có dấu chấm phân cách hàng nghìn (vd: "1.800.000", "300.000", "50.000")
    if (/^\d{1,3}(?:\.\d{3})+$/.test(normalized)) {
      const digits = normalized.replace(/\./g, '');
      return parseInt(digits, 10) || 0;
    }

    // 4. Dạng số nguyên thuần (vd: "300", "250", "850", "50000", "1800000")
    const digits = normalized.replace(/\D/g, '');
    if (!digits) return 0;
    const num = parseInt(digits, 10);
    if (num > 0 && num < 1000) {
      // Số dưới 1000 trong bóc đơn luôn là nghìn đồng (vd: Cod 300 -> 300.000đ, 250 -> 250.000đ)
      return num * 1000;
    }
    if (num >= 1000 && num < 10000 && !normalized.includes('.')) {
      // Số 4 chữ số trong bóc đơn (vd: 1200, 1500) là nghìn đồng (1.200k -> 1.200.000đ)
      return num * 1000;
    }
    return num;
  },

    extractCODFromLine(line) {
      const raw = String(line || '').trim();
      if (!raw) return { found: false, amount: 0 };

      if (/^(?:(?:cod|thu\s*hộ|thu\s*ho|tiền\s*cod|tien\s*cod|tiền\s*thu\s*hộ|tien\s*thu\s*ho|tiền\s*thu|tien\s*thu|tiền|tien)\s*[:\-\s]*)?0\s*(?:k|đ|d|vnd|đồng|dong|[^\d\s])?$/iu.test(raw)) {
        return { found: true, amount: 0, explicitZero: true };
      }

      const match = raw.match(/(?:cod|thu\s*hộ|thu\s*ho|tiền\s*cod|tien\s*cod|tiền\s*thu\s*hộ|tien\s*thu\s*ho|tiền\s*thu|tien\s*thu|tiền|tien)\s*[:\-\s]*([0-9][0-9.,\s]*(?:triệu|trieu|tr)[0-9.,\s]*(?:k|nghìn|ngàn|ngan|đ|d|vnd|đồng|dong)?|[0-9][0-9.,\s]*(?:k|nghìn|ngàn|ngan|đ|d|vnd|đồng|dong)|[0-9][0-9.,\s]*[a-zA-Z]+|[0-9][0-9.,]*)/iu);
      if (match && match[1]) {
        const amount = OrderProcessor.parseCOD(match[1]) || 0;
        return { found: true, amount, explicitZero: amount === 0 };
      }

      const standaloneMatch = raw.match(/^([0-9][0-9.,\s]*(?:triệu|trieu|tr)[0-9.,\s]*(?:k|nghìn|ngàn|ngan|đ|d|vnd|đồng|dong)?|[0-9][0-9.,\s]*(?:k|nghìn|ngàn|ngan|đ|d|vnd|đồng|dong)|[0-9][0-9.,\s]*(?:đ|d|vnd|đồng|dong))\s*$/iu);
      if (standaloneMatch && standaloneMatch[1]) {
        const amount = OrderProcessor.parseCOD(standaloneMatch[1]) || 0;
        return { found: true, amount, explicitZero: amount === 0 };
      }

      return { found: false, amount: 0 };
    },

    stripCODNoteFromAddress(address) {
      return String(address || '')
        .replace(/(?:[,;\-\s]*)?(?:cod|thu\s*hộ|thu\s*ho|tiền\s*cod|tien\s*cod|tiền\s*thu\s*hộ|tien\s*thu\s*ho|tiền\s*thu|tien\s*thu|tiền|tien)\s*[:\-\s]*(?:[0-9][0-9.,\s]*(?:triệu|trieu|tr)[0-9.,\s]*(?:k|nghìn|ngàn|ngan|đ|d|vnd|đồng|dong)?|[0-9][0-9.,\s]*(?:k|nghìn|ngàn|ngan|đ|d|vnd|đồng|dong)|[0-9][0-9.,\s]*[a-zA-Z]+|[0-9][0-9.,]*)\s*$/iu, '')
        .trim();
    },

    hasStandaloneZeroAmount(text, lines = []) {
      if ((lines || []).some(line => {
        const candidate = OrderProcessor.extractCODFromLine(line);
        return candidate.found && candidate.explicitZero;
      })) return true;

      return /(?:^|[\s,;])0\s*(?:đ|d|vnd|đồng|dong|[^\d\s])(?=\s+(?:vnpost|j\s*&?\s*t|jt|[A-Z]{2}\d{9,13}VN|C[A-Z0-9]{8,13}VN|\d{1,4}\/))/iu.test(String(text || ''));
    },

    extractPhoneNumbers(text) {
      if (!text) return [];
      const normalized = text.replace(/[\u00A0]/g, ' ');
      const unique = [];

      const pushPhone = (phone) => {
        let clean = phone.replace(/\D/g, '');
        if (clean.startsWith('84') && clean.length > 10) {
          clean = '0' + clean.slice(2);
        }
        if (clean && !unique.includes(clean) && (clean.length === 10 || clean.length === 11)) {
          unique.push(clean);
        }
      };

      const phoneRegex = /(?:\+84|84|0)(?:\s*[\.\-]?\s*\d){9,10}\b/g;
      let match;
      while ((match = phoneRegex.exec(normalized)) !== null) {
        const matchedStr = match[0];
        const matchIndex = match.index;
        
        if (matchIndex > 0 && /\d/.test(normalized[matchIndex - 1])) {
          continue;
        }
        pushPhone(matchedStr);
      }

      const longMatches = normalized.match(/\b0\d{19,43}\b/g) || [];
      longMatches.forEach(longPhone => {
        const clean = longPhone.replace(/\D/g, '');
        const segments = OrderProcessor.segmentPhoneDigits(clean);
        segments.forEach(pushPhone);
      });

      return unique;
    },

    segmentPhoneDigits(digits) {
      function helper(str) {
        if (str.length === 0) return [];
        if (str[0] !== '0') return null;
        for (const len of [10, 11]) {
          if (str.length >= len) {
            const rest = str.slice(len);
            if (rest.length === 0 || rest[0] === '0') {
              const result = helper(rest);
              if (result !== null) return [str.slice(0, len)].concat(result);
            }
          }
        }
        return null;
      }
      return helper(digits) || [];
    },

    preprocessText(text) {
      if (!text) return "";
      let s = text.trim();

      // Nếu văn bản chỉ có 1 dòng (hoặc không có dấu ngắt dòng) nhưng dài và có nhiều thông tin
      const lines = s.split(/\r?\n/).filter(l => l.trim().length > 0);
      if (lines.length <= 2) {
        s = s.replace(/;\s*/g, '\n');
        s = s.replace(/(?:^|\s+)(?:sđt|sdt|đt|dt|tel|phone|lh)[:\s]*((?:\+84|84|0)(?:\s*[\.\-]?\s*\d){9,10}\b)/gi, '\nSđt:$1');
        s = s.replace(/(?:^|\s+)((?:\+84|84|0)(?:\s*[\.\-]?\s*\d){9,10}\b)/g, '\n$1');
        s = s.replace(/(?:^|\s+)(địa chỉ|đ\/c|dc|address)[:\s]/gi, '\n$1: ');
        s = s.replace(/(?:^|\s+)(khách hàng|người nhận|tên khách|tên kh|khách|tên)[:\s]/gi, '\n$1: ');
        s = s.replace(/(?:^|\s+)(cod|tiền|thu hộ|tiền cod)[:\s]/gi, '\n$1: ');
        s = s.replace(/(?:^|\s+)(mã đơn|mã đh|mã dh|mã vận đơn|mã order|mã)[:\s]/gi, '\n$1: ');
        s = s.replace(/(?:^|\s+)(chỉ\s*thu\s*cước|thu\s*cước|chỉ\s*thu\s*ship|thu\s*ship)[:\s]*/gi, '\n$1');
      }
      return s;
    },

    parseCollectFee(text) {
      if (!text) return false;
      const low = text.toLowerCase();

      // Rule 1: Kiểm tra quy tắc PHỦ ĐỊNH trước (Free ship / Đã thanh toán ship)
      const isNegative = /(?:bên\s*bán\s*chịu\s*ship|freeship|free\s*ship|bao\s*ship|đã\s*ck\s*ship|đã\s*chuyển\s*khoản\s*ship|shop\s*chịu\s*ship|không\s*thu\s*ship|miễn\s*phí\s*ship|miễn\s*phí\s*vận\s*chuyển|k\s*thu\s*ship|ko\s*thu\s*ship|0k\s*ship|k\s*ship|ko\s*ship)/i.test(low);
      if (isNegative) return false;

      // Rule 2: Kiểm tra quy tắc KHẲNG ĐỊNH (Thu cước người nhận)
      const isPositive = /(?:\.\s*cước\s*:\s*có|thu\s*ship\s*:\s*có|thu\s*cước\s*:\s*có|có\s*thu\s*ship|có\s*thu\s*cước|\+\s*cước|\+\s*cuoc|\+\s*phí\s*ship|\+\s*ship|người\s*nhận\s*trả\s*ship|khách\s*trả\s*ship|cước\s*người\s*nhận|chỉ\s*thu\s*cước|thu\s*cước|chỉ\s*thu\s*ship|thu\s*ship)/i.test(low);
      return isPositive;
    },

    extractProductItem(lines) {
      let productItem = "";
      const addressKeywords = /(?:ấp|thôn|xóm|xã|huyện|tỉnh|quận|phường|đường|phố|ngõ|ngách|số\s*nhà|tdp|kp|tổ|đội|buôn|bản|chung\s*cư|tòa|khu|vinhomes|city)/i;

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];

        // 1. Kiểm tra trường hợp Sản phẩm nằm ở đầu dòng cùng Địa chỉ (vd: "5kg đỗ quyên 13e/28 trương Văn lực,cam lộ...")
        const combinedMatch = line.match(/^(\d+\s*(?:kg|gram|g|hộp|chai|cái|chiếc|bao|túi|lọ|gói|bịch|set|combo|sp|đôi|bộ)\s+[a-zA-ZÀ-ỹ0-9\s]+?)\s+(?=(?:\d+[a-zA-Z]?\/\d+|số\s*\d+|\b(?:đường|phố|ngõ|ngách|số|thôn|xóm|xã|phường|huyện|quận|tỉnh|tp|ấp|kđt|tòa|chung\s*cư)\b|[a-zA-ZÀ-ỹ\s]+,))/i);
        if (combinedMatch && combinedMatch[1]) {
          productItem = combinedMatch[1].trim();
          lines[i] = line.substring(combinedMatch[1].length).trim();
          break;
        }

        // 2. Kiểm tra dòng đứng độc lập chỉ chứa thông tin sản phẩm (vd: "5kg đỗ quyên")
        if (!addressKeywords.test(line) && !/^(sđt|sdt|đt|dt|tel|phone|lh|cod|tiền|thu\s*hộ|chỉ\s*thu\s*cước|thu\s*cước)/i.test(line)) {
          const match = line.match(/^(\d+\s*(?:kg|gram|g|hộp|chai|cái|chiếc|bao|túi|lọ|gói|bịch|set|combo|sp|đôi|bộ)\s+[a-zA-ZÀ-ỹ0-9\s]+)/i);
          if (match && match[1]) {
            productItem = match[1].trim();
            break;
          }
        }
      }

      return productItem;
    },

    extractOrderCode(text, lines, phones = []) {
      if (!text) return "";
      const orderCodes = [];

      // Từ khóa nhận diện Mã sản phẩm / SKU
      const skuKeywords = /(?:size|màu|mau|xl|xxl|áo|quần|váy|đầm|hộp|chai|cái|chiếc|bao|túi|lọ|sp|sản\s*phẩm|kg|gram|gói|bịch|set|combo)/i;

      // Từ khóa nhận diện Dòng Địa chỉ (Chung cư, Số nhà, Phòng, Tầng, Đường...) để không bóc nhầm số phòng thành mã đơn
      const addressKeywords = /(?:chung\s*cư|căn\s*hộ|toà\s*nhà|tòa\s*nhà|tòa|toà|block|tầng|lầu|phòng|khu\s*đô\s*thị|kđt|đường|phố|ngõ|ngách|hẻm|kiệt|số\s*nhà|thôn|xóm|ấp|bản|tổ|kp|khu\s*phố|xã|phường|quận|huyện|thị\s*xã|thành\s*phố|tp\.|tp\s|tỉnh|hcm|hà\s*nội|hn|đà\s*nẵng)/i;

      const isPhoneOrCod = (str) => {
        const clean = str.replace(/[\s\.\-]/g, '');
        const digits = str.replace(/\D/g, '');
        if (/^(?:0|\+?84)[3|5|7|8|9]\d{8}$/.test(digits) || /^\d{10,11}$/.test(digits)) return true;
        if (phones && phones.some(p => p && (clean.includes(p.replace(/\D/g, '')) || p.replace(/\D/g, '').includes(clean)))) return true;
        if (/^(?:cod|thu\s*hộ|ship|cước|tiền)?\s*\d+k?$/i.test(str)) return true;
        return false;
      };

      // Ưu tiên 1: Dòng độc lập chỉ chứa duy nhất mã đơn/mã hàng (ví dụ: dòng "E80.290" hoặc "DH-12345" hoặc "Mã: E80.290")
      for (const l of lines) {
        const trimmed = l.trim();
        if (!trimmed) continue;
        if (isPhoneOrCod(trimmed)) continue;

        // Bắt mã đơn theo tiền tố rõ ràng ("mã:", "mã đơn:", "mã đh:", "order:", "dh:")
        const explicitMatch = trimmed.match(/^(?:mã\s*đơn(?:\s*hàng)?(?:\s*là)?|mã\s*đh|mã\s*dh|mã\s*vận\s*đơn|mã\s*order|order\s*id|mã|dh)[:\s\-•]*([a-zA-Z0-9.\-_]{2,25})$/i);
        if (explicitMatch && explicitMatch[1]) {
          const candidate = explicitMatch[1].trim();
          if (!/^(hàng|gửi|tới|số|vận|đơn|cước|ship|thu|cod)$/i.test(candidate) && !skuKeywords.test(candidate) && !isPhoneOrCod(candidate)) {
            return candidate;
          }
        }

        // Dòng đứng độc lập 100% khớp pattern mã (ví dụ: "E80.290", "VN123456789", "JT987654321", "DH100462959")
        if (!addressKeywords.test(trimmed) && /^[A-Za-z0-9][A-Za-z0-9.\-_]{2,20}$/.test(trimmed)) {
          if (!/\d+k$/i.test(trimmed) && !/^(ship|cod|vnd|vnđ|kg|g|size|free|freeship)$/i.test(trimmed) && !skuKeywords.test(trimmed)) {
            // Bắt buộc phải có chữ số (tránh nhầm tên riêng thuần chữ cái như 'Bam', 'Nam', 'Hoa' thành mã đơn)
            if (/\d/.test(trimmed)) {
              // Loại trừ số căn hộ chung cư 3 cấp như B1.09.01 và loại trừ số thuần túy
              if (!/^[A-Za-z]\d+\.\d+\.\d+/i.test(trimmed) && !/^\d+$/.test(trimmed)) {
                return trimmed;
              }
            }
          }
        }
      }

      // Ưu tiên 2: Quét các dòng thông thường nhưng loại trừ dòng địa chỉ và dòng SĐT/COD
      lines.forEach(l => {
        const low = l.toLowerCase();

        if (addressKeywords.test(low) || isPhoneOrCod(low)) {
          return;
        }

        if (skuKeywords.test(low) && !/(?:mã\s*đơn|mã\s*đh|mã\s*dh|mã\s*vận\s*đơn|mã\s*order|order\s*id)/i.test(low)) {
          return;
        }

        // Bắt mã đơn theo tiền tố rõ ràng
        const explicitMatch = l.match(/(?:mã\s*đơn(?:\s*hàng)?(?:\s*là)?|mã\s*đh|mã\s*dh|mã\s*vận\s*đơn|mã\s*order|order\s*id|mã|dh)[:\s\-•]*([a-zA-Z0-9.\-_]{2,25})/i);
        if (explicitMatch && explicitMatch[1]) {
          const candidate = explicitMatch[1].trim();
          if (!/^(hàng|gửi|tới|số|vận|đơn|cước|ship|thu|cod)$/i.test(candidate) && !skuKeywords.test(candidate) && !isPhoneOrCod(candidate)) {
            if (!orderCodes.includes(candidate)) orderCodes.push(candidate);
            return;
          }
        }

        // Dòng khớp mã đơn tiêu chuẩn đứng độc lập
        const standaloneMatch = l.match(/\b(VN[0-9]{8,12}|JT[0-9]{8,12}|DH[-_]?[0-9]{3,10}|ORD[-_]?[0-9]{3,10}|[A-Za-z][0-9]{1,4}[\.-][0-9]{1,6}|[A-Za-z]{1,5}[-_]?[0-9]{2,10})\b/i);
        if (standaloneMatch && standaloneMatch[1]) {
          const cand = standaloneMatch[1].trim();
          if (!/\d+k$/i.test(cand) && !/^(ship|cod|vnd|vnđ|kg|g|size)$/i.test(cand) && !skuKeywords.test(cand) && !isPhoneOrCod(cand)) {
            if (!orderCodes.includes(cand)) orderCodes.push(cand);
          }
        }
      });

      return orderCodes.join(', ');
    },

    extractName(lines, phones, rawText) {
      // Từ điển Họ phổ biến ở Việt Nam
      const vnSurnames = /^(nguyễn|trần|lê|phạm|huỳnh|hoàng|vũ|võ|đặng|bùi|đỗ|hồ|ngô|dương|lý|đào|đinh|đoàn|mai|trịnh|thái|phan|cao|vương|lại|trương|lâm|phùng|hà|tạ|quách|lương|châu|chu|triệu|lưu|tống|tăng|diệp)\b/i;
      
      // Từ khóa giao tiếp / câu hội thoại không phải Tên (chú ý boundary để không lọc nhầm các họ chữ Lại, Tạ...)
      const chatterKeywords = /(?:freeship|free\s*ship|bao\s*ship|ship|cho\s*mình|gửi\s*cho|cho\s*xin|check\s*inbox|tư\s*vấn|tách\s*ko|hàng\s*dễ\s*vỡ|xem\s*hàng|đã\s*chuyển\s*khoản|chuyển\s*khoản|giao\s*giờ|(?:\b|\s|^)(?:nhé|nha|ạ|dạ|shop|ơi)(?:\b|\s|$|[!.,?])|\bfb\b|facebook|zalo|tiktok|instagram)/i;

      let candidateName = "";

      // Bước 0: Bắt tên đứng ở đầu câu/dòng trước SĐT (vd: "Phương: 0989.935.936", "Vũ Trang - 0962004039")
      for (const l of lines) {
        if (/^(?:fb|facebook|nick\s*fb|page|zalo|tiktok|ig|instagram)[:\s\-]/i.test(l.trim()) || /^fb\s+/i.test(l.trim())) continue;
        const prefixNameMatch = l.match(/^([a-zA-ZÀ-ỹ\s]{2,35})[:;\-–]\s*(?:sđt|sdt|đt|dt|tel|phone|lh)?\s*(?:\+84|84|0)(?:\s*[\.\-]?\s*\d){8,10}\b/i);
        if (prefixNameMatch && prefixNameMatch[1]) {
          let clean = prefixNameMatch[1].trim();
          // Loại bỏ nếu phần bắt match chỉ là nhãn SĐT, địa chỉ, COD (vd: "Sdt: 0982...", "Đc : 84...", "Cod : 0...")
          if (/^(?:sđt|sdt|đt|dt|tel|phone|lh|liên\s*hệ|điện\s*thoại|hotline|zalo|địa\s*chỉ|đ\/c|đc|dc|address|cod|tiền|thu\s*hộ|thu\s*cước|cước|ship|giá)(?:\s*(?:nhận|người\s*nhận|kh|khách|của\s*khách|liên\s*hệ))?$/i.test(clean)) continue;
          clean = clean.replace(/^(khách\s*hàng|người\s*nhận|khách|tên)[:\s]*/i, '').trim();
          clean = clean.replace(/^[-\|\:\s\.\,\/]+|[-\|\:\s\.\,\/]+$/g, '').trim();
          const isAddress = /(?:ấp|thôn|xóm|xã|huyện|tỉnh|quận|phường|đường|phố|ngõ|ngách|số\s*nhà|tdp|kp|cụm|tổ|khu|vinhomes|city|chung\s*cư|tòa|toà)/i.test(clean);
          if (clean.length >= 2 && clean.length <= 40 && !isAddress && !chatterKeywords.test(clean)) {
            return clean;
          }
        }
      }

      // Bước 1: Tìm dòng chứa nhãn tên người nhận rõ ràng ("khách:", "tên:", "người nhận:")
      for (const l of lines) {
        if (/^(?:fb|facebook|nick\s*fb|page|zalo|tiktok|ig|instagram)[:\s\-]/i.test(l.trim()) || /^fb\s+/i.test(l.trim())) continue;
        const nameLabelMatch = l.match(/(?:người\s*nhận\s*hàng|tên\s*khách\s*hàng|người\s*nhận|tên\s*khách|tên\s*kh|khách\s*hàng|họ\s*tên|tên|họ\s*và\s*tên|kh)[:\s\-•]+([^,;\n]+)/i);
        if (nameLabelMatch && nameLabelMatch[1]) {
          let clean = nameLabelMatch[1].trim();
          clean = clean.replace(/(?:\+84|84|0)(?:[\s\.\-]?\d){9,10}\b/g, '');
          phones.forEach(p => { clean = clean.replace(p, ''); });
          clean = clean.replace(/^[-\|\:\s\.\,\/]+|[-\|\:\s\.\,\/]+$/g, '').trim();
          if (clean.length >= 2 && clean.length <= 40 && !chatterKeywords.test(clean)) {
            return clean;
          }
        }
      }

      // Bước 1.5: Tìm dòng chứa tên kèm Nick/Acc Facebook (vd: "lại văn vũ ( acc kim sa tùng )", "vu quang anh ( acc diem huong )")
      for (const l of lines) {
        const trimmed = l.trim();
        if (/^(?:fb|facebook|zalo|tiktok)[:\s\-]/i.test(trimmed)) continue;
        const accMatch = trimmed.match(/^([a-zA-ZÀ-ỹ0-9\s._-]+?)\s*[\(\[]\s*(?:acc|fb|nick|page|facebook|nhựt|lũa|bonsai|shop)[^)\]]*[)\]]?/i);
        if (accMatch && accMatch[1]) {
          let clean = accMatch[1].trim();
          clean = clean.replace(/^[-\|\:\s\.\,\/]+|[-\|\:\s\.\,\/]+$/g, '').trim();
          const isAddress = /(?:ấp|thôn|xóm|xã|huyện|tỉnh|quận|phường|đường|phố|ngõ|ngách|số\s*nhà|tdp|kp|khu|vinhomes|city|chung\s*cư|tòa|toà)/i.test(clean);
          if (clean.length >= 2 && clean.length <= 45 && !isAddress && !chatterKeywords.test(clean)) {
            return clean;
          }
        }
      }

      // Bước 2: Tìm dòng bắt đầu bằng Họ tiếng Việt (kể cả khi chung dòng với SĐT/Địa chỉ)
      for (const l of lines) {
        if (/^(?:fb|facebook|nick\s*fb|page|zalo|tiktok|ig|instagram)[:\s\-]/i.test(l.trim()) || /^fb\s+/i.test(l.trim())) continue;
        let clean = l;
        clean = clean.replace(/(?:\+84|84|0)(?:[\s\.\-]?\d){9,10}\b/g, '');
        phones.forEach(p => { clean = clean.replace(p, ''); });
        clean = clean.replace(/(?:sđt|sdt|đt|dt|tel|phone|lh|liên\s*hệ)[:\-\s]*/i, '').trim();
        clean = clean.replace(/^[-\|\:\s\.\,\/]+|[-\|\:\s\.\,\/]+$/g, '').trim();

        // Tách phần tên đứng trước ngoặc đơn, dấu phẩy, hoặc tiền tố địa chỉ nếu nằm chung 1 dòng
        let cleanFront = clean.split(/[,\(\-–:]|\b(?:sđt|sdt|đt|dt|tel|phone|lh|địa\s*chỉ|đ\/c|dc|đc|số\s*nhà|thôn|xóm|xã|huyện|tỉnh|quận|phường|đường|phố|ngõ|ngách|ấp)\b/i)[0].trim();

        if (vnSurnames.test(cleanFront)) {
          const words = cleanFront.split(/\s+/);
          if (words.length >= 2 && words.length <= 5 && !chatterKeywords.test(cleanFront)) {
            const isAddress = /thôn|xóm|xã|huyện|tỉnh|quận|phường|đường|phố|ngõ|ngách|số\s*nhà|tdp|cụm|khu|tòa|chung\s*cư/i.test(cleanFront);
            if (!isAddress) {
              return cleanFront;
            }
          }
        }
      }

      // Bước 3: Fallback lấy phần tên nằm chung dòng với SĐT (vd: "0901234567 Nguyễn Văn A", "Hoà Trương 0944.639.639")
      for (const l of lines) {
        if (/^(?:fb|facebook|nick\s*fb|page|zalo|tiktok|ig|instagram)[:\s\-]/i.test(l.trim()) || /^fb\s+/i.test(l.trim())) continue;
        if (phones.some(p => l.replace(/\D/g, '').includes(p.replace(/\D/g, '')))) {
          let clean = l;
          clean = clean.replace(/(?:\+84|84|0)(?:[\s\.\-]?\d){9,10}\b/g, '');
          phones.forEach(p => { clean = clean.replace(p, ''); });
          clean = clean.replace(/(?:sđt|sdt|đt|dt|tel|phone|lh|liên\s*hệ)[:\-\s]*/i, '').trim();
          clean = clean.replace(/^(ship|gửi|chuyển|cho|xin|khách|tên)[:\s]*/i, '').trim();
          clean = clean.replace(/^[-\|\:\s\.\,\/]+|[-\|\:\s\.\,\/]+$/g, '').trim();

          const isAddress = /thôn|xóm|xã|huyện|tỉnh|quận|phường|đường|phố|ngõ|ngách|số\s*nhà|tdp|cụm|tổ|khu|vinhomes|ocean\s*park|chung\s*cư|tòa|toà|kđt/i.test(clean);
          const isCodOrCode = /cod|tiền|thu\s*hộ|mã/i.test(clean);

          if (clean && clean.length >= 2 && clean.length <= 35 && !isAddress && !isCodOrCode && !chatterKeywords.test(clean)) {
            return clean;
          }
        }
      }

      // Bước 4: Fallback cuối — lấy dòng đầu tiên không phải SĐT, địa chỉ, COD, mã, tên cửa hàng
      if (!candidateName) {
        const knownLabels = /^(sđt|sdt|đt|dt|tel|phone|lh|địa\s*chỉ|đ\/c|dc|đc|cod|tiền\s*thu\s*hộ|tiền|thu\s*hộ|mã\s*đơn|mã\s*vận|mã|order|ship|gửi|cho|kh|tên|fb|facebook|zalo|tiktok|chỉ\s*thu\s*cước|thu\s*cước|cước)/i;
        for (const l of lines) {
          let clean = l.replace(/(?:\+84|84|0)(?:[\s\.\-]?\d){9,10}\b/g, '');
          phones.forEach(p => { clean = clean.replace(p, ''); });
          clean = clean.replace(/^[-\|\:\s\.\,\/]+|[-\|\:\s\.\,\/]+$/g, '').trim();
          if (clean && clean.length >= 2 && clean.length <= 50 && !knownLabels.test(clean)) {
            const isAddress = (
              /(?:ấp|thôn|xóm|xã|huyện|tỉnh|quận|phường|đường|phố|ngõ|ngách|hẻm|kiệt|số\s*nhà|tdp|kp|khu\s*phố|tổ|đội|buôn|bản|cụm|chung\s*cư|tòa\s*nhà|tòa|toà|khu\s*đô\s*thị|kđt|vinhomes|city|smart\s*city|dự\s*án|building|block|lô|căn\s*hộ|apartment|villa|eco|ecohome|ocean\s*park)/i.test(clean) ||
              /^(?:hà\s*nội|hn|hcm|tp\s*hcm|sài\s*gòn|đà\s*nẵng|hải\s*phòng|cần\s*thơ|bình\s*dương|đồng\s*nai|bắc\s*ninh)\b/i.test(clean) ||
              /(?:hà\s*nội|hn|hcm|tp\s*hcm|sài\s*gòn|đà\s*nẵng|hải\s*phòng|cần\s*thơ|bình\s*dương|đồng\s*nai|bắc\s*ninh)$/i.test(clean) ||
              /^\d+[a-zA-Z]?[\/\.-]/.test(clean) ||
              clean.split(/[,;\-\.]/).filter(part => part.trim().length > 0).length >= 3
            );
            const isCod = /^(cod|thu\s*hộ|tiền|cước|chỉ\s*thu\s*cước|thu\s*cước|thu\s*ship)/i.test(clean);
            const isNumericOnly = /^\d+$/.test(clean);
            const isDistrictOnly = /^(gò\s*vấp|bình\s*thạnh|tân\s*bình|thủ\s*đức|quận\s*\d|huyện\s*|tp\.|tphcm|hà\s*nội|đà\s*nẵng)$/i.test(clean);
            const isOrderCode = /^[A-Za-z][0-9]{1,4}[\.-][0-9]{1,6}$/.test(clean);
            if (!isAddress && !isCod && !isNumericOnly && !isDistrictOnly && !isOrderCode) {
              const cleanNoParen = clean.replace(/\s*\([^)]*\)\s*$/, '').trim();
              return cleanNoParen || clean;
            }
          }
        }
      }

      return candidateName;
    },

    parse(rawInputText) {
      if (!rawInputText) return { name: "", phone: "", address: "không tìm thấy", orderCode: "", productItem: "", codAmount: 0, collectFee: false, extraPhones: [], extraNote: "", codExplicitZero: false, codFound: false, rawText: "" };

      // Preprocess text (Xử lý tin nhắn 1 dòng không ngắt dòng)
      const text = OrderProcessor.preprocessText(rawInputText);
      const lines = text.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);

      // 1. Trích xuất SĐT
      const phones = OrderProcessor.extractPhoneNumbers(text);
      let phone = phones[0] || "";
      const extraPhones = phones.slice(1);

      // 2. Trích xuất Tiền cước (collectFee) chuẩn xác theo ngữ cảnh
      const collectFee = OrderProcessor.parseCollectFee(text);

      // 3. Trích xuất Mặt hàng / Sản phẩm (vd: "5kg đỗ quyên")
      const productItem = OrderProcessor.extractProductItem(lines);

      // 4. Trích xuất Mã đơn hàng (Phân biệt với SKU Sản phẩm, loại trừ SĐT và địa chỉ)
      const orderCode = OrderProcessor.extractOrderCode(text, lines, phones);

      // 5. Trích xuất Tên người nhận (Dựa vào Họ VN & từ khóa lọc rác)
      let name = OrderProcessor.extractName(lines, phones, text);

      let address = "";
      let codAmount = 0;
      let codExplicitZero = OrderProcessor.hasStandaloneZeroAmount(text, lines);
      let extraNote = "";

      // Trích xuất Ghi chú MXH & Ghi chú đơn hàng (v.d.: "Fb Trung Jones", "Zalo: Nam", "Ghi chú: Giao giờ hành chính")
      lines.forEach(l => {
        const low = l.toLowerCase().trim();
        if (/^(?:fb|facebook|nick\s*fb|page|zalo|tiktok|ig|instagram|ghi\s*chú|note|lưu\s*ý)[:\s\-]/i.test(low) || /^fb\s+/i.test(low)) {
          const noteText = l.replace(/^(?:ghi\s*chú|note|lưu\s*ý)[:\s\-]*/i, '').trim() || l.trim();
          if (!extraNote) extraNote = noteText;
          else if (!extraNote.includes(noteText)) extraNote += ', ' + noteText;
        }
      });

      // 6. Duyệt dòng để trích xuất COD và Địa chỉ
      lines.forEach(l => {
        const low = l.toLowerCase();

        // Bỏ qua dòng nếu dòng đó chỉ chứa Tên người nhận và/hoặc Số điện thoại
        let tempLine = l.trim().toLowerCase();
        if (name) {
          tempLine = tempLine.replace(name.toLowerCase().trim(), '');
        }
        phones.forEach(p => {
          tempLine = tempLine.replace(p.toLowerCase().trim(), '');
        });
        tempLine = tempLine.replace(/(?:\+84|84|0)(?:[\s\.\-]?\d){9,10}\b/g, '');
        tempLine = tempLine.replace(/^(?:sđt|sdt|đt|dt|tel|phone|lh|liên\s*hệ|người\s*nhận|tên\s*khách|khách\s*hàng|tên|họ\s*tên|kh)[:\s\-•,]+/i, '').trim();
        tempLine = tempLine.replace(/^[-\|\:\s\.\,\/]+|[-\|\:\s\.\,\/]+$/g, '').trim();
        if (tempLine.length === 0) {
          return;
        }

        // Bỏ qua dòng nếu dòng đó là mã đơn hàng hoặc SKU
        const cleanTrimmed = l.trim();
        if (orderCode && (cleanTrimmed.toLowerCase() === orderCode.toLowerCase() || tempLine === orderCode.toLowerCase())) {
          return;
        }
        if (/^[A-Za-z][0-9]{1,4}[\.-][0-9]{1,6}$/i.test(cleanTrimmed)) {
          return;
        }

        const lineCodCandidate = OrderProcessor.extractCODFromLine(l);
        if (lineCodCandidate.found) {
          if (lineCodCandidate.explicitZero) {
            codExplicitZero = true;
            codAmount = 0;
          } else if (!codExplicitZero && lineCodCandidate.amount > 0 && codAmount === 0) {
            codAmount = lineCodCandidate.amount;
          }
        }

        // Trích xuất COD
        if (low.includes('cod') || low.includes('thu hộ') || (low.includes('tiền') && /\d/.test(low))) {
          const codCandidate = OrderProcessor.extractCODFromLine(l);
          if (codCandidate.found) {
            if (codCandidate.explicitZero) {
              codExplicitZero = true;
              codAmount = 0;
            } else if (!codExplicitZero && codCandidate.amount > 0 && codAmount === 0) {
              codAmount = codCandidate.amount;
            }
          }
        }

        // Trích xuất Địa chỉ
        let hasProvinceAlias = false;
        if (typeof ADM_DB !== 'undefined' && ADM_DB.provinces) {
          hasProvinceAlias = ADM_DB.provinces.some(p => {
            return p.aliases.some(a => {
              const regex = new RegExp('\\b' + a.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i');
              return regex.test(low);
            }) || low.includes(p.name.toLowerCase());
          });
        }

        const isAddressByProvince = hasProvinceAlias && (
          /\d/.test(l) || 
          l.includes(',') || 
          /(?<!\p{L})(?:ấp|thôn|xóm|xã|huyện|tỉnh|quận|phường|đường|phố|ngõ|ngách|số\s*nhà|tdp|khu\s*phố|kp|tổ|đội|buôn|bản|cụm|chung\s*cư|tòa\s*nhà|tòa|toà|khu\s*đô\s*thị|kđt|vinhomes|city|smart\s*city|dự\s*án|building|block|lô|căn\s*hộ|apartment|villa)(?!\p{L})/iu.test(l) ||
          l.split(/\s+/).length >= 2
        );

        const isAddressLine = (
          /(?:địa\s*chỉ|đ\/c|đc|dc|address)[\s:;\-–•]/i.test(l) ||
          /(?<!\p{L})(?:ấp|thôn|xóm|xã|huyện|tỉnh|quận|phường|đường|phố|ngõ|ngách|số\s*nhà|tdp|khu\s*phố|kp|tổ|đội|buôn|bản|cụm|chung\s*cư|tòa\s*nhà|tòa|toà|khu\s*đô\s*thị|kđt|vinhomes|city|smart\s*city|dự\s*án|building|block|lô|căn\s*hộ|apartment|villa)(?!\p{L})/iu.test(l) ||
          (/^[pq](?:\.|\s+)(?:[a-zA-ZÀ-ỹ\d]|\d{1,2}\b)/i.test(cleanTrimmed) && !/^[A-Za-z]\d+[\.-]\d+$/i.test(cleanTrimmed)) ||
          l.split(',').filter(part => part.trim().length > 0).length >= 3 ||
          isAddressByProvince
        );

        if (isAddressLine) {
          let ca = l;
          const addressLabelMatch = l.match(/^(?:[\s\-\–•]*)(?:địa\s*chỉ\s*nhận\s*hàng|địa\s*chỉ|đ\/c|đc|dc|address)[:\s\-•]+\s*(.*)/i);
          if (addressLabelMatch && addressLabelMatch[1]) {
            ca = addressLabelMatch[1].trim();
          } else {
            ca = ca.replace(/^(?:địa chỉ\s*nhận\s*hàng|địa chỉ|đ\/c|đc|dc|sđt|sdt|đt|dt|tel|phone|lh|liên\s*hệ)\s*:?\s*/gi, '').trim();
          }
          ca = ca.replace(/^(?:gửi\s+)?(?:ship\s+)?(?:cho\s+mình|cho\s+em|cho\s+tôi|cho\s+khách)?\s*(?:đến|về|tới)?\s*(?:địa\s*chỉ)?\s*[:\s\-•]*/gi, '').trim();
          ca = ca.replace(/(?:\+84|84|0)(?:[\s\.\-]?\d){9,10}\b/g, '');
          phones.forEach(p => { ca = ca.replace(p, ''); });
          ca = ca.replace(/[\s\.\,\-\–•]*(?:sđt|sdt|đt|dt|tel|phone|lh|liên\s*hệ|zalo|hotline)[:\s\-•]*$/gi, '').trim();

          // Chuẩn hóa prefix
          ca = ca.replace(/^Q(?:\.|\s+)(\d+|[a-zA-ZÀ-ỹ][a-zA-ZÀ-ỹ\s]*)/i, (m, g) => 'Quận ' + g.trim());
          ca = ca.replace(/^P(?:\.|\s+)(\d+|[a-zA-ZÀ-ỹ\d][a-zA-ZÀ-ỹ\s\d]*)/i, (m, g) => 'Phường ' + g.trim());
          ca = ca.replace(/^H(?:\.|\s+)([a-zA-ZÀ-ỹ][a-zA-ZÀ-ỹ\s]*)/i, (m, g) => 'Huyện ' + g.trim());
          ca = ca.replace(/^TX(?:\.|\s+)([a-zA-ZÀ-ỹ][a-zA-ZÀ-ỹ\s]*)/i, (m, g) => 'Thị xã ' + g.trim());
          ca = ca.replace(/^TP(?:\.|\s+)([a-zA-ZÀ-ỹ][a-zA-ZÀ-ỹ\s]*)/i, (m, g) => 'TP. ' + g.trim());
          ca = ca.replace(/^X(?:\.|\s+)([a-zA-ZÀ-ỹ][a-zA-ZÀ-ỹ\s]*)/i, (m, g) => 'Xã ' + g.trim());
          ca = ca.replace(/^TT(?:\.|\s+)([a-zA-ZÀ-ỹ][a-zA-ZÀ-ỹ\s]*)/i, (m, g) => 'Thị trấn ' + g.trim());

          ca = OrderProcessor.stripCODNoteFromAddress(ca);
          ca = ca.replace(/\s+/g, ' ').trim();
          // Xóa các đuôi hội thoại thừa (e nhé, em nha, v.v.)
          ca = ca.replace(/\s+(?:e\s+nhé|em\s+nhé|e\s+nha|em\s+nha|nhé\s+e|nhé\s+em|nha\s+e|nha\s+em|nhé|nha(?!\s+(?:trang|xá|mần|bè|nam|bắc|tây|đông|trung))|nghe|ơi|nhé\s+bạn|nhé\s+shop|nhé\s+ad|nhé\s+anh|nhé\s+chị|ạ|dạ)(?!\p{L}).*$/iu, '').trim();
          // Xóa các ghi chú trong ngoặc ở đuôi địa chỉ (ví dụ: ( địa chỉ sau xác nhập ))
          ca = ca.replace(/\s*\(\s*(?:địa\s*chỉ\s*)?(?:sau\s*)?(?:sáp\s*nhập|xác\s*nhập|cũ|mới|giao\s*giờ\s*hành\s*chính)[^)]*\)\s*$/i, '').trim();
          ca = ca.replace(/^[-\s\.\,\/]+|[-\s\.\,\/]+$/g, '').trim();

          const isChatterOnly = /^(?:e\s+nhé|em\s+nhé|e\s+nha|em\s+nha|nhé|nha|sđt|đt|dt|tel|phone|lh)$/i.test(ca);

          if (ca && !isChatterOnly) {
            if (!address) { address = ca; }
            else if (!address.toLowerCase().includes(ca.toLowerCase())) { address += ", " + ca; }
          }
        } else if (
          // Fallback địa chỉ: bắt đầu bằng số, độ dài >= 12, không phải số lượng sản phẩm, không phải dòng sĐT
          /^\d/.test(l) && /[a-zà-ỹ]/i.test(l) && l.length >= 12 &&
          !/\d+\s*(kg|gói|hộp|thùng|bao|bịch|cái|chiếc|chai|lọ|túi|tấn|yến|lít)\b/i.test(l) &&
          !phones.some(p => l.includes(p)) // Không phải dòng chứa sĐT đã biết
        ) {
          let ca = OrderProcessor.stripCODNoteFromAddress(l.trim());
          ca = ca.replace(/^(?:gửi\s+)?(?:ship\s+)?(?:cho\s+mình|cho\s+em|cho\s+tôi|cho\s+khách)?\s*(?:đến|về|tới)?\s*(?:địa\s*chỉ)?\s*[:\s\-•]*/gi, '').trim();
          ca = ca.replace(/(?:\+84|84|0)(?:[\s\.\-]?\d){9,10}\b/g, '');
          phones.forEach(p => { ca = ca.replace(p, ''); });
          ca = ca.replace(/[\s\.\,\-\–•]*(?:sđt|sdt|đt|dt|tel|phone|lh|liên\s*hệ|zalo|hotline)[:\s\-•]*$/gi, '').trim();
          ca = ca.replace(/\s+(?:e\s+nhé|em\s+nhé|e\s+nha|em\s+nha|nhé\s+e|nhé\s+em|nha\s+e|nha\s+em|nhé|nha(?!\s+(?:trang|xá|mần|bè|nam|bắc|tây|đông|trung))|nghe|ơi|nhé\s+bạn|nhé\s+shop|nhé\s+ad|nhé\s+anh|nhé\s+chị|ạ|dạ)(?!\p{L}).*$/iu, '').trim();
          ca = ca.replace(/\s*\(\s*(?:địa\s*chỉ\s*)?(?:sau\s*)?(?:sáp\s*nhập|xác\s*nhập|cũ|mới|giao\s*giờ\s*hành\s*chính)[^)]*\)\s*$/i, '').trim();
          ca = ca.replace(/^[-\s\.\,\/]+|[-\s\.\,\/]+$/g, '').trim();

          const isChatterOnly = /^(?:e\s+nhé|em\s+nhé|e\s+nha|em\s+nha|nhé|nha|sđt|đt|dt|tel|phone|lh)$/i.test(ca);

          if (ca && !isChatterOnly) {
            if (!address) { address = ca; }
            else if (!address.toLowerCase().includes(ca.toLowerCase())) { address += ", " + ca; }
          }
        } else {
          // Bắt ghi chú trong ngoặc (vd: "(Giao giờ hành chính)")
          const parenMatch = l.match(/\(([^)]+)\)/);
          if (parenMatch && !extraNote) {
            extraNote = parenMatch[1].trim();
          }
        }
      });

      if (!extraNote) {
        for (const l of lines) {
          const parenMatch = l.match(/\(([^)]+)\)/);
          if (parenMatch && parenMatch[1]) {
            extraNote = parenMatch[1].trim();
            break;
          }
        }
      }

      if (!address) address = "không tìm thấy";
      if (phone) phone = phone.replace(/\s+/g, '');
      const codFound = codAmount > 0 || codExplicitZero;
      return { name, phone, address, orderCode, productItem, codAmount, collectFee, extraPhones, extraNote, codExplicitZero, codFound, rawText: rawInputText };
    }
  };

  function runLocalComputerParser(text) {
    return OrderProcessor.parse(text);
  }

  function isValidPhoneNumber(phone) {
    if (!phone) return false;
    const clean = phone.toString().replace(/\D/g, '');
    return /^(0\d{9,10})$/.test(clean);
  }

  function normalizePhoneNumber(phone) {
    if (!phone) return "";
    const digits = phone.toString().replace(/\D/g, '');
    if (/^(0\d{9,10})$/.test(digits)) return digits;
    const matches = digits.match(/0\d{9,10}/g) || [];
    if (matches.length > 0) return matches[0];
    if (digits.length >= 10 && digits.startsWith('0')) {
      return digits.length === 11 ? digits.slice(0, 11) : digits.slice(0, 10);
    }
    return "";
  }

  globalThis.OrderProcessor = OrderProcessor;
  globalThis.runLocalComputerParser = runLocalComputerParser;
  globalThis.isValidPhoneNumber = isValidPhoneNumber;
  globalThis.normalizePhoneNumber = normalizePhoneNumber;
