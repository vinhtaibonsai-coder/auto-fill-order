(() => {
  const AddressLearning = {
    /**
     * Học máy địa chỉ: Lưu ánh xạ SĐT -> Địa chỉ chuẩn và Địa chỉ thô -> Địa chỉ chuẩn
     */
    async learn(rawAddress, correctAddressObj, phone = "") {
      if (!correctAddressObj) return;
      // Chỉ học khi độ tin cậy >= 85
      if ((correctAddressObj.confidence || 0) < 85) return;
      
      try {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id && chrome.storage && chrome.storage.local) {
          chrome.storage.local.get(['addressLearningDB'], (res) => {
            const lastErr = chrome.runtime.lastError;
            if (lastErr) return;
            const db = res.addressLearningDB || { byPhone: {}, byRaw: {} };
            
            // Giới hạn kích thước DB (LRU đơn giản, giữ 1000 records)
            const MAX_ENTRIES = 1000;
            
            if (phone) {
              const keys = Object.keys(db.byPhone);
              if (keys.length > MAX_ENTRIES) delete db.byPhone[keys[0]];
              db.byPhone[phone] = correctAddressObj;
            }
            if (rawAddress) {
              const cleanRaw = rawAddress.trim().toLowerCase();
              const keys = Object.keys(db.byRaw);
              if (keys.length > MAX_ENTRIES) delete db.byRaw[keys[0]];
              db.byRaw[cleanRaw] = correctAddressObj;
            }
            
            chrome.storage.local.set({ addressLearningDB: db }).catch(() => {});
          });
          } else {
            const data = localStorage.getItem('addressLearningDB');
            const db = data ? JSON.parse(data) : { byPhone: {}, byRaw: {} };
            const MAX_ENTRIES = 1000;
            
            if (phone) {
              const keys = Object.keys(db.byPhone);
              if (keys.length > MAX_ENTRIES) delete db.byPhone[keys[0]];
              db.byPhone[phone] = correctAddressObj;
            }
            if (rawAddress) {
              const cleanRaw = rawAddress.trim().toLowerCase();
              const keys = Object.keys(db.byRaw);
              if (keys.length > MAX_ENTRIES) delete db.byRaw[keys[0]];
              db.byRaw[cleanRaw] = correctAddressObj;
            }
            localStorage.setItem('addressLearningDB', JSON.stringify(db));
          }
      } catch (e) {
        console.warn("Lỗi Learning Engine:", e);
      }
    },

    /**
     * Tra cứu địa chỉ trong AKB bằng SĐT hoặc Địa chỉ thô
     */
    async lookup(rawAddress, phone = "") {
      return new Promise((resolve) => {
        try {
          const cleanRaw = (rawAddress || "").trim().toLowerCase();
          const hasRawAddress = Boolean(cleanRaw && cleanRaw !== "không tìm thấy");

          const handleLookup = (db) => {
            if (!db) {
              resolve(null);
              return;
            }
            // 1. Ưu tiên khớp chính xác theo địa chỉ thô đã học
            if (hasRawAddress && db.byRaw && db.byRaw[cleanRaw]) {
              resolve({ match: db.byRaw[cleanRaw], confidence: 100, source: "akb_raw" });
              return;
            }

            // Nếu người dùng đã cung cấp địa chỉ cụ thể nhưng chưa có trong byRaw,
            // TUYỆT ĐỐI KHÔNG dùng địa chỉ cũ từ byPhone để ghi đè (tránh tình trạng khách đổi địa chỉ
            // hoặc người dùng trực tiếp sửa địa chỉ nhưng lại bị load lại địa chỉ cũ theo SĐT)
            if (hasRawAddress) {
              resolve(null);
              return;
            }

            // 2. Chỉ khi đơn KHÔNG CÓ địa chỉ (hoặc 'không tìm thấy'), mới dùng địa chỉ đã học theo SĐT làm phương án dự phòng
            if (phone && db.byPhone && db.byPhone[phone]) {
              resolve({ match: db.byPhone[phone], confidence: 90, source: "akb_phone" });
              return;
            }
            resolve(null);
          };

          if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(['addressLearningDB'], (res) => {
              const lastErr = chrome.runtime.lastError;
              if (lastErr) {
                resolve(null);
                return;
              }
              const db = res.addressLearningDB || { byPhone: {}, byRaw: {} };
              handleLookup(db);
            });
          } else {
            const data = localStorage.getItem('addressLearningDB');
            const db = data ? JSON.parse(data) : { byPhone: {}, byRaw: {} };
            handleLookup(db);
          }
        } catch (e) {
          console.warn("Lỗi tra cứu AKB:", e);
          resolve(null);
        }
      });
    }
  };

  globalThis.AddressLearning = AddressLearning;
})();
