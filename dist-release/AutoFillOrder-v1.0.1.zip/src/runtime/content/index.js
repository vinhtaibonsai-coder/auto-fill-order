(() => {
  // =========================================================================
  // ENTRY POINT / COORDINATOR - content/index.js
  // =========================================================================

  // Chỉ chạy ở frame gốc (top frame) — tránh inject panel vào iframe con của J&T micro-frontend
  if (window !== window.top) return;

  if (globalThis.parsedDataStore === undefined) {
    globalThis.parsedDataStore = null;
  }
  let timeoutId = null;
  let observerActive = false;
  let lastSuccessfulFillPlatform = '';
  let carrierRefillTimer = null;
  let _carrierSubmitInterceptorAttached = false;

  function onDOMReady(fn) {
    if (document.readyState === 'interactive' || document.readyState === 'complete') {
      fn();
    } else {
      document.addEventListener('DOMContentLoaded', fn);
    }
  }

  const observer = new MutationObserver(() => {
    // Chỉ kích hoạt lại nếu shadow host bị tháo gỡ khỏi DOM
    if (!document.getElementById('vnpost-autofill-shadow-host')) {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        checkUrlAndInject();
      }, 300);
    }
  });

  function startObserver() {
    if (observerActive) return;
    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true });
      observerActive = true;
    }
  }

  function stopObserver() {
    if (!observerActive) return;
    observer.disconnect();
    observerActive = false;
    if (timeoutId) {
      clearTimeout(timeoutId);
      timeoutId = null;
    }
  }

  function getVnpostEl(id) {
    const host = document.getElementById('vnpost-autofill-shadow-host');
    if (host && host.shadowRoot) {
      const el = host.shadowRoot.getElementById(id);
      if (el) return el;
    }
    return document.getElementById(id);
  }

  const carrierRuntime = globalThis.AutoFillCarrierRuntime || {};
  const PLATFORMS = carrierRuntime.PLATFORMS || {};
  const getCurrentPlatform = carrierRuntime.getCurrentPlatform || (() => null);
  const detectCarrierAccount = carrierRuntime.detectCarrierAccount || (() => '');

  // ─── CHỐNG TRÙNG LẶP SỰ KIỆN TẠO ĐƠN TOÀN CỤC (GLOBAL SUBMISSION GUARD) ───
  const _recentlyProcessedSubmissions = new Map();

  function isSubmissionRecentlyHandled(trackingCode, orderCode, phone, name) {
    const now = Date.now();
    for (const [k, time] of _recentlyProcessedSubmissions.entries()) {
      if (now - time > 30000) _recentlyProcessedSubmissions.delete(k);
    }

    const cleanTrack = String(trackingCode || '').trim().toLowerCase().replace(/\s+/g, '');
    const cleanOrder = String(orderCode || '').trim().toLowerCase().replace(/\s+/g, '');
    const cleanPhone = String(phone || '').replace(/\D/g, '');
    const cleanName = String(name || '').trim().toLowerCase();

    const keys = [];
    if (cleanTrack && cleanTrack !== '—' && cleanTrack !== '-') keys.push('tr_' + cleanTrack);
    if (cleanOrder && cleanOrder !== '—' && cleanOrder !== '-') keys.push('oc_' + cleanOrder);

    for (const k of keys) {
      if (_recentlyProcessedSubmissions.has(k) && (now - _recentlyProcessedSubmissions.get(k) < 15000)) {
        return true;
      }
    }

    for (const k of keys) {
      _recentlyProcessedSubmissions.set(k, now);
    }
    return false;
  }

  async function checkUrlAndInject() {
    const platform = getCurrentPlatform();
    if (platform) {
      startObserver();
      try {
        initCarrierSubmitInterceptor(platform);
      } catch (err) {
        console.warn('[checkUrlAndInject] Error initializing submit interceptor:', err);
      }
      setTimeout(async function() {
        let isAuth = false;
        try {
          if (typeof AuthService !== 'undefined' && typeof AuthService.isAuthenticated === 'function') {
            isAuth = await AuthService.isAuthenticated();
          }
        } catch (err) {
          console.warn('[checkUrlAndInject] Error checking auth state:', err);
          isAuth = false;
        }

        if (!isAuth) {
          try {
            if (typeof createLoginRequiredPanel === 'function') {
              createLoginRequiredPanel(platform, openSettingsPage);
            }
          } catch (panelErr) {
            console.warn('[checkUrlAndInject] Error creating login panel:', panelErr);
          }
          return;
        }

        // Check if device limit is exceeded
        let session = null;
        try {
          if (typeof AuthSession !== 'undefined' && typeof AuthSession.getSession === 'function') {
            session = await AuthSession.getSession();
          }
        } catch (_) {}

        if (session && session.device_limit_exceeded === true) {
          try {
            if (typeof createDeviceLimitExceededPanel === 'function') {
              createDeviceLimitExceededPanel(platform, session.max_devices || 5, openSettingsPage);
            }
          } catch (limitErr) {
            console.warn('[checkUrlAndInject] Error creating device limit panel:', limitErr);
          }
          return;
        }

        globalThis.afTriggerFillForm = triggerFillForm;
        globalThis.afHandleSaveOrder = handleSaveOrder;

        if (typeof createInputPanel === 'function') {
          try {
            createInputPanel(
              platform,
              handleHybridParsing,
              triggerFillForm,
              handleClearOrder,
              handleAiAddressClick,
              openSettingsPage,
              updateParsedField,
              handleSaveOrder
            );
            if (globalThis.parsedDataStore && typeof displayParsedData === 'function') {
              displayParsedData(globalThis.parsedDataStore);
            }
          } catch (inputPanelErr) {
            console.warn('[checkUrlAndInject] Error creating input panel:', inputPanelErr);
          }
        } else {
          console.log('[checkUrlAndInject] React Panel is taking over. No vanilla UI injected.');
        }
      }, 50);
    } else {
      stopObserver();
      const host = document.getElementById('vnpost-autofill-shadow-host');
      if (host) host.remove();
    }
  }

  globalThis.checkUrlAndInject = checkUrlAndInject;

  // ─── ĐĂNG KÝ SỰ KIỆN URL NAVIGATION & TUẦN HOÀN THEO DÕI URL (SPA POLL) ───
  window.addEventListener('popstate', checkUrlAndInject);
  window.addEventListener('hashchange', checkUrlAndInject);

  // Lắng nghe sự kiện đăng nhập / đổi phiên từ Options hoặc Tab khác trong thời gian thực
  try {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && (changes.vnpost_session || changes.currentUser || changes.activeShop || changes.activeShopId)) {
          setTimeout(checkUrlAndInject, 60);
        }
      });
    }
  } catch (_) {}

  if (typeof AuthEvents !== 'undefined' && typeof AuthEvents.on === 'function') {
    AuthEvents.on('AUTH_STATE_CHANGED', () => {
      setTimeout(checkUrlAndInject, 60);
    });
  }

  window.addEventListener('storage', (e) => {
    if (e.key === 'vnpost_session' || e.key === 'currentUser' || e.key === 'activeShopId') {
      setTimeout(checkUrlAndInject, 60);
    }
  });

  // Tự động xóa dữ liệu trên panel khi bấm "Tạo đơn hàng mới" hoặc "Tạo đơn mới" trên giao diện trang web
  document.addEventListener('click', (e) => {
    try {
      const target = e.target;
      if (target) {
        const text = (target.textContent || target.innerText || '').trim().toLowerCase();
        if (text === 'tạo đơn hàng mới' || text === 'tạo đơn mới') {
          handleClearOrder(true);
        }
      }
    } catch (_) {}
  });

  // ─── PHÍM TẮT TOÀN CỤC SIÊU TỐC (PHASE 1: SHORTCUTS & AUTO-DETECT) ───
  document.addEventListener('keydown', async (e) => {
    try {
      // 1. Tổ hợp Ctrl + Shift + V hoặc Cmd + Shift + V: Dán và Bóc tách tức thì
      const isPasteShortcut = (e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'V' || e.key === 'v');
      if (isPasteShortcut) {
        e.preventDefault();
        let clipText = '';
        try {
          if (navigator.clipboard && navigator.clipboard.readText) {
            clipText = await navigator.clipboard.readText();
          }
        } catch (clipErr) {
          console.warn('[AutoFill Shortcut] Không thể đọc clipboard:', clipErr);
        }

        if (clipText && clipText.trim()) {
          // Bảo đảm panel đã hiển thị
          const host = document.getElementById('vnpost-autofill-shadow-host');
          if (!host) {
            checkUrlAndInject();
          }

          setTimeout(() => {
            const panel = getVnpostEl('vnpost-autofill-panel');
            if (panel) {
              // Mở panel nếu đang thu gọn
              if (panel.classList.contains('panel-docked') && panel.classList.contains('collapsed')) {
                const tab = getVnpostEl('vnpost-dock-toggle-tab');
                if (tab) tab.click();
              } else if (panel.classList.contains('minimized')) {
                const btnMin = getVnpostEl('vnpost-btn-minimize');
                if (btnMin) btnMin.click();
              }
            }

            const rawTextarea = getVnpostEl('rawOrderText');
            const parseBtn = getVnpostEl('btnParseOrder');

            if (rawTextarea) {
              rawTextarea.value = clipText.trim();
              rawTextarea.dispatchEvent(new Event('input', { bubbles: true }));
              rawTextarea.dispatchEvent(new Event('change', { bubbles: true }));
            }

            if (parseBtn) {
              parseBtn.click();
              if (typeof showVnpostToast === 'function') {
                showVnpostToast('⚡ Phím tắt: Đã dán và bóc tách đơn hàng siêu tốc!', 'success', 3000);
              }
            }
          }, 100);
        }
        return;
      }

      // 2. Phím Escape: Thu nhỏ / Ẩn nhanh Panel
      if (e.key === 'Escape') {
        const panel = getVnpostEl('vnpost-autofill-panel');
        if (panel) {
          if (panel.classList.contains('panel-docked') && !panel.classList.contains('collapsed')) {
            const btnMin = getVnpostEl('vnpost-btn-minimize');
            if (btnMin) btnMin.click();
          } else if (panel.classList.contains('panel-floating') && !panel.classList.contains('minimized')) {
            const btnMin = getVnpostEl('vnpost-btn-minimize');
            if (btnMin) btnMin.click();
          }
        }
      }
    } catch (shortcutErr) {
      console.warn('[AutoFill Shortcut] Error:', shortcutErr);
    }
  });

  let lastUrlForPoll = typeof window !== 'undefined' ? window.location.href : '';
  setInterval(() => {
    if (typeof window !== 'undefined' && window.location.href !== lastUrlForPoll) {
      lastUrlForPoll = window.location.href;
      checkUrlAndInject();
    }
  }, 500);

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    checkUrlAndInject();
  } else {
    window.addEventListener('DOMContentLoaded', checkUrlAndInject);
  }

  // Khởi chạy observer dự phòng
  if (document.body) {
    startObserver();
  } else {
    window.addEventListener('DOMContentLoaded', () => {
      if (document.body) startObserver();
    });
  }

  // ─── CHUẨN HÓA VÀ GỢI Ý ĐỊA CHỈ ───
  function formatCleanAddress(addrResult, rawAddress = '') {
    if (!addrResult) return rawAddress || '';
    const normalized = addrResult.fullAddress || [addrResult.street, addrResult.ward, addrResult.district, addrResult.province].filter(Boolean).join(', ');
    if (typeof AddressNormalizer !== 'undefined' && typeof AddressNormalizer.preserveComplete === 'function') {
      return AddressNormalizer.preserveComplete(rawAddress, normalized);
    }
    return normalized || rawAddress;
  }

  function formatTwoLevelAddress(addrResult, rawAddress = '') {
    if (!addrResult) return rawAddress || '';
    const parts2 = [];
    if (addrResult.street) {
      parts2.push(addrResult.street);
    } else if (rawAddress) {
      // Lấy phần đường/chi tiết từ địa chỉ thô
      const rawParts = rawAddress.split(',').map(p => p.trim());
      const streetPart = rawParts.find(p => /\d/.test(p) && !/^(phường|xã|quận|huyện|tỉnh|thành phố)/i.test(p));
      if (streetPart) parts2.push(streetPart);
    }
    if (addrResult.ward) {
      let w = addrResult.ward;
      if (!/^(phường|xã|thị trấn|đặc khu|p\.|x\.)\s/i.test(w)) {
        if (addrResult.province && /thành phố|tp\b/i.test(addrResult.province) && addrResult.district && /quận/i.test(addrResult.district)) {
          w = 'Phường ' + w;
        } else if (addrResult.district && /huyện/i.test(addrResult.district)) {
          w = 'Xã ' + w;
        }
      }
      parts2.push(w);
    } else if (addrResult.district && !/^(quận\s*\d+|quận|huyện|thị xã)/i.test(addrResult.district)) {
      parts2.push(addrResult.district);
    }
    if (addrResult.province) {
      parts2.push(addrResult.province);
    }
    return parts2.length > 0 ? parts2.join(', ') : (addrResult.fullAddress || rawAddress);
  }

  function detectAddressLevels(rawText = '', addrResult = null) {
    if (!addrResult) return 3;
    if (!addrResult.ward && !addrResult.province) return 3;

    const stripAccents = (str) => {
      return String(str || '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .replace(/đ/g, 'd');
    };

    const normRaw = stripAccents(rawText);

    // 1. Kiểm tra xem quận/huyện được nhận diện có xuất hiện trong địa chỉ thô không
    if (addrResult.district) {
      const dClean = addrResult.district.replace(/^(quận|huyện|thị xã|thành phố|tp\.?|tx\.?|q\.?|h\.?)\s+/i, '').trim();
      const normDistrictClean = stripAccents(dClean);
      const normDistrictFull = stripAccents(addrResult.district);

      // Quận dạng số: ví dụ Quận 3, Q.1
      if (/^\d+$/.test(normDistrictClean)) {
        const numPattern = new RegExp(`\\b(?:quan|q\\.?|huyen|h\\.?)\\s*0*${normDistrictClean}\\b`, 'i');
        if (numPattern.test(normRaw)) {
          return 3;
        }
      } else if (normDistrictClean.length >= 2) {
        if (normRaw.includes(normDistrictClean) || normRaw.includes(normDistrictFull)) {
          return 3;
        }
      }
    }

    // 2. Kiểm tra xem trong địa chỉ thô có chứa bất kỳ từ khóa định danh quận/huyện nào không
    const districtKeywordsPattern = /\b(?:quận|huyện|thị\s*xã|tx\.|q\.\s*\d+|q\s*\d+)\b/i;
    if (districtKeywordsPattern.test(rawText)) {
      return 3;
    }

    // 3. Nếu có xã/phường + tỉnh/thành phố rõ ràng nhưng KHÔNG có quận/huyện trong văn bản gốc
    // => Khách hàng đưa địa chỉ theo định dạng 2 cấp mới!
    if (addrResult.ward && addrResult.province) {
      return 2;
    }

    return 3;
  }

  async function refreshAddressSuggestion(newAddress, phone = '') {
    if (!newAddress || newAddress === 'không tìm thấy') return newAddress;
    const referenceStatus = getVnpostEl('address-reference-status');
    const addressStatusBadge = getVnpostEl('address-status-badge');
    const suggestCleanEl = getVnpostEl('rev-suggest-clean');
    const suggest2LevelEl = getVnpostEl('rev-suggest-2level');
    const rawAddressEl = getVnpostEl('rev-raw-address');
    if (referenceStatus) {
      referenceStatus.textContent = 'Đang bóc tách...';
      referenceStatus.className = 'address-reference-status is-loading';
    }
    if (addressStatusBadge) addressStatusBadge.textContent = '⏳ Đang kiểm tra';
    if (suggestCleanEl) suggestCleanEl.textContent = 'Đang tạo gợi ý...';
    if (suggest2LevelEl) suggest2LevelEl.textContent = 'Đang quy đổi...';
    if (rawAddressEl) rawAddressEl.textContent = newAddress;
    try {
      let addrResult = null;
      try {
        if (typeof AddressEngine !== 'undefined' && typeof AddressEngine.process === 'function') {
          addrResult = await Promise.race([
            AddressEngine.process(newAddress, phone || globalThis.parsedDataStore?.phone || ''),
            new Promise((_, reject) => setTimeout(() => reject(new Error('AddressEngine timeout')), 3000))
          ]);
        }
      } catch (e) {
        console.warn('[AddressEdit] AddressEngine error:', e);
      }

      if (globalThis.parsedDataStore && addrResult) {
        globalThis.parsedDataStore.addressParts = {
          ward: addrResult.ward || '',
          district: addrResult.district || '',
          province: addrResult.province || ''
        };
      }

      const mergerNotice = getVnpostEl('ai-merger-notice');

      if (addrResult) {
        const cleanText = formatCleanAddress(addrResult, newAddress);
        const twoLevelText = formatTwoLevelAddress(addrResult, newAddress);
        const detectedLevel = detectAddressLevels(newAddress, addrResult);

        if (globalThis.parsedDataStore) {
          globalThis.parsedDataStore.addressLevel = detectedLevel;
        }

        if (suggestCleanEl) suggestCleanEl.textContent = cleanText;
        if (suggest2LevelEl) suggest2LevelEl.textContent = twoLevelText;
        if (referenceStatus) {
          referenceStatus.textContent = detectedLevel === 2 ? 'Chuẩn 2 cấp' : 'Đã bóc tách lại';
          referenceStatus.className = 'address-reference-status is-ready';
        }

        const btnClean = getVnpostEl('btn-switch-clean');
        const btn2Level = getVnpostEl('btn-switch-2level');
        if (btnClean && btn2Level) {
          btnClean.classList.toggle('active', detectedLevel !== 2);
          btn2Level.classList.toggle('active', detectedLevel === 2);
        }

        if (addressStatusBadge) {
          addressStatusBadge.textContent = detectedLevel === 2 ? '🎯 Địa chỉ 2 Cấp' : '✓ Đã tối ưu';
          addressStatusBadge.title = detectedLevel === 2
            ? 'Địa chỉ được nhận diện theo chuẩn 2 cấp (không chèn quận).'
            : 'Địa chỉ chuẩn hóa 3 cấp đầy đủ.';
        }

        const wardEl = getVnpostEl('rev-addr-ward');
        const distEl = getVnpostEl('rev-addr-district');
        const provEl = getVnpostEl('rev-addr-province');
        if (wardEl) wardEl.textContent = addrResult.ward || '---';
        if (distEl) distEl.textContent = addrResult.district || '---';
        if (provEl) provEl.textContent = addrResult.province || '---';

        if (mergerNotice) {
          if (addrResult.warning) {
            mergerNotice.textContent = '📢 ' + addrResult.warning;
            mergerNotice.style.display = 'block';
          } else {
            mergerNotice.style.display = 'none';
          }
        }

        const preferredText = (detectedLevel === 2 && twoLevelText && twoLevelText !== 'không tìm thấy')
          ? twoLevelText
          : cleanText;
        return preferredText;
      } else {
        if (suggestCleanEl) suggestCleanEl.textContent = newAddress;
        if (suggest2LevelEl) suggest2LevelEl.textContent = 'Chưa đủ dữ liệu để quy đổi 2 cấp';
        if (referenceStatus) {
          referenceStatus.textContent = 'Cần kiểm tra';
          referenceStatus.className = 'address-reference-status is-warning';
        }
        if (addressStatusBadge) addressStatusBadge.textContent = '⚠ Cần kiểm tra';
      }
    } catch (err) {
      console.warn('Lỗi khi bóc tách lại gợi ý địa chỉ:', err);
      if (suggestCleanEl) suggestCleanEl.textContent = newAddress;
      if (suggest2LevelEl) suggest2LevelEl.textContent = 'Không thể quy đổi tự động';
      if (referenceStatus) {
        referenceStatus.textContent = 'Cần kiểm tra';
        referenceStatus.className = 'address-reference-status is-warning';
      }
      if (addressStatusBadge) addressStatusBadge.textContent = '⚠ Cần kiểm tra';
    }
    return newAddress;
  }

  globalThis.refreshAddressSuggestion = refreshAddressSuggestion;

  const customerHubLookupCache = new Map();
  async function lookupCustomerAfterParse(parsed) {
    const phone = String(parsed?.phone || '').replace(/\D/g, '').replace(/^84(?=\d{9}$)/, '0');
    if (phone.length < 9) return null;
    let shopId = '';
    try { shopId = String(await AuthSession?.getActiveShop?.() || ''); } catch (_) {}
    const key = `${shopId}:${phone}`; const cached = customerHubLookupCache.get(key);
    if (cached && Date.now() - cached.at < 5 * 60 * 1000) return cached.value;
    try {
      const lookup = typeof globalThis.lookupPanelCustomerHistory === 'function'
        ? globalThis.lookupPanelCustomerHistory(phone) : Promise.resolve(null);
      const value = await Promise.race([lookup, new Promise(resolve => setTimeout(() => resolve(null), 1500))]);
      customerHubLookupCache.set(key, { at: Date.now(), value });
      return value;
    } catch (_) { return null; }
  }
  globalThis.lookupCustomerAfterParse = lookupCustomerAfterParse;

  // ─── XỬ LÝ LỌC TRÙNG & PHÂN TÍCH HYBRID ───
  async function handleHybridParsing() {
    let isAuth = false;
    try {
      if (typeof AuthService !== 'undefined' && typeof AuthService.isAuthenticated === 'function') {
        isAuth = await AuthService.isAuthenticated();
      }
    } catch (_) { isAuth = false; }

    if (!isAuth) {
      showVnpostToast("⚠️ Bạn chưa đăng nhập hoặc phiên đã hết hạn. Vui lòng đăng nhập lại để tách đơn!", "error");
      checkUrlAndInject();
      return;
    }

    if (typeof loadCustomL2Mappings === 'function') await loadCustomL2Mappings();
    const rawTextEl = getVnpostEl('rawOrderText');
    const text = rawTextEl ? rawTextEl.value.trim() : '';
    if (!text) {
      showVnpostToast("⚠️ Vui lòng dán thông tin đơn hàng thô!", "error");
      return;
    }

    lastSuccessfulFillPlatform = '';
    if (carrierRefillTimer) {
      clearTimeout(carrierRefillTimer);
      carrierRefillTimer = null;
    }

    // Lấy khóa xử lý AI để tránh chạy nhiều luồng cùng lúc (Lỗi số 1 và 7)
    const acquired = await Mutex.acquire('ai_parsing');
    if (!acquired) {
      showVnpostToast("⏳ AI đang bóc tách, vui lòng đợi...", "info");
      return;
    }

    const btnParse = getVnpostEl('btnParseOrder');
    const progContainer = getVnpostEl('gemini-progress-container');
    const progBar = getVnpostEl('gemini-progress-bar');
    const txtStatus = getVnpostEl('ai-status');
    const txtPercent = getVnpostEl('ai-percent');

    if (btnParse) {
      btnParse.disabled = true;
      btnParse.style.backgroundColor = "#cccccc";
      btnParse.textContent = "⏳ Đang xử lý...";
    }

    if (typeof showPanelSkeleton === 'function') {
      showPanelSkeleton();
    }

    try {
      // Bước 1: Phân tích máy tính cục bộ cực nhanh
      const localResult = runLocalComputerParser(text);
      const rawExtractedAddress = localResult.address;

      // Lau sạch địa chỉ gốc tối thiểu: chỉ xóa sđt, ký tự thừa — KHÔNG phân tích cấp hành chính
      let cleanRaw = rawExtractedAddress;
      (localResult.extraPhones || []).forEach(p => { cleanRaw = cleanRaw.replace(p, ''); });
      if (localResult.phone) {
        cleanRaw = cleanRaw.replace(localResult.phone, '');
      }
      cleanRaw = cleanRaw.replace(/(?:\+84|84|0)(?:[\s\.\-]?\d){9,10}\b/g, '');
      cleanRaw = cleanRaw.replace(/sđt|sdt|đt|dt|tel|phone|lh|liên hệ\s*\d{0,11}\s*/gi, '');
      cleanRaw = cleanRaw.replace(/^(?:gửi\s+)?(?:ship\s+)?(?:cho\s+mình|cho\s+em|cho\s+tôi|cho\s+khách)?\s*(?:đến|về|tới)?\s*(?:địa\s*chỉ)?\s*[:\s\-•]*/gi, '');
      cleanRaw = cleanRaw.replace(/địa chỉ\s*:?\s*/gi, '');
      cleanRaw = cleanRaw.replace(/\s*(?:e\s+nhé|em\s+nhé|e\s+nha|em\s+nha|nhé\s+e|nhé\s+em|nha\s+e|nha\s+em|nhé|nha(?!\s+(?:trang|xá|mần|bè|nam|bắc|tây|đông|trung))|nghe|ơi|nhé\s+bạn|nhé\s+shop|nhé\s+ad|nhé\s+anh|nhé\s+chị|ạ|dạ)(?!\p{L}).*$/giu, '');
      cleanRaw = cleanRaw.replace(/\s*\(\s*(?:địa\s*chỉ\s*)?(?:sau\s*)?(?:sáp\s*nhập|xác\s*nhập|cũ|mới|giao\s*giờ\s*hành\s*chính)[^)]*\)\s*$/gi, '');
      cleanRaw = cleanRaw.replace(/[\s\.\,\-\–•]*(?:sđt|sdt|đt|dt|tel|phone|lh|liên\s*hệ|zalo|hotline)[:\s\-•]*$/gi, '');

      // Xóa tên khách hàng nếu bị dính ở đầu địa chỉ
      if (localResult.name) {
        const baseName = localResult.name.split(/[\(\[]/)[0].trim();
        if (baseName && baseName.length >= 3 && cleanRaw.toLowerCase().startsWith(baseName.toLowerCase())) {
          cleanRaw = cleanRaw.substring(baseName.length).trim();
        }
      }

      cleanRaw = cleanRaw.replace(/^[-\s\.\,\/]+|[-\s\.\,\/]+$/g, '').trim();
      cleanRaw = cleanRaw.replace(/,+/g, ',').trim();
      cleanRaw = cleanRaw.replace(/\s+/g, ' ').trim();
      cleanRaw = cleanRaw.replace(/\s*,\s*/g, ', ');
      cleanRaw = cleanRaw.replace(/(^|\s)([a-zAÀ-ỹ])/g, (_, sp, c) => sp + c.toUpperCase());
      cleanRaw = cleanRaw.replace(/(^|,\s*)([a-zAÀ-ỹ])/g, (_, sp, c) => sp + c.toUpperCase());
      localResult.address = cleanRaw || rawExtractedAddress;

      // Hiển thị địa chỉ gốc (chưa chuẩn hóa) trong rev-address
      globalThis.parsedDataStore = localResult;
      
      try {
        window.dispatchEvent(new CustomEvent('autofill:parsed', { detail: globalThis.parsedDataStore }));
      } catch (e) {}
      lookupCustomerAfterParse(globalThis.parsedDataStore).catch(() => {});

      if (progContainer && progBar && txtStatus && txtPercent) {
        progContainer.style.display = 'block';
        progBar.style.width = '30%';
        txtStatus.textContent = "⚡ Đang kiểm tra cơ sở dữ liệu địa giới...";
        txtPercent.textContent = "30%";
        const setParseStep = (id, complete, label) => {
          const el = getVnpostEl(id);
          if (el) {
            el.textContent = `${complete ? '✓' : '✕'} ${label}`;
            el.className = complete ? 'is-complete' : 'is-missing';
          }
        };
        setParseStep('parse-step-customer', Boolean(localResult.name), 'Nhận diện khách hàng');
        setParseStep('parse-step-phone', Boolean(localResult.phone), 'Nhận diện SĐT');
        setParseStep('parse-step-cod', Number(localResult.codAmount || 0) >= 0, 'Nhận diện COD');
        const addressStep = getVnpostEl('parse-step-address');
        if (addressStep) { addressStep.textContent = '● Đang chuẩn hóa địa chỉ'; addressStep.className = 'is-active'; }
      }

      // Hiển thị địa chỉ gốc ngay lập tức (không chờ pipeline)
      const rawSuggest = getVnpostEl('rev-suggest-2level');
      if (rawSuggest && localResult.address) {
        rawSuggest.textContent = localResult.address;
      }

      // Bước 2: Chuẩn hóa địa chỉ qua Address Engine — timeout 5s để tránh treo
      let addrResult;
      try {
        addrResult = await Promise.race([
          AddressEngine.process(localResult.address, localResult.phone),
          new Promise((_, reject) => setTimeout(() => reject(new Error('AddressEngine timeout')), 5000))
        ]);
      } catch (_engErr) {
        console.warn('[Parse] AddressEngine.process failed:', _engErr);
        addrResult = null;
      }

      // Cập nhật addressParts từ pipeline chuẩn hóa (dùng cho gợi ý & fill form)
      if (addrResult) {
        localResult.addressParts = {
          ward:     addrResult.ward     || '',
          district: addrResult.district || '',
          province: addrResult.province || ''
        };
      } else {
        localResult.addressParts = { ward: '', district: '', province: '' };
      }
      globalThis.parsedDataStore = localResult;

      // Cập nhật gợi ý địa chỉ sạch & quy đổi 2 cấp và tự động chọn địa chỉ sạch tối ưu
      if (addrResult) {
        const suggestCleanEl = getVnpostEl('rev-suggest-clean');
        const suggest2LevelEl = getVnpostEl('rev-suggest-2level');
        const referenceStatus = getVnpostEl('address-reference-status');
        const mergerNotice = getVnpostEl('ai-merger-notice');

        const cleanText = formatCleanAddress(addrResult, localResult.address);
        const twoLevelText = formatTwoLevelAddress(addrResult, localResult.address);
        const detectedLevel = detectAddressLevels(text, addrResult);

        localResult.addressLevel = detectedLevel;

        if (suggestCleanEl) suggestCleanEl.textContent = cleanText;
        if (suggest2LevelEl) suggest2LevelEl.textContent = twoLevelText;
        if (referenceStatus) {
          referenceStatus.textContent = detectedLevel === 2 ? 'Chuẩn 2 cấp' : 'Đã bóc tách';
          referenceStatus.className = 'address-reference-status is-ready';
        }

        const preferredAddress = (detectedLevel === 2 && twoLevelText && twoLevelText !== 'không tìm thấy')
          ? twoLevelText
          : cleanText;

        // Tự động gán địa chỉ chuẩn hóa phù hợp vào ô nhận hàng chính (không chèn quận nếu là 2 cấp)
        if (preferredAddress && preferredAddress !== 'không tìm thấy') {
          localResult.address = preferredAddress;
        }

        const btnClean = getVnpostEl('btn-switch-clean');
        const btn2Level = getVnpostEl('btn-switch-2level');
        const addressStatusBadge = getVnpostEl('address-status-badge');
        if (btnClean && btn2Level) {
          btnClean.classList.toggle('active', detectedLevel !== 2);
          btn2Level.classList.toggle('active', detectedLevel === 2);
        }
        if (addressStatusBadge) {
          addressStatusBadge.textContent = detectedLevel === 2 ? '🎯 Địa chỉ 2 Cấp' : '✓ Đã tối ưu';
          addressStatusBadge.title = detectedLevel === 2
            ? 'Địa chỉ được nhận diện theo chuẩn 2 cấp (không chèn quận). Bấm gợi ý để đổi 3 cấp nếu muốn.'
            : 'Địa chỉ chuẩn hóa 3 cấp đầy đủ.';
        }

        const wardEl = getVnpostEl('rev-addr-ward');
        const distEl = getVnpostEl('rev-addr-district');
        const provEl = getVnpostEl('rev-addr-province');
        if (wardEl) wardEl.textContent = addrResult.ward || '---';
        if (distEl) distEl.textContent = addrResult.district || '---';
        if (provEl) provEl.textContent = addrResult.province || '---';

        if (mergerNotice) {
          if (addrResult.warning) {
            mergerNotice.textContent = '📢 ' + addrResult.warning;
            mergerNotice.style.display = 'block';
          } else {
            mergerNotice.style.display = 'none';
          }
        }

        // Cập nhật lại giao diện với địa chỉ sạch và tính toán Readiness Status
        displayParsedData(localResult);
      }

      // Bỏ qua AI — không gọi runGroq nữa
      if (progBar && txtStatus && txtPercent) {
        progBar.style.width = '100%';
        txtStatus.textContent = "✅ Bóc tách thành công!";
        txtPercent.textContent = "100%";
      }
      const finalAddressStep = getVnpostEl('parse-step-address');
      if (finalAddressStep) { finalAddressStep.textContent = '✓ Đã chuẩn hóa địa chỉ'; finalAddressStep.className = 'is-complete'; }
      displayParsedData(localResult);
      if (btnParse) {
        btnParse.disabled = false;
        // Xóa inline style để trả về CSS gradient gốc (không dùng .style.backgroundColor)
        btnParse.style.removeProperty('background-color');
        btnParse.style.removeProperty('background');
        btnParse.innerHTML = (typeof PANEL_ICONS !== 'undefined' && PANEL_ICONS.parse ? PANEL_ICONS.parse + ' ' : '🤖 ') + "Tách Đơn Tự Động";
      }
      if (typeof globalThis.collapseSourceOrderCard === 'function') {
        globalThis.collapseSourceOrderCard(globalThis.parsedDataStore || localResult);
      }

      // Lưu lịch sử tách đơn
      try {
        if (typeof globalThis.SplitHistory !== 'undefined') {
          const platform = getCurrentPlatform();
          const res = await globalThis.SplitHistory.add(text, globalThis.parsedDataStore, platform);
          if (res && res.isDuplicate) {
            showVnpostToast('ℹ️ Đơn này đã được tách trước đó — cập nhật thời gian.', 'info');
          }
        }
      } catch (e) {
        console.warn('Lỗi ghi lịch sử:', e);
      }
    } catch (err) {
      Logger.error("Lỗi phân tích đơn:", err);
      showVnpostToast("❌ Có lỗi xảy ra trong quá trình phân tích.", "error");
    } finally {
      Mutex.release('ai_parsing');
    }
  }

  // ─── THEO DÕI MÃ VẬN ĐƠN SAU KHI LÊN ĐƠN ───
  function startTrackingCodeMonitor(savedOrderId, targetPlatform, onCodeFound) {
    let found = false;
    function extractCode(text) {
      if (!text) return null;
      const patterns = [
        /(?:số\s*hiệu\s*bưu\s*gửi|mã\s*bưu\s*gửi|mã\s*vận\s*đơn|mã\s*vận\s*chuyển|mã\s*vận\s*đơn\s*là|mã\s*bưu\s*gửi\s*là)\s*[:;]?\s*([A-Z0-9]{8,22})/i,
        /(?:mã\s*đơn(?:\s*hàng)?|order\s*id|tracking\s*(?:code|no|number)?)\s*[:;]?\s*([A-Z0-9]{8,22})/i,
        /\b(C\d{9,13}VN)\b/i,
        /\b(MP\d{8,12}VN)\b/i,
        /\b(E[A-Z]\d{8,12}VN)\b/i,
        /\b([A-Z]{2}\d{9,13}VN)\b/i,
        /\b(8\d{11,14})\b/
      ];
      for (const p of patterns) {
        const m = text.match(p);
        if (m && m[1]) return m[1].trim();
      }
      if (/^\d{10,15}$/.test(text.trim())) return text.trim();
      return null;
    }

    function tryNotify(code) {
      if (found) return;
      found = true;
      if (typeof onCodeFound === 'function') {
        onCodeFound(code);
      } else if (savedOrderId) {
        OrderStorage.updateSubmittedOrderTracking(savedOrderId, code).then(ok => {
          if (ok) showVnpostToast('📦 Đã lấy mã vận đơn: ' + code, 'success');
        });
      }
      if (trackMo) trackMo.disconnect();
      if (fetchRestore && typeof fetchRestore === 'function') fetchRestore();
      if (trackTimer) clearTimeout(trackTimer);
    }

    // DOM monitoring
    const trackMo = new MutationObserver(() => {
      const allEls = document.querySelectorAll('*:not(script):not(style)');
      for (const el of allEls) {
        if (el.children.length > 0) continue;
        const text = (el.textContent || '').trim();
        if (text.length < 8 || text.length > 200) continue;
        const code = extractCode(text);
        if (code) { tryNotify(code); return; }
      }
    });
    trackMo.observe(document.body, { childList: true, subtree: true, characterData: true });

    // Fetch API interception — bắt response từ API tạo đơn của VNPost
    let fetchRestore = null;
    if (targetPlatform === 'vnpost' || targetPlatform === 'jt') {
      const origFetch = window.fetch.bind(window);
      window.fetch = async function(input, init) {
        const url = typeof input === 'string' ? input : (input instanceof Request ? input.url : '');
        try {
          const response = await origFetch(input, init);
          if (response.ok && url.includes('order') && (init?.method || 'GET').toUpperCase() === 'POST') {
            const clone = response.clone();
            clone.json().then(body => {
              if (!body || found) return;
              const code = body.orderId || body.orderCode || body.trackingCode || body.maVanDon || body.shipmentNumber || body.id || null;
              if (code && /^[A-Z0-9]{8,20}$/i.test(String(code))) tryNotify(String(code));
            }).catch(() => {});
          }
          return response;
        } catch (e) { return origFetch(input, init); }
      };
      fetchRestore = () => { window.fetch = origFetch; };
    }

    // Cho J&T Express: Gọi API danh sách đơn hàng ngầm để lấy mã vận đơn tự động sau khi tạo đơn
    if (targetPlatform === 'jt') {
      const pollJtApi = async () => {
        if (found) return;
        try {
          const endpoints = [
            '/api/order/order/pageList',
            '/api/v2/order/page',
            '/api/order/pageList',
            '/api/order/list',
            '/api/v1/order/list'
          ];
          for (const ep of endpoints) {
            if (found) break;
            const resp = await fetch(ep, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ page: 1, pageSize: 5, pageNum: 1, size: 5 }),
              credentials: 'include'
            }).catch(() => null);

            if (resp && resp.ok) {
              const body = await resp.json().catch(() => null);
              if (body) {
                const list = body.data?.list || body.data?.records || body.data || body.list || [];
                if (Array.isArray(list) && list.length > 0) {
                  for (const item of list) {
                    const code = item.billCode || item.waybillNo || item.trackingNo || item.txLogisticId || item.code || null;
                    if (code && /^[A-Z0-9]{8,22}$/i.test(String(code))) {
                      tryNotify(String(code));
                      break;
                    }
                  }
                }
              }
            }
          }
        } catch (_) {}
      };

      setTimeout(pollJtApi, 1500);
      setTimeout(pollJtApi, 3500);
      setTimeout(pollJtApi, 7000);
    }

    // URL change detection (SPA redirect)
    const urlCheckTimer = setInterval(() => {
      if (found) { clearInterval(urlCheckTimer); return; }
      const text = document.body.innerText || '';
      const code = extractCode(text);
      if (code) tryNotify(code);
    }, 1000);
    setTimeout(() => { clearInterval(urlCheckTimer); if (!found) { trackMo.disconnect(); if (fetchRestore) fetchRestore(); } }, 30000);

    let trackTimer = setTimeout(() => { if (!found) { trackMo.disconnect(); if (fetchRestore) fetchRestore(); } }, 30000);
  }

  // ─── CẬP NHẬT LẠI TIỀN COD VÀO FORM BƯU ĐIỆN NẾU NGƯỜI DÙNG SỬA TRONG BẢNG XÉT DUYỆT ───
  async function updateCodInputInDOM(platform, newCod) {
    try {
      const plat = platform || (typeof getCurrentPlatform === 'function' ? getCurrentPlatform()?.id : 'vnpost');
      const cleanVal = Number(newCod || 0);

      if (plat === 'vnpost') {
        let codEl = document.querySelector('input[name="PROP0018"]');
        if (!codEl) {
          const codLabels = Array.from(document.querySelectorAll('label, .ant-form-item-label, span, b, div')).filter(l => {
            const txt = (l.innerText || l.textContent || '').trim().toLowerCase();
            return (txt.includes('phát hàng thu tiền') || txt.includes('thu tiền cod') || txt.includes('tiền thu hộ')) && !txt.includes('hủy');
          });
          for (const lbl of codLabels) {
            const container = lbl.closest('.ant-form-item, tr, .ant-row, .form-item') || lbl.parentElement;
            if (container) {
              const inp = container.querySelector('input[name="PROP0018"], input.ant-input-number-input, input[role="spinbutton"], input:not([type="checkbox"])');
              if (inp) { codEl = inp; break; }
            }
          }
        }
        if (codEl) {
          codEl.focus();
          if (typeof setInputValue === 'function') setInputValue(codEl, String(cleanVal));
          codEl.dispatchEvent(new Event('input', { bubbles: true }));
          codEl.dispatchEvent(new Event('change', { bubbles: true }));
          codEl.blur();
        }
      } else if (plat === 'jt') {
        let codInp = document.querySelector('input[placeholder*="Nhập số tiền" i]') || document.querySelector('#money');
        if (!codInp) {
          document.querySelectorAll('.el-form-item').forEach(item => {
            if ((item.innerText || '').includes('Tiền thu hộ')) {
              const el = item.querySelector('input');
              if (el) codInp = el;
            }
          });
        }
        if (codInp) {
          codInp.focus();
          if (typeof setInputValue === 'function') setInputValue(codInp, String(cleanVal));
          codInp.dispatchEvent(new Event('input', { bubbles: true }));
          codInp.dispatchEvent(new Event('change', { bubbles: true }));
          codInp.blur();
        }
      } else {
        const codEl = document.querySelector('input[name*="cod" i], input[placeholder*="thu hộ" i], input[placeholder*="cod" i]');
        if (codEl) {
          codEl.focus();
          if (typeof setInputValue === 'function') setInputValue(codEl, String(cleanVal));
          codEl.dispatchEvent(new Event('input', { bubbles: true }));
          codEl.dispatchEvent(new Event('change', { bubbles: true }));
          codEl.blur();
        }
      }
    } catch (err) {
      console.warn('[updateCodInputInDOM] error:', err);
    }
  }

  // ─── CHỐT CHẶN XÉT DUYỆT TOÀN CỤC KHI LÊN ĐƠN (KỂ CẢ LÊN ĐƠN BẰNG TAY) ───
  function initCarrierSubmitInterceptor(platform) {
    const plat = platform || (typeof getCurrentPlatform === 'function' ? getCurrentPlatform()?.id : 'vnpost');
    const submitKeywords = ['tạo đơn', 'đăng đơn', 'lưu đơn', 'gửi đơn', 'tạo bưu gửi', 'tạo mới', 'xác nhận', 'hoàn tất', 'tạo'];

    async function handleCarrierSubmitClick(e) {
      const btn = e.currentTarget || e.target;
      if (!btn) return;

      // Nếu nút bấm đã được duyệt qua modal trong lượt này thì cho đi tiếp
      if (btn.dataset.afApproved === 'true') {
        return;
      }

      // Ngăn chặn lệnh submit tức thì của hãng để mở Bảng Xét Duyệt
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();

      const activePlatform = plat || (typeof getCurrentPlatform === 'function' ? getCurrentPlatform()?.id : 'vnpost');
      const scrapedData = scrapeOrderFromDOM(activePlatform);

      // Nếu cả tên, sđt và địa chỉ đều trống (chưa nhập gì), bỏ qua để form của bưu điện tự hiện validation
      if (!scrapedData.name && !scrapedData.phone && (!scrapedData.address || scrapedData.address === 'không tìm thấy')) {
        btn.dataset.afApproved = 'true';
        btn.click();
        setTimeout(() => { btn.dataset.afApproved = ''; }, 2000);
        return;
      }

      // Lấy thông tin từ Panel để đối chiếu trực tiếp với Form Bưu Điện
      const panelData = (globalThis.parsedDataStore && (globalThis.parsedDataStore.phone || globalThis.parsedDataStore.name))
        ? { ...globalThis.parsedDataStore }
        : (globalThis.__AF_LAST_FILLED_ORDER__ ? { ...globalThis.__AF_LAST_FILLED_ORDER__ } : {});

      // Lấy đơn thô từ parsedDataStore hoặc từ ô nhập trên panel nếu có
      const rawInputEl = getVnpostEl('order-raw-input');
      const rawText = (globalThis.parsedDataStore && globalThis.parsedDataStore.rawText)
        || (rawInputEl ? rawInputEl.value : '')
        || '';

      if (typeof globalThis.showOrderApprovalModal === 'function') {
        try {
          const approval = await globalThis.showOrderApprovalModal({
            carrierData: scrapedData,
            panelData: panelData,
            orderData: scrapedData,
            rawText: rawText,
            platform: activePlatform,
            onUpdateCOD: async (newCod) => {
              await updateCodInputInDOM(activePlatform, newCod);
              if (globalThis.parsedDataStore) {
                globalThis.parsedDataStore.codAmount = newCod;
                if (newCod === 0) globalThis.parsedDataStore.codExplicitZero = true;
                if (typeof displayParsedData === 'function') displayParsedData(globalThis.parsedDataStore);
              }
            }
          });

          if (approval && approval.confirmed) {
            // Cập nhật lại số tiền COD nếu có thay đổi
            if (approval.orderData && approval.orderData.codAmount !== undefined) {
              await updateCodInputInDOM(activePlatform, approval.orderData.codAmount);
            }

            // Kích hoạt theo dõi lưu đơn (doSave)
            setupAutoSaveOnSubmit(activePlatform);

            // Đánh dấu đã duyệt và kích hoạt click thật
            btn.dataset.afApproved = 'true';
            btn.click();
            setTimeout(() => { btn.dataset.afApproved = ''; }, 3000);
          }
        } catch (modalErr) {
          console.warn('[handleCarrierSubmitClick] Error showing modal:', modalErr);
          btn.dataset.afApproved = 'true';
          btn.click();
          setTimeout(() => { btn.dataset.afApproved = ''; }, 2000);
        }
      } else {
        // Fallback an toàn nếu chưa nạp được modal
        btn.dataset.afApproved = 'true';
        btn.click();
        setTimeout(() => { btn.dataset.afApproved = ''; }, 2000);
      }
    }

    function scanAndHookButtons() {
      const btns = document.querySelectorAll('button, a, input[type="submit"], input[type="button"]');
      for (const btn of btns) {
        if (btn.closest('#vnpost-autofill-shadow-host')) continue;
        const text = (btn.innerText || btn.value || btn.textContent || '').trim().toLowerCase();
        if (!text || text.length > 35) continue;
        if (/hủy|xóa|tìm|tra cứu|đơn mẫu|hướng dẫn|quay lại|in|tải|nhập excel/i.test(text)) continue;

        if (submitKeywords.some(kw => text.includes(kw))) {
          if (btn.dataset.afSubmitHooked === '1') continue;
          btn.dataset.afSubmitHooked = '1';
          btn.addEventListener('click', handleCarrierSubmitClick, true); // capture phase
        }
      }
    }

    scanAndHookButtons();
    if (!_carrierSubmitInterceptorAttached) {
      _carrierSubmitInterceptorAttached = true;
      const mo = new MutationObserver(scanAndHookButtons);
      mo.observe(document.body, { childList: true, subtree: true });
    }
  }

  // ─── TỰ ĐỘNG LƯU ĐƠN KHI NGƯỜI DÙNG BẤM GỬI ĐƠN TRÊN TRANG ───
  function setupAutoSaveOnSubmit(platform) {
    const submitKeywords = ['tạo đơn', 'đăng đơn', 'lưu đơn', 'gửi đơn', 'tạo bưu gửi', 'tạo mới', 'xác nhận', 'hoàn tất', 'lưu', 'tạo'];

    // scrapeOrderFromDOM moved to IIFE scope
    function doSave() {
      // Luôn lấy giá trị từ DOM (form VNPost/J&T) trước — ưu tiên dữ liệu thực tế trên trang
      let data = scrapeOrderFromDOM(platform);
      const parsed = globalThis.parsedDataStore;
      const hasParsedData = !!parsed;
      
      // Bổ sung các trường còn thiếu từ parsedDataStore (panel) nếu trên form chưa có
      if (parsed) {
        if (!data.name) data.name = parsed.name || '';
        if (!data.phone) data.phone = parsed.phone || '';
        if (!data.address || data.address === 'không tìm thấy') data.address = (parsed.address && parsed.address !== 'không tìm thấy') ? parsed.address : '';
        if (!data.orderCode) data.orderCode = parsed.orderCode || '';
        if (!data.codAmount) data.codAmount = parsed.codAmount || 0;
        if (!data.collectFee) data.collectFee = parsed.collectFee || false;
        data.extraNote = data.extraNote || parsed.extraNote || '';
        if (parsed.id) data.id = parsed.id;
      }
      
      const { name, phone, address, orderCode } = data;
      if (!name && !phone && !address && !orderCode) return;
      
      const orderToSave = {
        name: name || '',
        phone: phone || '',
        address: address && address !== 'không tìm thấy' ? address : '',
        orderCode: orderCode || '',
        codAmount: data.codAmount || 0,
        collectFee: data.collectFee || false,
        platform: platform || '',
        extraNote: data.extraNote || '',
        carrierAccount: data.carrierAccount || detectCarrierAccount(platform) || ''
      };
      
      if (data.id) orderToSave.id = data.id;

      // ─── KIỂM TRA LÊN ĐƠN THÀNH CÔNG / THẤT BẠI TRƯỚC KHI GHI NHẬN ───
      let resolved = false;

      function checkDomError() {
        if (resolved) return null;
        // Check các toast / notification / form field error của VNPost & J&T
        const errorSelectors = [
          '.ant-notification-notice-error',
          '.ant-message-error',
          '.ant-alert-error',
          '.el-message--error',
          '.el-notification--error',
          '.el-form-item__error'
        ];
        for (const sel of errorSelectors) {
          const els = document.querySelectorAll(sel);
          for (const el of els) {
            if (el.offsetParent === null) continue; // ẩn / không visible
            const txt = (el.textContent || el.innerText || '').trim();
            if (txt && txt.length > 2) return txt;
          }
        }
        // Check dialog / modal thông báo lỗi
        const dialogs = document.querySelectorAll('.ant-modal-content, .el-dialog, [role="dialog"], .modal-content');
        for (const dlg of dialogs) {
          const txt = (dlg.textContent || dlg.innerText || '').trim();
          if (txt && /(?:lỗi|thất bại|không hợp lệ|không thành công|thiếu|chưa chọn|không đủ|sai)\s*(?:thông tin|dữ liệu|yêu cầu|nhập|chọn|đăng|ghi)?/i.test(txt)) {
            return txt;
          }
        }
        return null;
      }

      function onFailure(errText) {
        if (resolved) return;
        resolved = true;
        cleanup();
        showVnpostToast('❌ VNPost/J&T báo lỗi chưa thành công. Chưa ghi nhận đơn đã lên!', 'error');
      }

      function onSuccess(trackingCode) {
        if (resolved) return;

        // Tìm trackingCode nếu chưa có
        if (!trackingCode) {
          const successEls = document.querySelectorAll('.ant-message-success, .ant-notification-notice, .ant-alert-success, .el-message--success, .el-notification, [role="alert"]');
          for (const el of successEls) {
            const txt = (el.textContent || el.innerText || '').trim();
            const codeMatch = txt.match(/(?:mã\s*vận\s*đơn|mã\s*bưu\s*gửi|số\s*hiệu\s*bưu\s*gửi|tracking)\s*[:;]?\s*([A-Z0-9]{8,22})/i) ||
                              txt.match(/\b([A-Z]{2}\d{9,13}VN|C\d{9,13}VN|MP\d{8,12}VN|E[A-Z]\d{8,12}VN|8\d{11,14})\b/i);
            if (codeMatch && codeMatch[1]) {
              trackingCode = codeMatch[1].trim();
              break;
            }
          }
        }

        const latestDom = scrapeOrderFromDOM(platform);
        const nameToCheck = latestDom.name || data.name || orderToSave.name || '';
        const phoneToCheck = latestDom.phone || data.phone || orderToSave.phone || '';
        const orderCodeToCheck = latestDom.orderCode || data.orderCode || orderToSave.orderCode || '';

        // Kiểm tra xem đơn này vừa được xử lý gần đây chưa (tránh trùng lặp với interceptor)
        if (isSubmissionRecentlyHandled(trackingCode, orderCodeToCheck, phoneToCheck, nameToCheck)) {
          resolved = true;
          cleanup();
          if (trackingCode) {
            OrderStorage.updateLatestSubmittedOrderTracking(trackingCode).catch(() => {});
          }
          return;
        }

        // Ghi nhận đơn ngay (cả VNPost và J&T)
        resolved = true;
        cleanup();

        const cleanDomPhone = String(latestDom.phone || data.phone || orderToSave.phone || '').replace(/\D/g, '');
        const cleanDomOrderCode = String(latestDom.orderCode || data.orderCode || orderToSave.orderCode || '').trim().toLowerCase();
        const cleanPanelPhone = String(globalThis.parsedDataStore?.phone || globalThis.__AF_LAST_FILLED_ORDER__?.phone || '').replace(/\D/g, '');
        const cleanPanelOrderCode = String(globalThis.parsedDataStore?.orderCode || globalThis.__AF_LAST_FILLED_ORDER__?.orderCode || '').trim().toLowerCase();

        const isAutoFilled = Boolean(
          globalThis.__AF_JUST_FILLED__ ||
          (cleanDomPhone && cleanPanelPhone && cleanDomPhone.length >= 9 && cleanDomPhone === cleanPanelPhone) ||
          (cleanDomOrderCode && cleanPanelOrderCode && cleanDomOrderCode !== '—' && cleanDomOrderCode === cleanPanelOrderCode)
        );
        const orderSource = isAutoFilled ? 'AUTO_FILL' : 'MANUAL_ENTRY';
        orderToSave.source = orderSource;

        OrderStorage.saveOrder(orderToSave).then(saved => {
          if (hasParsedData && globalThis.parsedDataStore) {
            globalThis.parsedDataStore.id = saved.id;
            globalThis.parsedDataStore.createdAt = saved.createdAt;
          }

          // Ưu tiên cao nhất thông tin cào trực tiếp từ form trang VNPost / J&T
          const finalAddress = (latestDom.address && latestDom.address !== 'không tìm thấy')
            ? latestDom.address
            : ((data.address && data.address !== 'không tìm thấy') ? data.address : ((saved.address && saved.address !== 'không tìm thấy') ? saved.address : ((orderToSave.address && orderToSave.address !== 'không tìm thấy') ? orderToSave.address : '')));

          const submittedOrder = {
            name: latestDom.name || data.name || saved.name || orderToSave.name || '',
            phone: latestDom.phone || data.phone || saved.phone || orderToSave.phone || '',
            address: finalAddress,
            orderCode: latestDom.orderCode || data.orderCode || saved.orderCode || orderToSave.orderCode || '',
            codAmount: (latestDom.hasValidCodField && latestDom.codAmount !== undefined && latestDom.codAmount > 0)
              ? latestDom.codAmount
              : (data.codAmount || saved.codAmount || orderToSave.codAmount || 0),
            collectFee: latestDom.collectFee || data.collectFee || saved.collectFee || orderToSave.collectFee || false,
            platform: platform || '',
            extraNote: latestDom.extraNote || data.extraNote || saved.extraNote || orderToSave.extraNote || '',
            carrierAccount: latestDom.carrierAccount || data.carrierAccount || saved.carrierAccount || orderToSave.carrierAccount || detectCarrierAccount(platform) || '',
            trackingCode: trackingCode || '',
            savedOrderId: saved.id,
            source: orderSource
          };

          OrderStorage.saveSubmittedOrder(submittedOrder).then(() => {
            const sourceText = isAutoFilled ? '⚡ Tách đơn AI' : '✍️ Gõ tay thủ công';
            if (trackingCode) {
              showVnpostToast(`📦 Đã xác nhận lên đơn (${sourceText})! Mã vận đơn: ` + trackingCode, 'success');
            } else if (platform === 'jt') {
              showVnpostToast(`✅ Đã ghi nhận đơn J&T (${sourceText}) thành công!`, 'success');
            } else {
              showVnpostToast(`📬 Đã ghi nhận đơn VNPost (${sourceText})! Đang cập nhật mã vận đơn...`, 'success');
              startTrackingCodeMonitor(saved.id, platform);
            }

            globalThis.__AF_JUST_FILLED__ = false;

            // Phát sự kiện báo React panel rằng đơn đã được lưu DB
            window.dispatchEvent(new CustomEvent('order-saved-db'));

            // Tự động xóa dữ liệu trên panel sau khi lên đơn thành công
            setTimeout(() => {
              if (typeof handleClearOrder === 'function') {
                handleClearOrder(true);
              }
            }, 1000);
          }).catch((err) => {
            console.error('Lỗi khi lưu đơn vào DB:', err);
            showVnpostToast('❌ Lỗi khi lưu đơn vào Database!', 'error');
          });
        }).catch(() => {});
      }

      // Theo dõi DOM mutations
      const domMo = new MutationObserver(() => {
        if (resolved) return;

        // Luôn kiểm tra success TRƯỚC error — tránh field-validation false positive
        // khiến resolved = true trước khi API kịp trả về thành công
        const bodyText = document.body.innerText || '';

        if (platform === 'jt' && /đăng đơn thành công|đơn hàng được tải lên/i.test(bodyText)) {
          onSuccess();
          return;
        }

        if (platform === 'vnpost' && /(?:tạo vận đơn|tạo bưu gửi|tạo đơn|thêm mới|lưu bưu gửi|lưu vận đơn|lưu thông tin).*thành công/i.test(bodyText)) {
          const codeMatch = bodyText.match(/\b([A-Z]{2}\d{9,13}VN|C\d{9,13}VN|MP\d{8,12}VN|E[A-Z]\d{8,12}VN|8\d{11,14})\b/i) ||
                            bodyText.match(/(?:mã\s*vận\s*đơn|số\s*hiệu\s*bưu\s*gửi|mã\s*bưu\s*gửi|tracking)\s*[:;]?\s*([A-Z0-9]{8,22})/i);
          onSuccess(codeMatch ? codeMatch[1].trim() : null);
          return;
        }

        // Check success message trên DOM (chỉ match class success cụ thể và có nội dung tạo đơn thành công)
        const successSelector = '.ant-message-success, .ant-notification-notice-success, .ant-alert-success, .el-message--success, .el-notification--success';
        const successEls = document.querySelectorAll(successSelector);
        if (successEls.length > 0) {
          for (const el of successEls) {
            const txt = (el.textContent || el.innerText || '').trim();
            const isOrderSuccess = /(?:tạo|lưu|đăng|bưu gửi|vận đơn|thành công|đơn hàng|tracking)/i.test(txt);
            const codeMatch = txt.match(/\b([A-Z]{2}\d{9,13}VN|C\d{9,13}VN|MP\d{8,12}VN|E[A-Z]\d{8,12}VN|8\d{11,14})\b/i) ||
                              txt.match(/(?:mã\s*vận\s*đơn|số\s*hiệu\s*bưu\s*gửi|mã\s*bưu\s*gửi|tracking)\s*[:;]?\s*([A-Z0-9]{8,22})/i);
            if (isOrderSuccess || codeMatch) {
              onSuccess(codeMatch ? codeMatch[1].trim() : null);
              return;
            }
          }
        }

        // Chỉ kiểm tra error nếu chưa có success — giảm false positive từ field validation
        const err = checkDomError();
        if (err) {
          onFailure(err);
          return;
        }
      });
      domMo.observe(document.body, { childList: true, subtree: true, characterData: true });

      // Intercept fetch API cho request tạo đơn
      const origFetch = window.fetch.bind(window);
      window.fetch = async function(input, init) {
        const url = typeof input === 'string' ? input : (input instanceof Request ? input.url : '');
        try {
          const response = await origFetch(input, init);
          const method = (init?.method || 'GET').toUpperCase();
          if ((url.includes('order') || url.includes('shipment') || url.includes('delivery') || url.includes('create')) && method === 'POST') {
            const clone = response.clone();
            clone.json().then(body => {
              if (resolved) return;
              if (!response.ok || (body && (body.success === false || body.code === 400 || body.code === 500 || body.error || body.errorMessage))) {
                const errMsg = body?.message || body?.error || body?.errorMessage || ('HTTP ' + response.status);
                onFailure(errMsg);
              } else if (body) {
                const code = body.orderId || body.orderCode || body.trackingCode || body.maVanDon || body.shipmentNumber || body.itemCode || body.barcode || body.code || body.id || null;
                const foundCode = (code && /^[A-Z0-9]{8,22}$/i.test(String(code))) ? String(code) : null;
                onSuccess(foundCode);
              }
            }).catch(() => {
              if (!response.ok) onFailure('HTTP ' + response.status);
            });
          }
          return response;
        } catch (e) {
          return origFetch(input, init);
        }
      };

      function cleanup() {
        domMo.disconnect();
        window.fetch = origFetch;
        if (timerId) clearTimeout(timerId);
      }

      // 2s sau khi bấm gửi, kiểm tra xem có lỗi rõ ràng trên DOM không
      setTimeout(() => {
        if (resolved) return;
        const err = checkDomError();
        if (err) onFailure(err);
      }, 2000);

      // Timeout fallback: lưu đơn nếu không có lỗi sau 15s
      const timerId = setTimeout(() => {
        if (resolved) return;
        const err = checkDomError();
        if (err) {
          onFailure(err);
        } else {
          onSuccess();
        }
      }, 15000);
    }

    function tryHook() {
      const btns = document.querySelectorAll('button, a, input[type="submit"], input[type="button"]');
      for (const btn of btns) {
        const text = (btn.innerText || btn.value || btn.textContent || '').trim().toLowerCase();
        if (!text || text.length > 30) continue;
        if (submitKeywords.some(kw => text.includes(kw))) {
          if (btn.dataset.afAutoSave) continue;
          btn.dataset.afAutoSave = '1';
          btn.addEventListener('click', doSave);
        }
      }
    }

    tryHook();
    const mo = new MutationObserver(tryHook);
    mo.observe(document.body, { childList: true, subtree: true });
    setTimeout(() => mo.disconnect(), 20000);
  }

  // ─── ĐIỀN BIỂU MẪU ĐVVC (MUTEX KHÓA TRÙNG) ───
  // 🚀 ĐIỀN BIỂU MẪU ĐƠN (MUTEX KHÓA TRẠNG) 🚀
  async function triggerFillForm(targetPlatform, options = {}) {
    const isPanelUpdate = options.isPanelUpdate === true;
    if (!globalThis.parsedDataStore) {
      showVnpostToast("❌ Vui lòng bấm 'Tách Đơn Hàng' trước!", "error");
      return;
    }

    // Chống double click hoặc thao tác lặp ghi đè DOM (Lỗi số 1 & Lỗi số 7)
    const acquired = await Mutex.acquire('autofill_execution');
    if (!acquired) {
      showVnpostToast("⌛ Biểu mẫu đang được điền, vui lòng đợi...", "info");
      return;
    }

    const btnId = targetPlatform === 'vnpost' ? 'btnFillVNPost' : 'btnFillJT';
    let btn = getVnpostEl(btnId);
    if (!btn) btn = getVnpostEl('btnFillForm'); // Fallback for React UI
    const originalLabel = btn ? btn.innerHTML : '';

    const { name, phone, address, orderCode, codAmount, collectFee } = globalThis.parsedDataStore;

    const adapter = targetPlatform === 'vnpost' 
      ? globalThis.VNPostAdapter 
      : targetPlatform === 'jt' 
        ? globalThis.JTAdapter 
        : targetPlatform === 'viettel' 
          ? globalThis.ViettelPostAdapter 
          : targetPlatform === 'ghtk' 
            ? globalThis.GHTKAdapter 
            : (globalThis.VNPostAdapter || globalThis.JTAdapter);
    if (!adapter) {
      Mutex.release('autofill_execution');
      return;
    }

    const normalizedPhone = normalizePhoneNumber(phone);
    if (!normalizedPhone) {
      showVnpostToast("⚠️ Số điện thoại không đúng định dạng. Vui lòng sửa lại trước khi nhập đơn.", "error");
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = originalLabel;
      }
      Mutex.release('autofill_execution');
      return;
    }
    globalThis.parsedDataStore.phone = normalizedPhone;

    // ─── KIỂM TRA ĐƠN ĐÃ LÊN TRONG NGÀY TRƯỚC KHI ĐIỀN FORM ───
    try {
      if (typeof OrderStorage !== 'undefined' && typeof OrderStorage.getSubmittedOrders === 'function') {
        const submittedOrders = await OrderStorage.getSubmittedOrders().catch(() => []);
        const todayStr = new Date().toISOString().slice(0, 10);
        const todayLocale = new Date().toLocaleDateString('vi-VN');
        const checkCode = String(orderCode || '').trim().toLowerCase();
        const checkPh = String(normalizedPhone || '').replace(/\D/g, '');

        const dup = (submittedOrders || []).find(sub => {
          const rawDate = sub.submittedAt || sub.createdAt || sub.updatedAt || '';
          let isToday = false;
          if (rawDate) {
            const dStr = new Date(rawDate).toISOString().slice(0, 10);
            const dLocale = new Date(rawDate).toLocaleDateString('vi-VN');
            if (dStr === todayStr || dLocale === todayLocale) isToday = true;
          } else {
            isToday = true;
          }
          if (!isToday) return false;
          const subCode = String(sub.orderCode || sub.order_code || '').trim().toLowerCase();
          const subPhone = String(sub.phone || '').replace(/\D/g, '');
          const hasBothCodes = Boolean(checkCode && checkCode !== '—' && checkCode !== '-' && subCode && subCode !== '—' && subCode !== '-');
          if (hasBothCodes && checkCode !== subCode) {
            return false; // Khách mua 2 cây khác nhau trong ngày -> khác mã đơn -> không coi là trùng
          }
          return (checkCode && checkCode !== '—' && checkCode !== '-' && subCode && checkCode === subCode) ||
                 (checkPh && checkPh.length >= 9 && subPhone && checkPh === subPhone);
        });

        if (dup) {
          const dupTime = dup.submittedAt ? new Date(dup.submittedAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) : 'Hôm nay';
          showVnpostToast(`⚠️ LƯU Ý: Đơn này (${dup.orderCode || dup.phone}) đã được lên đơn hôm nay lúc ${dupTime}${dup.trackingCode ? ` (Mã VĐ: ${dup.trackingCode})` : ''}!`, 'warning', 5000);
        }
      }
    } catch (_) {}

    if (btn) {
      btn.disabled = true;
      btn.textContent = '⏳ Đang xử lý...';
    }

    try {
      if (adapter.prepare && !isPanelUpdate) {
        if (btn && targetPlatform === 'vnpost') btn.textContent = '⏳ Đang chọn đơn mẫu...';
        const ok = await adapter.prepare();
        if (!ok) {
          Mutex.release('autofill_execution');
          if (btn) btn.disabled = false;
          return;
        }
      }
      if (btn) btn.textContent = '⏳ Đang chờ biểu mẫu...';

      // Chờ cho đến khi ô nhập số điện thoại xuất hiện (tối đa 8 giây)
      const inputEl = await waitFor(() => {
        const platformSelectors = targetPlatform === 'vnpost' ? globalThis.VNPOST_SELECTORS : globalThis.JT_SELECTORS;
        return findFieldInput(platformSelectors.phoneLabels, platformSelectors.phoneFallbacks);
      }, 8000, 300);

      if (!inputEl) {
        showVnpostToast('❌ Không tìm thấy biểu mẫu điền đơn của trang web.', 'error');
        Mutex.release('autofill_execution');
        if (btn) btn.disabled = false;
        return;
      }

      if (btn) btn.textContent = '⏳ Đang điền đơn...';
      
      // Thực thi điền thông tin (await để chờ J&T dropdown xử lý xong)
      await adapter.fill(name, normalizedPhone, address, orderCode, codAmount, collectFee);
      lastSuccessfulFillPlatform = targetPlatform;
      globalThis.__AF_JUST_FILLED__ = true;
      globalThis.__AF_LAST_FILLED_ORDER__ = {
        name,
        phone: normalizedPhone,
        address,
        orderCode,
        codAmount,
        collectFee,
        platform: targetPlatform,
        timestamp: Date.now()
      };
      showVnpostToast('✅ Đã điền đơn thành công!', 'success');

      // Ghi nhận Log Vận hành
      if (typeof AuditLogger !== 'undefined' && typeof AuditLogger.logOperation === 'function') {
        AuditLogger.logOperation('AUTOFILL_SUCCESS', `Tự động điền đơn cho khách ${name} (${orderCode || 'Không mã'}) vào ${targetPlatform}`, {
          name,
          phone: normalizedPhone,
          orderCode,
          platform: targetPlatform,
          codAmount
        });
      }

      // Tự động theo dõi khi người dùng bấm nút Tạo đơn / Đăng đơn trên trang web
      setupAutoSaveOnSubmit(targetPlatform);
    } catch (err) {
      if (typeof AuditLogger !== 'undefined' && typeof AuditLogger.logError === 'function') {
        AuditLogger.logError('AUTOFILL_FAILED', `Lỗi khi điền đơn vào ${targetPlatform}: ${err?.message || err}`, {
          platform: targetPlatform,
          error: err?.message || err
        });
      }
      showVnpostToast('❌ Có lỗi khi điền đơn: ' + (err?.message || err), 'error');
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = originalLabel;
      }
      Mutex.release('autofill_execution');
    }
  }

  function scheduleCarrierRefillAfterEdit() {
    if (!lastSuccessfulFillPlatform) return;
    if (carrierRefillTimer) clearTimeout(carrierRefillTimer);
    // Chỉ tự động cập nhật lại form bưu cục khi người dùng đã kết thúc chỉnh sửa (không focus vào bất kỳ ô nào)
    carrierRefillTimer = setTimeout(() => {
      carrierRefillTimer = null;
      if (!lastSuccessfulFillPlatform) return;
      const host = document.getElementById('vnpost-autofill-shadow-host');
      if (host && host.shadowRoot) {
        const active = host.shadowRoot.activeElement;
        if (active && (active.isContentEditable || active.tagName === 'INPUT' || active.tagName === 'TEXTAREA')) {
          return; // Người dùng đang thao tác, tuyệt đối không tự nhập đơn
        }
      }
      triggerFillForm(lastSuccessfulFillPlatform, { isPanelUpdate: true });
    }, 1500);
  }

  // ─── CẬP NHẬT TRƯỜNG CHỈNH SỬA TRỰC TIẾP ───
  async function updateParsedField(field, value) {
    if (!globalThis.parsedDataStore) return;
    const oldAddress = globalThis.parsedDataStore.address;
    
    globalThis.parsedDataStore[field] = value;
    
    if (globalThis.parsedDataStore.id) {
      autoUpdateSavedOrder();
    }

    // Tự động bóc tách và chuẩn hóa lại gợi ý 2 cấp khi người dùng sửa ô địa chỉ
    if (field === 'address' && value) {
      // 1. Luôn giữ nguyên giá trị người dùng trực tiếp sửa tay vào ô hiển thị và dataStore
      globalThis.parsedDataStore.address = value;
      const addressEl = getVnpostEl('rev-address');
      if (addressEl && addressEl.textContent !== value) {
        addressEl.textContent = value;
      }

      // 2. Cập nhật gợi ý 2 cấp, 3 cấp và bóc tách các cấp Tỉnh/Huyện/Xã (để adapter bưu điện chọn được dropdown)
      // TUYỆT ĐỐI KHÔNG ghi đè lại nội dung ô rev-address người dùng vừa sửa tay!
      await refreshAddressSuggestion(value, globalThis.parsedDataStore.phone);

      // 3. Tự động học lại khi người dùng sửa thủ công để tối ưu AKB
      if (value !== oldAddress) {
        const rawEl = getVnpostEl('rawOrderText');
        const rawText = rawEl ? rawEl.value.trim() : '';
        const localResult = typeof runLocalComputerParser === 'function' ? runLocalComputerParser(rawText) : {};
        const rawAddress = localResult.address;
        if (typeof AddressParser !== 'undefined' && typeof AddressLearning !== 'undefined') {
          const parsedCorrect = AddressParser.parse(AddressNormalizer.normalize(value));
          if (parsedCorrect) {
            parsedCorrect.confidence = 100; // Người dùng trực tiếp sửa tay -> độ tin cậy tối đa 100%
            AddressLearning.learn(value, parsedCorrect, globalThis.parsedDataStore.phone);
            if (rawAddress && rawAddress !== "không tìm thấy") {
              AddressLearning.learn(rawAddress, parsedCorrect, globalThis.parsedDataStore.phone);
            }
          }
        }
      }
    }

    if (field === 'address' && globalThis.parsedDataStore.id) {
      autoUpdateSavedOrder();
    }

    if (field === 'orderCode' || field === 'phone' || field === 'name') {
      if (typeof globalThis.checkAndDisplayDuplicateAlert === 'function') {
        globalThis.checkAndDisplayDuplicateAlert(globalThis.parsedDataStore);
      }
    }

    try {
      window.dispatchEvent(new CustomEvent('autofill:parsed', { detail: globalThis.parsedDataStore }));
    } catch (_) {}
    lookupCustomerAfterParse(globalThis.parsedDataStore).catch(() => {});
    scheduleCarrierRefillAfterEdit();
  }

  async function autoUpdateSavedOrder() {
    if (!globalThis.parsedDataStore || !globalThis.parsedDataStore.id) return;
    try {
      const platform = getCurrentPlatform();
      const orderToSave = {
        id: globalThis.parsedDataStore.id,
        name: globalThis.parsedDataStore.name || "",
        phone: globalThis.parsedDataStore.phone || "",
        address: globalThis.parsedDataStore.address && globalThis.parsedDataStore.address !== "không tìm thấy" ? globalThis.parsedDataStore.address : "",
        orderCode: globalThis.parsedDataStore.orderCode || "",
        codAmount: globalThis.parsedDataStore.codAmount || 0,
        collectFee: globalThis.parsedDataStore.collectFee || false,
        extraNote: globalThis.parsedDataStore.extraNote || "",
        carrierAccount: detectCarrierAccount(platform) || globalThis.parsedDataStore.carrierAccount || "",
        platform: platform ? platform.id : "",
        createdAt: globalThis.parsedDataStore.createdAt
      };
      
      await OrderStorage.saveOrder(orderToSave);
    } catch (err) {
      Logger.error("Lỗi khi tự động cập nhật đơn hàng đã lưu:", err);
    }
  }

  function strip2025Province(addressVal) {
    if (!addressVal) return '';
    return String(addressVal)
      .replace(/\s*\([^)]*(?:2025|sáp nhập|cũ|mới)[^)]*\)/gi, '')
      .trim();
  }

  function handleAiAddressClick(addressVal) {
    if (!addressVal || !globalThis.parsedDataStore) return;
    copyToClipboard(addressVal);
    
    const cleanAddress = strip2025Province(addressVal);
    globalThis.parsedDataStore.address = cleanAddress;
    const revAddress = getVnpostEl('rev-address');
    if (revAddress) revAddress.textContent = cleanAddress;
    
    if (globalThis.parsedDataStore.id) {
      autoUpdateSavedOrder();
    }

    const aiGeoBox = getVnpostEl('ai-geo-box');
    if (aiGeoBox) {
      aiGeoBox.style.backgroundColor = '#dbeafe';
      setTimeout(() => { aiGeoBox.style.backgroundColor = '#eff6ff'; }, 400);
    }
    showVnpostToast('📍 Đã chọn địa chỉ: ' + cleanAddress, 'success');
  }

  function copyToClipboard(text) {
    if (!text || text === "không tìm thấy") return;
    navigator.clipboard.writeText(text).catch(() => {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
    });
  }

  function handleClearOrder(silent = false) {
    globalThis.parsedDataStore = null;
    lastSuccessfulFillPlatform = '';
    if (carrierRefillTimer) {
      clearTimeout(carrierRefillTimer);
      carrierRefillTimer = null;
    }
    const rawOrderText = getVnpostEl('rawOrderText');
    if (rawOrderText) {
      rawOrderText.value = '';
      rawOrderText.focus();
    }
    const reviewPanel = getVnpostEl('review-panel');
    const aiGeoBox = getVnpostEl('ai-geo-box');
    const geminiContainer = getVnpostEl('gemini-progress-container');
    const dupAlert = getVnpostEl('panel-duplicate-alert');
    if (reviewPanel) reviewPanel.style.display = 'none';
    if (aiGeoBox) aiGeoBox.style.display = 'none';
    if (geminiContainer) geminiContainer.style.display = 'none';
    if (dupAlert) dupAlert.style.display = 'none';
    if (typeof globalThis.resetSourceOrderCard === 'function') {
      globalThis.resetSourceOrderCard();
    }
    if (!silent) {
      showVnpostToast('🗑️ Đã xóa, sẵn sàng dán đơn mới.', 'info');
    }
  }

  function openSettingsPage() {
    try {
      chrome.runtime.sendMessage({ action: 'openOptions' }, () => {
        if (chrome.runtime.lastError) {
          showVnpostToast('Không thể tự mở trang cài đặt. Vào chrome://extensions → Auto Fill Order → "Tùy chọn".', 'error');
        }
      });
    } catch (e) {
      showVnpostToast('Không thể tự mở trang cài đặt. Vào chrome://extensions → Auto Fill Order → "Tùy chọn".', 'error');
    }
  }

  async function handleSaveOrder() {
    if (!globalThis.parsedDataStore) {
      showVnpostToast("⚠️ Vui lòng tách đơn hàng trước khi lưu!", "error");
      return;
    }

    const { name, phone, address, orderCode, codAmount, collectFee } = globalThis.parsedDataStore;

    if (!name && !phone && !address && !orderCode) {
      showVnpostToast("⚠️ Không có thông tin để lưu!", "error");
      return;
    }

    const btnSave = getVnpostEl('btnSaveOrder');
    if (btnSave) {
      btnSave.disabled = true;
      btnSave.textContent = "⏳ Đang lưu...";
    }

    try {
      const platform = getCurrentPlatform();
      const carrierAccount = detectCarrierAccount(platform);
      const orderToSave = {
        name: name || "",
        phone: phone || "",
        address: address && address !== "không tìm thấy" ? address : "",
        orderCode: orderCode || "",
        codAmount: codAmount || 0,
        collectFee: collectFee || false,
        platform: platform || "",
        carrierAccount: carrierAccount || globalThis.parsedDataStore.carrierAccount || "",
        extraNote: globalThis.parsedDataStore.extraNote || ""
      };

      if (globalThis.parsedDataStore.id) {
        orderToSave.id = globalThis.parsedDataStore.id;
      }

      // Kiểm tra đơn đã lưu ở ĐVVC khác chưa
      try {
        if (typeof OrderStorage !== 'undefined' && orderToSave.platform) {
          const allSaved = await OrderStorage.getOrders();
          const sameOnOther = allSaved.filter(o =>
            o.id !== orderToSave.id &&
            o.platform && o.platform !== orderToSave.platform &&
            (
              (orderToSave.orderCode && o.orderCode &&
                orderToSave.orderCode.toLowerCase() === o.orderCode.toLowerCase()) ||
              (orderToSave.name && orderToSave.phone &&
                orderToSave.name.toLowerCase() === (o.name || '').toLowerCase() &&
                orderToSave.phone.replace(/\D/g, '') === (o.phone || '').replace(/\D/g, ''))
            )
          );
          if (sameOnOther.length > 0) {
            const otherPlatforms = [...new Set(sameOnOther.map(o => o.platform))].join(', ');
            const wantContinue = typeof showPanelConfirmModal === 'function'
              ? await showPanelConfirmModal(
                  `Đơn này đã được tạo trên ${otherPlatforms.toUpperCase()} trước đó!\n\n` +
                  `Khách: ${orderToSave.name} - ${orderToSave.phone}\n` +
                  `Mã: ${orderToSave.orderCode || '—'}\n\n` +
                  `Bạn có muốn tạo tiếp đơn này trên ${orderToSave.platform.toUpperCase()} không?`
                )
              : confirm(
                  `⚠️ ĐƠN NÀY ĐÃ ĐƯỢC TẠO TRÊN ${otherPlatforms.toUpperCase()} TRƯỚC ĐÓ!\n\n` +
                  `Khách: ${orderToSave.name} - ${orderToSave.phone}\n` +
                  `Mã: ${orderToSave.orderCode || '—'}\n\n` +
                  `Bạn có muốn tạo tiếp đơn này trên ${orderToSave.platform.toUpperCase()} không?`
                );
            if (!wantContinue) {
              if (btnSave) { btnSave.disabled = false; btnSave.textContent = "💾 Lưu đơn"; }
              return;
            }
          }
        }
      } catch (_e) {}

      const savedOrder = await OrderStorage.saveOrder(orderToSave);
      globalThis.parsedDataStore.id = savedOrder.id;
      globalThis.parsedDataStore.createdAt = savedOrder.createdAt;
      
      showVnpostToast("📦 Đã lưu vào Đơn nháp thành công!", "success");
    } catch (err) {
      Logger.error("Lỗi khi lưu đơn hàng:", err);
      showVnpostToast("❌ Lỗi khi lưu: " + (err?.message || err), "error");
    } finally {
      if (btnSave) {
        btnSave.disabled = false;
        btnSave.textContent = "💾 Lưu đơn";
      }
    }
  }

  // ─── KIỂM TRA ĐƠN ĐIỀN LẠI PENDING ───
  function checkPendingRefill() {
    try {
      if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id || !chrome.storage || !chrome.storage.local) {
        return;
      }
      chrome.storage.local.get(['pendingRefillOrder'], (res) => {
        const lastErr = chrome.runtime.lastError;
        if (lastErr) return;
        if (!res || !res.pendingRefillOrder) return;
        const order = res.pendingRefillOrder;
        chrome.storage.local.remove('pendingRefillOrder');

        const tryFill = (attempt) => {
          const rawEl = getVnpostEl('rawOrderText');
          if (!rawEl) {
            if (attempt < 20) setTimeout(() => tryFill(attempt + 1), 300);
            return;
          }

          const lines = [];
          if (order.name)      lines.push(order.name);
          if (order.phone)     lines.push(order.phone);
          if (order.address)   lines.push(order.address);
          if (order.orderCode) lines.push('Mã đơn: ' + order.orderCode);
          if (order.codAmount) lines.push('COD: ' + order.codAmount);
          if (order.collectFee) lines.push('+ cước');
          rawEl.value = lines.join('\n');
          rawEl.dispatchEvent(new Event('input', { bubbles: true }));

          const platform = getCurrentPlatform();
          if (!platform) return;

          globalThis.parsedDataStore = {
              name:        order.name        || '',
              phone:       order.phone       || '',
              address:     order.address     || '',
              orderCode:   order.orderCode   || '',
              codAmount:   order.codAmount   || 0,
              collectFee:  order.collectFee  || false,
              platform:    order.platform    || '',
              extraPhones: [],
              extraNote:   order.extraNote   || ''
          };

          displayParsedData(globalThis.parsedDataStore);

          setTimeout(() => {
              triggerFillForm(platform.id);
          }, 500);

          showVnpostToast('✅ Đã tự động tải và điền đơn!', 'success');
        };
        tryFill(0);
      });
    } catch(e) { console.warn('checkPendingRefill error:', e); }
  }

  // Lắng nghe thay đổi storage từ trang Options khi bấm "Nhập đơn" hoặc khi trạng thái đăng nhập thay đổi
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'local') {
        if (changes.pendingRefillOrder && changes.pendingRefillOrder.newValue) {
          const order = changes.pendingRefillOrder.newValue;
          const platform = getCurrentPlatform();
          if (platform && (!order.platform || order.platform === platform.id)) {
            checkPendingRefill();
          }
        }
        // Tự động làm mới trạng thái panel khi đăng nhập/đăng xuất hoặc thay đổi API key (không cần bấm F5)
        if (changes.vnpost_session || changes.groqApiKey) {
          checkUrlAndInject();
        }
      }
    });
  }

  if (typeof globalThis.AuthEvents !== 'undefined' && typeof globalThis.AuthEvents.on === 'function') {
    globalThis.AuthEvents.on('AUTH_STATE_CHANGED', () => {
      checkUrlAndInject();
    });
  }

  setTimeout(checkPendingRefill, 600);

  // Chạy chẩn đoán DOM J&T sau 3 giây để thu thập dữ liệu phục vụ gỡ lỗi
  setTimeout(() => {
    try {
      const platform = getCurrentPlatform();
      if (platform && platform.id === 'jt') {
        const inputs = Array.from(document.querySelectorAll('input, textarea'));
        const diagnosticInfo = inputs.map(el => {
          let labelText = '';
          const id = el.id;
          if (id) {
            const lbl = document.querySelector(`label[for="${id}"]`);
            if (lbl) labelText = lbl.innerText;
          }
          if (!labelText) {
            const parentLabel = el.closest('label');
            if (parentLabel) labelText = parentLabel.innerText;
          }
          if (!labelText) {
            const formItem = el.closest('.el-form-item');
            const lbl = formItem ? formItem.querySelector('.el-form-item__label') : null;
            if (lbl) labelText = lbl.innerText;
          }
          return {
            tag: el.tagName,
            id: el.id || '',
            name: el.name || '',
            placeholder: el.placeholder || '',
            type: el.type || '',
            labelText: (labelText || '').trim().replace(/\s+/g, ' ')
          };
        });
        Logger.log("Chẩn đoán DOM J&T (Diagnostics)", diagnosticInfo);
      }
    } catch (e) {
      console.warn("Diagnostics run error:", e);
    }
  }, 6000);

  // ─── LẮNG NGHE LỆNH TỪ TRANG OPTIONS (BULK PARSE) ───
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'LOGOUT_BROADCAST' || request.type === 'LOGOUT_BROADCAST') {
        try {
          if (typeof localStorage !== 'undefined') {
            localStorage.removeItem('vnpost_session');
            localStorage.removeItem('af_logged_user');
            localStorage.removeItem('profile');
            localStorage.removeItem('currentUser');
            localStorage.removeItem('activeShopId');
            localStorage.removeItem('shop_access_key');
            localStorage.removeItem('staff_name');
          }
        } catch (_) {}
        setTimeout(() => {
          checkUrlAndInject();
        }, 50);
        sendResponse({ ok: true });
        return true;
      }
      if (request.type === 'deviceRevoked' || request.action === 'deviceRevoked') {
        // Thiết bị bị thu hồi: xoá panel + báo user ngay trên trang
        try {
          if (typeof window.__antigravityFloatingPanel !== 'undefined' && window.__antigravityFloatingPanel) {
            window.__antigravityFloatingPanel.remove();
            window.__antigravityFloatingPanel = null;
          }
        } catch (_) {}
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.remove(['vnpost_session', 'fbAuthTokens', 'fbDeviceId', 'fbDeviceName'], () => {
            try { showVnpostToast('⚠️ Thiết bị này đã bị thu hồi. Vui lòng đăng nhập lại bằng thiết bị được phép.', 'error'); } catch (_) {}
            setTimeout(() => { location.reload(); }, 1500);
          });
        }
        sendResponse({ ok: true });
        return true;
      }
      if (request.action === 'FILL_FROM_BULK' && request.order) {
        const platform = getCurrentPlatform();
        if (platform && platform.id === request.platform) {
          const order = request.order;
          globalThis.parsedDataStore = {
            id:          order.id || '',
            name:        order.name || '',
            phone:       order.phone || '',
            address:     order.address || '',
            orderCode:   order.orderCode || '',
            codAmount:   order.codAmount || 0,
            collectFee:  order.collectFee || false,
            platform:    order.platform || '',
            extraPhones: [],
            extraNote:   order.extraNote || ''
          };
          displayParsedData(globalThis.parsedDataStore);
          
          setTimeout(() => {
            triggerFillForm(platform.id);
          }, 200);

          showVnpostToast('✅ Đã tự động điền đơn từ Tách hàng loạt!', 'success');
          sendResponse({ success: true });
        }
      }
      return true;
    });
  }
  // ─── TỰ ĐỘNG BẮT MÃ VẬN ĐƠN TRÊN TRANG ORDER TABLE CỦA J&T EXPRESS ───
  if (window.location.hostname.includes('jtexpress.vn')) {
    const scanJtOrderTablePage = async () => {
      const rows = document.querySelectorAll('tr, .el-table__row');
      if (!rows || rows.length === 0) return;

      const submitted = await OrderStorage.getSubmittedOrders().catch(() => []);
      if (!submitted || submitted.length === 0) return;

      const unassigned = submitted.filter(s => !s.trackingCode || s.trackingCode === '—' || s.trackingCode === '');
      if (unassigned.length === 0) return;

      rows.forEach(row => {
        const text = row.textContent || row.innerText || '';
        const normalizedText = text.replace(/[\s\-\.,]/g, '').toLowerCase();

        const codeMatch = normalizedText.match(/(?:^|[^0-9])(8\d{11,14}|jt\d{10,14})(?:[^0-9]|$)/) || 
                          normalizedText.match(/(?:mãvậnđơn|tracking|waybill)(?:[:;]*)([a-z0-9]{8,22})/);
        if (!codeMatch) return;
        const waybillCode = codeMatch[1].toUpperCase();

        unassigned.forEach(sub => {
          const normPhone = sub.phone ? sub.phone.replace(/[\s\-\.,]/g, '') : null;
          const phoneMatch = normPhone && normalizedText.includes(normPhone);

          const normName = sub.name ? sub.name.replace(/[\s\-\.,]/g, '').toLowerCase() : null;
          const nameMatch = normName && normName.length > 2 && normalizedText.includes(normName);

          const normOrderCode = sub.orderCode && sub.orderCode !== '—' ? sub.orderCode.replace(/[\s\-\.,]/g, '').toLowerCase() : null;
          const orderCodeMatch = normOrderCode && normalizedText.includes(normOrderCode);

          if (phoneMatch || nameMatch || orderCodeMatch) {
            window.__processedWaybills = window.__processedWaybills || new Set();
            if (window.__processedWaybills.has(waybillCode)) return;
            window.__processedWaybills.add(waybillCode);

            OrderStorage.updateSubmittedOrderTracking(sub.savedOrderId || sub.id, waybillCode).then(ok => {
              if (ok) showVnpostToast('📦 Đã tự động cập nhật mã vận đơn J&T: ' + waybillCode, 'success');
            });
            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
              try {
                chrome.runtime.sendMessage({ action: 'jtWaybillFound', waybillCode, orderId: sub.savedOrderId || sub.id });
              } catch (_) {}
            }
          }
        });
      });
    };

    setInterval(scanJtOrderTablePage, 2500);
    onDOMReady(scanJtOrderTablePage);
  }

  // ─── TỰ ĐỘNG BẮT MÃ VẬN ĐƠN TRÊN TRANG ORDER MANAGER CỦA VNPOST ───
  if (window.location.hostname.includes('vnpost.vn')) {
    const scanVnpostOrderManagerPage = async () => {
      const rows = document.querySelectorAll('tr, .ant-table-row, .order-item, .item-order');
      if (!rows || rows.length === 0) return;

      const submitted = await OrderStorage.getSubmittedOrders().catch(() => []);
      if (!submitted || submitted.length === 0) return;

      const unassigned = submitted.filter(s => !s.trackingCode || s.trackingCode === '—' || s.trackingCode === '');
      if (unassigned.length === 0) return;

      rows.forEach(row => {
        const text = row.textContent || row.innerText || '';
        const normalizedText = text.replace(/[\s\-\.,]/g, '').toLowerCase();

        const codeMatch = text.match(/\b([A-Z]{2}\d{9}VN|C[A-Z0-9]{8,11}VN|MP[A-Z0-9]{7,11}VN|E[A-Z0-9]{8,11}VN|R[A-Z0-9]{8,11}VN)\b/i) ||
                          text.match(/(?:mã\s*vận\s*đơn|số\s*hiệu\s*bưu\s*gửi|mã\s*bưu\s*gửi|tracking)\s*[:;]?\s*([A-Z0-9]{8,22})/i);
        if (!codeMatch) return;
        const waybillCode = codeMatch[1].trim();

        unassigned.forEach(sub => {
          const normPhone = sub.phone ? sub.phone.replace(/[\s\-\.,]/g, '') : null;
          const phoneMatch = normPhone && normalizedText.includes(normPhone);

          const normName = sub.name ? sub.name.replace(/[\s\-\.,]/g, '').toLowerCase() : null;
          const nameMatch = normName && normName.length > 2 && normalizedText.includes(normName);

          const normOrderCode = sub.orderCode && sub.orderCode !== '—' ? sub.orderCode.replace(/[\s\-\.,]/g, '').toLowerCase() : null;
          const orderCodeMatch = normOrderCode && normalizedText.includes(normOrderCode);

          if (phoneMatch || nameMatch || orderCodeMatch) {
            window.__processedWaybills = window.__processedWaybills || new Set();
            if (window.__processedWaybills.has(waybillCode)) return;
            window.__processedWaybills.add(waybillCode);

            const orderId = sub.savedOrderId || sub.id;
            // Trích xuất tên/SĐT từ row để cập nhật vào đơn nếu đang bị thiếu
            let rowName = sub.name || '';
            let rowPhone = sub.phone || '';
            if (!rowName || !rowPhone) {
              const phoneMatchInRow = text.match(/(?:\+84|84|0)(?:\s*[\.\-]?\s*\d){9,10}\b/);
              if (phoneMatchInRow) rowPhone = phoneMatchInRow[0].replace(/\D/g, '');
              // Tên thường đứng đầu row trước số phone
              if (!rowName) {
                const nameBeforePhone = text.match(/^([A-ZÀ-ỹ][a-zà-ỹ]*(?:\s+[A-ZÀ-ỹ][a-zà-ỹ]*){1,4})/);
                if (nameBeforePhone) rowName = nameBeforePhone[1].trim();
              }
            }
            OrderStorage.updateSubmittedOrderTracking(orderId, waybillCode).then(ok => {
              if (ok && (!sub.name || !sub.phone)) {
                OrderStorage.updateSubmittedOrderData(orderId, { name: rowName, phone: rowPhone }).catch(() => {});
              }
              if (ok) showVnpostToast('📦 Đã tự động cập nhật mã vận đơn VNPost: ' + waybillCode, 'success');
            });
            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
              try {
                chrome.runtime.sendMessage({ action: 'vnpostWaybillFound', waybillCode, orderId });
              } catch (_) {}
            }
          }
        });
      });
    };

    setInterval(scanVnpostOrderManagerPage, 2500);
    onDOMReady(scanVnpostOrderManagerPage);
  }

  // ─── TÁCH HÀM SCRAPE DOM RA PHẠM VI TOÀN CỤC ĐỂ TÁI SỬ DỤNG ───
  function scrapeOrderFromDOM(plat) {
    let name = '', phone = '', address = '', orderCode = '', codAmount = 0, hasValidCodField = false, collectFee = false, carrierAccount = '', productItem = '', extraNote = '', weight = 0;
    try {
      carrierAccount = detectCarrierAccount(plat);
      if (plat === 'vnpost') {
        const sel = globalThis.VNPOST_SELECTORS || {};

        // 1. Số điện thoại người nhận
        const phoneEl = document.querySelector('#form-create-order_receiverPhone') ||
                        document.querySelector('input#receiverPhone') ||
                        document.querySelector('input[placeholder*="SĐT" i]') ||
                        document.querySelector('input[placeholder*="Số điện thoại" i]') ||
                        document.querySelector('input[type="tel"]') ||
                        (globalThis.findFieldInput ? globalThis.findFieldInput(sel.phoneLabels, sel.phoneFallbacks) : null);
        if (phoneEl && phoneEl.value) phone = phoneEl.value.trim();

        // 2. Tên người nhận
        const nameEl = document.querySelector('#form-create-order_receiverName') ||
                       document.querySelector('input#receiverName') ||
                       document.querySelector('input[placeholder*="Tên" i]') ||
                       document.querySelector('input[placeholder*="Họ và tên" i]') ||
                       (globalThis.findFieldInput ? globalThis.findFieldInput(sel.nameLabels, sel.nameFallbacks) : null);
        if (nameEl && nameEl.value) name = nameEl.value.trim();

        // 3. Địa chỉ người nhận (quét input, textarea và các dropdown chọn Tỉnh/Quận/Phường trên VNPost)
        let addrEl = document.querySelector('#form-create-order_receiverAddress') ||
                     document.querySelector('input#form-create-order_receiverAddress') ||
                     document.querySelector('input#receiverAddress') ||
                     document.querySelector('textarea#receiverAddress') ||
                     document.querySelector('input[placeholder="Địa chỉ chi tiết"]') ||
                     document.querySelector('input[placeholder*="Địa chỉ chi tiết" i]') ||
                     document.querySelector('textarea[placeholder*="Địa chỉ chi tiết" i]');

        if (!addrEl) {
          const addrCandidates = Array.from(document.querySelectorAll('textarea, input')).filter(el => {
            if (el.type === 'hidden' || el.type === 'radio' || el.type === 'checkbox' || el.disabled) return false;
            const ph = (el.placeholder || '').toLowerCase();
            const nm = (el.name || '').toLowerCase();
            const id = (el.id || '').toLowerCase();
            const lbl = (el.closest('.ant-form-item')?.querySelector('label')?.innerText || '').toLowerCase();
            return (
              id.includes('receiveraddress') || nm.includes('receiveraddress') ||
              ph.includes('địa chỉ chi tiết') || ph.includes('số nhà') || ph.includes('địa chỉ') ||
              lbl.includes('địa chỉ chi tiết') || lbl.includes('địa chỉ mới') || lbl.includes('địa chỉ cũ') || lbl.includes('địa chỉ')
            );
          });

          if (addrCandidates.length > 0) {
            addrEl = addrCandidates.find(el => {
              const container = (el.closest('.ant-card, .ant-form, div')?.innerText || '').toLowerCase();
              return !container.includes('người gửi') || container.includes('người nhận');
            }) || addrCandidates[0];
          }
        }

        if (!addrEl && globalThis.findFieldInput) {
          addrEl = globalThis.findFieldInput(sel.addressLabels, sel.addressFallbacks, true);
        }

        if (addrEl && addrEl.value && addrEl.value.trim()) {
          address = addrEl.value.trim();
        }

        // Lấy thêm các cấp hành chính đã chọn từ dropdowns nếu có (TP, Quận/Huyện, Phường/Xã)
        try {
          const selectItems = Array.from(document.querySelectorAll('.ant-select-selection-item, .ant-select-selection-selected-value, .ant-cascader-picker-label'));
          const selectedParts = selectItems
            .map(el => (el.innerText || el.textContent || '').trim())
            .filter(t => t && !/chọn|tất cả|đơn hàng mẫu|loại hàng/i.test(t) && (t.includes('TP.') || t.includes('Tỉnh') || t.includes('Quận') || t.includes('Huyện') || t.includes('Phường') || t.includes('Xã') || t.includes('Thị trấn') || t.startsWith('P.') || t.startsWith('Q.') || t.startsWith('H.')));
          
          if (selectedParts.length > 0) {
            selectedParts.forEach(part => {
              if (address && !address.toLowerCase().includes(part.toLowerCase())) {
                address += ', ' + part;
              } else if (!address) {
                address = part;
              }
            });
          }
        } catch (_) {}

        // 4. Mã đơn hàng của Shop (Trực tiếp từ ô nhập trên VNPost)
        let orderCodeEl = document.querySelector('#form-create-order_customerOrderCode') ||
                          document.querySelector('#form-create-order_orderCode') ||
                          document.querySelector('input#customerOrderCode') ||
                          document.querySelector('input#orderCode');
        if (!orderCodeEl) {
          const candidates = document.querySelectorAll('input[placeholder*="mã đơn" i], input[placeholder*="Mã đơn" i], input[placeholder*="Mã khách hàng" i]');
          for (const cand of candidates) {
            if (!cand.closest('header, .header, .topbar, .ant-layout-header, .search-box, .search-container, [class*="search" i]')) {
              orderCodeEl = cand;
              break;
            }
          }
        }
        if (orderCodeEl && orderCodeEl.value && orderCodeEl.value.trim()) {
          orderCode = orderCodeEl.value.trim();
        }

        // 5. Tên hàng hóa / Nội dung hàng hóa
        const goodsEl = document.querySelector('#form-create-order_goodsName') ||
                        document.querySelector('#form-create-order_itemName') ||
                        document.querySelector('#form-create-order_productName') ||
                        document.querySelector('input[placeholder*="tên hàng" i]') ||
                        document.querySelector('input[placeholder*="Tên hàng" i]') ||
                        document.querySelector('input[placeholder*="nội dung hàng" i]') ||
                        document.querySelector('input[placeholder*="Nội dung hàng" i]') ||
                        document.querySelector('textarea[placeholder*="nội dung hàng" i]');
        if (goodsEl && goodsEl.value && goodsEl.value.trim()) {
          productItem = goodsEl.value.trim();
          // Nếu chưa có orderCode mà ô nội dung/hàng hóa có mã (vd: E80.290 hoặc Mã: ...)
          if (!orderCode) {
            const match = productItem.match(/(?:mã|đơn|đh|dh)[:\s\-]*([A-Za-z0-9.\-_]{2,25})/i) ||
                          productItem.match(/\b([A-Za-z][0-9]{1,4}[\.-][0-9]{1,6}|DH[-_]?[0-9]{3,10}|[A-Za-z]{1,5}[-_]?[0-9]{2,10})\b/i);
            if (match && match[1]) orderCode = match[1].trim();
          }
        }

        // 6. Ghi chú chuyển phát
        const noteEl = document.querySelector('#form-create-order_receiverNote') ||
                       document.querySelector('#form-create-order_note') ||
                       document.querySelector('textarea#receiverNote') ||
                       document.querySelector('textarea[placeholder*="Ghi chú" i]') ||
                       (globalThis.findFieldInput ? globalThis.findFieldInput(sel.noteLabels, sel.noteFallbacks, true) : null);
        if (noteEl && noteEl.value && noteEl.value.trim()) {
          extraNote = noteEl.value.trim();
          if (!orderCode) {
            const match = extraNote.match(/(?:mã\s*đơn|đơn\s*hàng|mã|đh|dh)[:\s\-]*([A-Za-z0-9.\-_]{2,25})/i) ||
                          extraNote.match(/\b([A-Za-z][0-9]{1,4}[\.-][0-9]{1,6}|DH[-_]?[0-9]{3,10})\b/i);
            if (match && match[1]) orderCode = match[1].trim();
          }
        }

        // 7. Tiền thu hộ COD - Tuyệt đối không dùng selector toàn trang kiểu input.ant-input-number-input
        let codEl = document.querySelector('input[name="PROP0018"]');
        if (!codEl) {
          const codLabels = Array.from(document.querySelectorAll('label, .ant-form-item-label, span, b, div')).filter(l => {
            const t = (l.innerText || l.textContent || '').trim().toLowerCase();
            return (t.includes('phát hàng thu tiền') || t.includes('thu tiền cod') || t.includes('tiền thu hộ')) && !t.includes('hủy');
          });
          for (const lbl of codLabels) {
            const container = lbl.closest('.ant-form-item, tr, .ant-row, .form-item') || lbl.parentElement;
            if (container) {
              const inp = container.querySelector('input[name="PROP0018"], input.ant-input-number-input, input[role="spinbutton"], input:not([type="checkbox"])');
              if (inp) { codEl = inp; break; }
            }
          }
        }
        if (codEl && codEl.value !== undefined && codEl.value !== null && String(codEl.value).trim() !== '') {
          hasValidCodField = true;
          codAmount = parseInt(String(codEl.value).replace(/\D/g, ''), 10) || 0;
        }

        const shipFeeBox = document.querySelector('input#collectFee') || 
                           document.querySelector('input[name="collectFee"]') || 
                           document.querySelector('input#form-create-order_collectFee') ||
                           document.querySelector('input[type="checkbox"][name*="collect" i]') ||
                           document.querySelector('input[type="checkbox"][id*="collect" i]');
        if (shipFeeBox) collectFee = !!shipFeeBox.checked;

        // 9. Cân nặng (khối lượng)
        let weightEl = document.querySelector('#form-create-order_weight') ||
                       document.querySelector('#form-create-order_totalWeight') ||
                       document.querySelector('input#weight') ||
                       document.querySelector('input#totalWeight') ||
                       document.querySelector('input[name="weight"]') ||
                       document.querySelector('input[name="totalWeight"]') ||
                       document.querySelector('input[placeholder*="khối lượng" i]') ||
                       document.querySelector('input[placeholder*="Khối lượng" i]');
        if (!weightEl) {
          const labels = Array.from(document.querySelectorAll('label, .ant-form-item-label, span, b')).filter(l => {
            const t = (l.innerText || l.textContent || '').trim().toLowerCase();
            return (t.includes('tổng khối lượng') || t.includes('khối lượng')) && !t.includes('tính cước') && !t.includes('quy đổi');
          });
          for (const lbl of labels) {
            const container = lbl.closest('.ant-form-item, .ant-row, .form-item') || lbl.parentElement?.parentElement;
            if (container) {
              const inp = container.querySelector('input.ant-input-number-input, input[role="spinbutton"], input');
              if (inp) { weightEl = inp; break; }
            }
          }
        }
        if (weightEl && weightEl.value) {
          weight = parseInt(weightEl.value.replace(/\D/g, ''), 10) || 0;
        }

      } else if (plat === 'jt') {
        const phoneEl = document.querySelector('input[placeholder*="số điện thoại" i]');
        const nameEl = document.querySelector('input[placeholder*="tên người nhận" i]');
        let addrEl = document.querySelector('input[placeholder*="địa chỉ" i]') || 
                     document.querySelector('textarea[placeholder*="địa chỉ" i]') ||
                     document.querySelector('input[placeholder*="Số nhà/ đường/ ngõ"]') ||
                     document.querySelector('textarea[placeholder*="Số nhà/ đường/ ngõ"]');
        if (!addrEl) {
          const jtCandidates = Array.from(document.querySelectorAll('input, textarea')).filter(el => {
            if (el.type === 'hidden' || el.type === 'radio' || el.type === 'checkbox' || el.disabled) return false;
            const ph = (el.placeholder || '').toLowerCase();
            const lbl = (el.closest('.el-form-item')?.querySelector('label')?.innerText || '').toLowerCase();
            return ph.includes('địa chỉ') || ph.includes('số nhà') || lbl.includes('địa chỉ');
          });
          if (jtCandidates.length > 0) addrEl = jtCandidates[0];
        }
        
        let orderCodeEl = null;
        const jtCandidates = document.querySelectorAll('input[placeholder*="Mã đơn" i], input[placeholder*="Mã tham chiếu" i]');
        for (const cand of jtCandidates) {
          if (!cand.closest('header, .header, .topbar, .ant-layout-header, .search-box, .search-container, [class*="search" i]')) {
            orderCodeEl = cand;
            break;
          }
        }
        
        const goodsInp = document.querySelector('textarea[placeholder*="tên sản phẩm" i]') || document.querySelector('input[placeholder*="tên sản phẩm" i]');
        
        let codInp = document.querySelector('input[placeholder*="Nhập số tiền" i]') || document.querySelector('#money');
        if (!codInp) {
          document.querySelectorAll('.el-form-item').forEach(item => {
            const labelText = (item.innerText || '').trim();
            if (labelText.includes('Tiền thu hộ') && !labelText.includes('Phí')) {
              const el = item.querySelector('input');
              if (el) codInp = el;
            }
          });
        }

        if (phoneEl && phoneEl.value) phone = phoneEl.value.trim();
        if (nameEl && nameEl.value) name = nameEl.value.trim();
        if (addrEl && addrEl.value && addrEl.value.trim()) address = addrEl.value.trim();
        if (orderCodeEl && orderCodeEl.value) orderCode = orderCodeEl.value.trim();
        if (goodsInp && goodsInp.value) productItem = goodsInp.value.trim();
        if (codInp && codInp.value !== undefined && codInp.value !== null && String(codInp.value).trim() !== '') {
          hasValidCodField = true;
          codAmount = parseInt(String(codInp.value).replace(/\D/g, ''), 10) || 0;
        }

        // Lấy các cấp Tỉnh/Thành, Quận/Huyện, Phường/Xã từ cascader / select của J&T
        try {
          const cascaderEl = document.querySelector('.el-cascader__label, .el-cascader input, .el-select__selected-item');
          if (cascaderEl) {
            const cascText = (cascaderEl.value || cascaderEl.innerText || cascaderEl.textContent || '').trim();
            if (cascText && !/chọn|vui lòng/i.test(cascText)) {
              if (address && !address.toLowerCase().includes(cascText.toLowerCase())) {
                address += ', ' + cascText;
              } else if (!address) {
                address = cascText;
              }
            }
          }
        } catch (_) {}

        const weightInp = document.querySelector('input[placeholder*="trọng lượng" i]') || 
                          document.querySelector('input[placeholder*="Trọng lượng" i]') ||
                          document.querySelector('#weight');
        if (weightInp && weightInp.value) {
          weight = parseInt(weightInp.value.replace(/\D/g, ''), 10) || 0;
        }
      }
    } catch (e) {
      console.warn('Lỗi khi cào dữ liệu từ DOM:', e);
    }
    return { name, phone, address, orderCode, productItem, extraNote, codAmount, hasValidCodField, collectFee, carrierAccount, weight };
  }

  // ─── NHÚNG INTERCEPTOR VÀ LẮNG NGHE TẠO ĐƠN (GÕ TAY) ───
  function injectInterceptor() {
    try {
      if (document.getElementById('af-interceptor-script')) return;
      if (!window.location.hostname.includes('vnpost.vn') && !window.location.hostname.includes('jtexpress.vn')) return;

      const script = document.createElement('script');
      script.id = 'af-interceptor-script';
      script.src = chrome.runtime.getURL('interceptor.js');
      script.onload = () => { console.log('[Auto Fill] Interceptor injected.'); };
      (document.head || document.documentElement).appendChild(script);

      function isCarrierTrackingCode(code) {
        if (!code) return false;
        const s = String(code).trim();
        if (s.toUpperCase().startsWith('DH')) return false;
        
        // VNPost tracking code patterns
        const vnpostRegex = /^[A-Z]{2}\d{9,13}VN$/i;
        const vnpostRegex2 = /^C\d{9,13}VN$/i;
        const vnpostRegex3 = /^MP\d{8,12}VN$/i;
        
        // J&T tracking code patterns
        const jtRegex = /^8\d{11,14}$/i;
        
        return vnpostRegex.test(s) || vnpostRegex2.test(s) || vnpostRegex3.test(s) || jtRegex.test(s);
      }

      window.addEventListener('message', (event) => {
        if (event.source !== window || !event.data || event.data.type !== 'AF_ORDER_CREATED') return;
        
        console.log('[Auto Fill] Nhận sự kiện tạo đơn gõ tay!', event.data);
        const trackingCode = event.data.trackingCode;
        if (!trackingCode || !isCarrierTrackingCode(trackingCode)) {
          console.log('[Auto Fill] Bỏ qua bắt đơn từ form do không có mã vận đơn hợp lệ:', trackingCode);
          return;
        }

        const platform = getCurrentPlatform();
        if (!platform) return;

        // Cào thông tin đơn từ form trang
        const data = scrapeOrderFromDOM(platform);
        const parsed = globalThis.parsedDataStore;
        
        if (parsed) {
          if (!data.name) data.name = parsed.name || '';
          if (!data.phone) data.phone = parsed.phone || '';
          if (!data.address || data.address === 'không tìm thấy') data.address = (parsed.address && parsed.address !== 'không tìm thấy') ? parsed.address : '';
          if (!data.orderCode) data.orderCode = parsed.orderCode || '';
          if (!data.codAmount) data.codAmount = parsed.codAmount || 0;
          if (!data.collectFee) data.collectFee = parsed.collectFee || false;
          data.extraNote = data.extraNote || parsed.extraNote || '';
          if (parsed.id) data.id = parsed.id;
        }

        const { name, phone, address, orderCode } = data;
        const cleanName = (name || '').trim();
        const cleanPhone = (phone || '').replace(/\D/g, '');
        const hasValidCustomer = (cleanName && cleanName !== '—' && cleanName.length >= 2) || (cleanPhone && cleanPhone.length >= 9);

        // Kiểm tra xem đơn này vừa được xử lý gần đây chưa (tránh trùng lặp với autofill onSuccess)
        if (isSubmissionRecentlyHandled(trackingCode, orderCode, cleanPhone, cleanName)) {
          console.log('[Auto Fill] Đơn đã được ghi nhận trước đó, chỉ cập nhật mã vận đơn nếu cần:', trackingCode);
          if (trackingCode) {
            OrderStorage.updateLatestSubmittedOrderTracking(trackingCode).catch(() => {});
          }
          return;
        }

        // Nếu không có thông tin khách hàng hợp lệ mà có mã vận đơn -> chỉ cập nhật đơn gần nhất
        if (!hasValidCustomer) {
          if (trackingCode) {
            OrderStorage.updateLatestSubmittedOrderTracking(trackingCode).then(ok => {
              if (ok) showVnpostToast('📦 Đã cập nhật mã vận đơn: ' + trackingCode, 'success');
            });
          }
          return;
        }

        // Kiểm tra phiên đăng nhập / kích hoạt Shop Key
        chrome.storage.local.get(['vnpost_session', 'staff_name', 'shop_access_key', 'device_id', 'pending_offline_orders'], (storageRes) => {
          const session = storageRes?.vnpost_session;
          const staffName = storageRes?.staff_name || session?.staff_name || session?.user?.full_name || 'Nhân viên kho';
          const deviceId = storageRes?.device_id || session?.device_id || '';

          const cleanPanelPhone = String(globalThis.parsedDataStore?.phone || globalThis.__AF_LAST_FILLED_ORDER__?.phone || '').replace(/\D/g, '');
          const cleanPanelOrderCode = String(globalThis.parsedDataStore?.orderCode || globalThis.__AF_LAST_FILLED_ORDER__?.orderCode || '').trim().toLowerCase();

          const isAutoFilled = Boolean(
            globalThis.__AF_JUST_FILLED__ ||
            (cleanPhone && cleanPanelPhone && cleanPhone.length >= 9 && cleanPhone === cleanPanelPhone) ||
            (orderCode && cleanPanelOrderCode && orderCode !== '—' && orderCode.toLowerCase() === cleanPanelOrderCode)
          );
          const orderSource = isAutoFilled ? 'AUTO_FILL' : 'MANUAL_ENTRY';

          const orderToSave = {
            name: cleanName || '',
            phone: cleanPhone || '',
            address: address && address !== 'không tìm thấy' ? address : '',
            orderCode: orderCode || '',
            codAmount: data.codAmount || 0,
            collectFee: data.collectFee || false,
            platform: platform || '',
            carrierAccount: data.carrierAccount || detectCarrierAccount(platform) || '',
            extraNote: data.extraNote || '',
            weight: data.weight || 0,
            source: orderSource,
            created_by_name: staffName,
            source_device_id: deviceId
          };

          if (data.id) orderToSave.id = data.id;

          // Lưu đơn hàng trước
          OrderStorage.saveOrder(orderToSave).then(saved => {
            const finalAddress = (data.address && data.address !== 'không tìm thấy') 
              ? data.address 
              : ((saved.address && saved.address !== 'không tìm thấy') ? saved.address : ((orderToSave.address && orderToSave.address !== 'không tìm thấy') ? orderToSave.address : ''));

            const submittedOrder = {
              name: data.name || saved.name || orderToSave.name || '',
              phone: data.phone || saved.phone || orderToSave.phone || '',
              address: finalAddress,
              orderCode: data.orderCode || saved.orderCode || orderToSave.orderCode || '',
              codAmount: data.codAmount !== undefined && data.codAmount > 0 ? data.codAmount : (saved.codAmount || orderToSave.codAmount || 0),
              collectFee: data.collectFee || saved.collectFee || orderToSave.collectFee || false,
              platform: platform || '',
              carrierAccount: data.carrierAccount || saved.carrierAccount || orderToSave.carrierAccount || detectCarrierAccount(platform) || '',
              extraNote: data.extraNote || saved.extraNote || orderToSave.extraNote || '',
              productNote: data.productItem || '',
              weight: data.weight || 0,
              trackingCode: trackingCode || '',
              savedOrderId: saved.id,
              source: orderSource,
              created_by_name: staffName,
              source_device_id: deviceId
            };

            OrderStorage.saveSubmittedOrder(submittedOrder).then(() => {
              const sourceText = isAutoFilled ? '⚡ Tách đơn AI' : '✍️ Gõ tay thủ công';
              if (trackingCode) {
                showVnpostToast(`📦 Đã bắt đơn (${sourceText})! Mã vận đơn: ${trackingCode}`, 'success');
              } else {
                showVnpostToast(`✅ Đã ghi nhận đơn (${sourceText})! Đang chờ mã vận đơn...`, 'success');
                if (platform === 'vnpost') {
                  startTrackingCodeMonitor(saved.id, platform);
                }
              }
              window.dispatchEvent(new CustomEvent('order-saved-db'));
              globalThis.__AF_JUST_FILLED__ = false;
            }).catch(e => console.error('Lỗi khi lưu tự động:', e));
          }).catch(e => console.error('Lỗi khi lưu đơn nháp:', e));
        });

      });
    } catch (e) {
      console.warn('Lỗi inject interceptor:', e);
    }
  }

  // Tự động đẩy hàng đợi ngoại tuyến lên Cloud khi phát hiện Shop Key / Session
  function drainOfflineQueue() {
    try {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return;
      chrome.storage.local.get(['pending_offline_orders', 'vnpost_session', 'shop_access_key'], (res) => {
        const queue = res?.pending_offline_orders || [];
        const session = res?.vnpost_session;
        const shopKey = res?.shop_access_key || session?.shop_access_key;
        const shopId = session?.active_shop_id;

        if (queue.length > 0 && (shopId || shopKey)) {
          console.log(`[Auto Fill] Bắt đầu đồng bộ ${queue.length} đơn hàng từ Offline Queue...`);
          if (typeof OrderStorage !== 'undefined' && typeof OrderStorage.pushSubmittedOrderToCloud === 'function') {
            Promise.all(queue.map(order => OrderStorage.pushSubmittedOrderToCloud({ ...order, shopId: shopId || order.shopId })))
              .then(() => {
                chrome.storage.local.remove(['pending_offline_orders'], () => {
                  showVnpostToast(`🎉 Đã đồng bộ bù ${queue.length} đơn hàng ngoại tuyến lên Shop thành công!`, 'success');
                });
              })
              .catch(err => console.warn('[OfflineDrain] Lỗi đồng bộ bù:', err));
          }
        }
      });
    } catch (e) {}
  }

  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, namespace) => {
      if (namespace === 'local' && (changes['vnpost_session'] || changes['shop_access_key'])) {
        drainOfflineQueue();
      }
    });
  }

  onDOMReady(() => {
    injectInterceptor();
    drainOfflineQueue();
  });

})();
