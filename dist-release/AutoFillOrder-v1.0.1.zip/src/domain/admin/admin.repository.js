import { AuthSession } from '../auth/auth.session.esm.js';

/**
 * Admin Repository - Lớp tương tác trực tiếp với Supabase Database qua REST API
 * (Data Layer - Không chứa Business Logic)
 */
export class AdminRepository {
  /**
   * Lấy cấu hình Supabase Cloud an toàn
   */
  static async _getConfig() {
    if (!globalThis.SupabaseCloud) throw new Error('SupabaseCloud context not found');
    return await globalThis.SupabaseCloud.loadConfig();
  }

  /**
   * Sinh Headers chuẩn 3-part JWT cho Admin
   */
  static async _getAuthHeaders(configRes) {
    const sess = await AuthSession.getSession().catch(() => null);
    const anonKey = (configRes?.anonKey || '').trim();
    const headers = { 'Content-Type': 'application/json' };
    
    if (anonKey) {
      headers['apikey'] = anonKey;
    }
  
    const userToken = sess?.access_token;
    if (typeof userToken === 'string' && userToken.split('.').length === 3) {
      headers['Authorization'] = `Bearer ${userToken}`;
    } else if (typeof anonKey === 'string' && anonKey.split('.').length === 3) {
      headers['Authorization'] = `Bearer ${anonKey}`;
    }
  
    return headers;
  }

  static async _getAdminId() {
    const sess = await AuthSession.getSession().catch(() => null);
    return sess?.user?.id;
  }

  static async _rpc(name, payload = {}) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);
    const res = await fetch(`${configRes.url}/rest/v1/rpc/${name}`, {
      method: 'POST', headers, body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error(`RPC ${name} Failed: ${res.status} - ${await res.text()}`);
    const text = await res.text();
    return text ? JSON.parse(text) : true;
  }

  static async createShopWithAccount({ shopName, ownerEmail, ownerName, password, maxDevices = 1, dailyAiLimit = 500 }) {
    try {
      return await this._rpc('admin_create_shop_with_account', {
        p_shop_name: shopName,
        p_owner_email: ownerEmail,
        p_owner_full_name: ownerName,
        p_owner_password: password,
        p_max_devices: maxDevices,
        p_daily_ai_limit: dailyAiLimit
      });
    } catch (rpcErr) {
      const configRes = await this._getConfig();
      const headers = await this._getAuthHeaders(configRes);

      const user = await this.findUserByEmailOrId(ownerEmail);
      if (user && user.id) {
        const shopRes = await fetch(`${configRes.url}/rest/v1/shops`, {
          method: 'POST',
          headers: { ...headers, 'Prefer': 'return=representation' },
          body: JSON.stringify({ name: shopName, owner_id: user.id, status: 'active' })
        });
        if (shopRes.ok) {
          const created = await shopRes.json().catch(() => []);
          const shopId = created[0]?.id;
          if (shopId) {
            let ownerRoleId = null;
            try {
              const rolesRes = await fetch(`${configRes.url}/rest/v1/roles?code=eq.SHOP_OWNER&select=id`, { headers });
              if (rolesRes.ok) {
                const rolesList = await rolesRes.json();
                ownerRoleId = rolesList[0]?.id;
              }
              if (!ownerRoleId) {
                const fallbackRolesRes = await fetch(`${configRes.url}/rest/v1/roles?code=eq.OWNER&select=id`, { headers });
                if (fallbackRolesRes.ok) {
                  const fallbackList = await fallbackRolesRes.json();
                  ownerRoleId = fallbackList[0]?.id;
                }
              }
            } catch (_) {}

            const memberPayload = { shop_id: shopId, user_id: user.id, role: 'OWNER', status: 'active' };
            if (ownerRoleId) memberPayload.role_id = ownerRoleId;
            await fetch(`${configRes.url}/rest/v1/shop_members`, {
              method: 'POST',
              headers,
              body: JSON.stringify(memberPayload)
            }).catch(() => {});

            await fetch(`${configRes.url}/rest/v1/shop_quotas`, {
              method: 'POST',
              headers,
              body: JSON.stringify({ shop_id: shopId, max_devices: maxDevices, daily_ai_limit: dailyAiLimit })
            }).catch(() => {});

            await fetch(`${configRes.url}/rest/v1/shop_feature_flags`, {
              method: 'POST',
              headers,
              body: JSON.stringify({ shop_id: shopId })
            }).catch(() => {});

            return { success: true, shop_id: shopId, user_id: user.id };
          }
        }
      }
      throw rpcErr;
    }
  }

  static topupQuota(shopId, amount) { return this._rpc('admin_topup_shop_quota', { p_shop_id: shopId, p_amount: amount }); }
  static getQuotaOverview() { return this._rpc('admin_get_ai_quota_overview'); }
  static async transferShopOwnership(shopId, newOwnerId) {
    try {
      return await this._rpc('admin_transfer_shop_ownership', { p_shop_id: shopId, p_new_owner_id: newOwnerId });
    } catch (rpcErr) {
      const configRes = await this._getConfig();
      const headers = await this._getAuthHeaders(configRes);
      const res = await fetch(`${configRes.url}/rest/v1/shops?id=eq.${encodeURIComponent(shopId)}`, {
        method: 'PATCH',
        headers: headers,
        body: JSON.stringify({ owner_id: newOwnerId, updated_at: new Date().toISOString() })
      });
      if (!res.ok) {
        throw new Error(`Chuyển chủ sở hữu thất bại: ${res.status} - ${await res.text()}`);
      }
      return true;
    }
  }

  static async findUserByEmailOrId(query) {
    if (!query) return null;
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);
    const trimmed = String(query).trim();

    if (trimmed.includes('@')) {
      const res = await fetch(`${configRes.url}/rest/v1/profiles?email=ilike.${encodeURIComponent(trimmed)}&select=*&limit=1`, {
        method: 'GET',
        headers: headers
      });
      if (res.ok) {
        const list = await res.json().catch(() => []);
        if (list && list.length > 0) return list[0];
      }
    }

    const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(trimmed);
    if (isUUID) {
      const idRes = await fetch(`${configRes.url}/rest/v1/profiles?id=eq.${encodeURIComponent(trimmed)}&select=*&limit=1`, {
        method: 'GET',
        headers: headers
      });
      if (idRes.ok) {
        const list = await idRes.json().catch(() => []);
        if (list && list.length > 0) return list[0];
      }
    }

    const nameRes = await fetch(`${configRes.url}/rest/v1/profiles?full_name=ilike.*${encodeURIComponent(trimmed)}*&select=*&limit=1`, {
      method: 'GET',
      headers: headers
    });
    if (nameRes.ok) {
      const list = await nameRes.json().catch(() => []);
      if (list && list.length > 0) return list[0];
    }

    return null;
  }
  static createAdminAccount(data) { return this._rpc('admin_create_admin_account', { p_email: data.email, p_full_name: data.fullName, p_password: data.password, p_role_code: data.role }); }
  static startImpersonation(shopId, reason) { return this._rpc('admin_start_impersonation', { p_shop_id: shopId, p_reason: reason }); }
  static async setUserRole(userId, role) {
    const normalizedRole = String(role || '').toUpperCase().trim();
    try {
      return await this._rpc('admin_set_user_role', { p_user_id: userId, p_role_code: normalizedRole });
    } catch (rpcErr) {
      const configRes = await this._getConfig();
      const headers = await this._getAuthHeaders(configRes);
      if (['USER', 'NONE', 'MEMBER', 'EXTENSION_USER', 'SHOP_STAFF', 'VIEWER'].includes(normalizedRole)) {
        const delRes = await fetch(`${configRes.url}/rest/v1/user_roles?user_id=eq.${encodeURIComponent(userId)}`, {
          method: 'DELETE',
          headers: headers
        });
        if (delRes.ok) {
          return { success: true, message: 'Đã chuyển thành tài khoản người dùng tiêu chuẩn.' };
        }
      }
      throw rpcErr;
    }
  }
  static overrideSubscription(shopId, plan, months) { return this._rpc('admin_override_subscription', { p_shop_id: shopId, p_plan_code: plan, p_extend_months: months }); }
  static revokeShopDevices(shopId) { return this._rpc('admin_revoke_shop_devices', { p_shop_id: shopId }); }
  static replySupportTicket(ticketId, reply, internalNote) { return this._rpc('admin_reply_support_ticket', { p_ticket_id: ticketId, p_reply: reply, p_internal_note: internalNote || null }); }
  static publishRelease(data) { return this._rpc('admin_publish_release', { p_version: data.version, p_min_supported_version: data.minVersion, p_force_update: data.forceUpdate, p_rollout_percentage: data.rolloutPercentage, p_release_notes: data.notes, p_download_url: data.downloadUrl || null }); }
  static recordCarrierProbe(carrierCode, status, responseTimeMs, errorMessage = null) { return this._rpc('admin_record_carrier_probe', { p_carrier_code: carrierCode, p_status: status, p_response_time_ms: responseTimeMs, p_error_message: errorMessage }); }
  static getUnitEconomics() { return this._rpc('admin_get_unit_economics'); }
  static publishRemoteSelectors(data) { return this._rpc('admin_publish_remote_selectors', { p_carrier_code: data.carrierCode, p_selectors: data.selectors, p_min_extension_version: data.minVersion || null, p_release_note: data.note || null }); }
  static getGrowthMetrics() { return this._rpc('admin_get_growth_metrics'); }
  static async resetUserPassword(userId, newPassword) {
    try {
      return await this._rpc('admin_reset_user_password', { p_target_user_id: userId, p_new_password: newPassword });
    } catch (rpcErr) {
      const configRes = await this._getConfig();
      const headers = await this._getAuthHeaders(configRes);
      const res = await fetch(`${configRes.url}/auth/v1/admin/users/${encodeURIComponent(userId)}`, {
        method: 'PUT',
        headers: headers,
        body: JSON.stringify({ password: newPassword })
      });
      if (res.ok) {
        return { success: true, message: 'Đã cập nhật mật khẩu thành công.' };
      }
      throw rpcErr;
    }
  }
  static async assignUserShop(userId, shopId, roleCode = 'STAFF') {
    try {
      return await this._rpc('admin_assign_user_shop', { p_user_id: userId, p_shop_id: shopId, p_role_code: roleCode });
    } catch (rpcErr) {
      try {
        return await this._rpc('admin_add_shop_member', { p_shop_id: shopId, p_user_id: userId, p_role: roleCode });
      } catch (_) {}

      const configRes = await this._getConfig();
      const headers = await this._getAuthHeaders(configRes);
      
      let roleId = null;
      try {
        const rolesRes = await fetch(`${configRes.url}/rest/v1/roles?code=eq.${encodeURIComponent(roleCode)}&select=id`, { headers });
        if (rolesRes.ok) {
          const roles = await rolesRes.json();
          roleId = roles[0]?.id;
        }
      } catch (_) {}

      const payload = {
        shop_id: shopId,
        user_id: userId,
        role: roleCode,
        status: 'active',
        removed_at: null
      };
      if (roleId) payload.role_id = roleId;

      const res = await fetch(`${configRes.url}/rest/v1/shop_members`, {
        method: 'POST',
        headers: { ...headers, 'Prefer': 'resolution=merge-duplicates' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) {
        throw new Error(`Thêm nhân viên thất bại: ${res.status} - ${await res.text()}`);
      }
      return { success: true };
    }
  }

  static async createAndAddShopMember(shopId, { email, fullName, password, roleCode = 'STAFF' }) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);
    const cleanEmail = String(email).trim().toLowerCase();

    // 1. Kiểm tra xem user đã tồn tại chưa
    let user = await this.findUserByEmailOrId(cleanEmail);

    if (!user || !user.id) {
      // 2. Tạo user mới trong auth.users / profiles
      const pass = password || Math.random().toString(36).slice(-8);
      const signupRes = await fetch(`${configRes.url}/auth/v1/admin/users`, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify({
          email: cleanEmail,
          password: pass,
          email_confirm: true,
          user_metadata: { full_name: fullName }
        })
      });

      if (signupRes.ok) {
        const signupData = await signupRes.json();
        user = { id: signupData.id || signupData.user?.id, email: cleanEmail, full_name: fullName };
      } else {
        const newId = (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : `usr_${Date.now()}`;
        await fetch(`${configRes.url}/rest/v1/profiles`, {
          method: 'POST',
          headers: headers,
          body: JSON.stringify({ id: newId, email: cleanEmail, full_name: fullName, status: 'active' })
        }).catch(() => {});
        user = { id: newId, email: cleanEmail, full_name: fullName };
      }
    }

    // 3. Gán vào shop
    return await this.assignUserShop(user.id, shopId, roleCode);
  }

  static async getShopMembers(shopId) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);
    let members = [];
    try {
      const res = await fetch(`${configRes.url}/rest/v1/shop_members?shop_id=eq.${encodeURIComponent(shopId)}&removed_at=is.null&select=*,profiles:user_id(id,email,full_name,avatar_url),roles:role_id(code,name)`, {
        method: 'GET',
        headers: headers
      });
      if (res.ok) {
        members = await res.json();
      }
    } catch (_) {}

    if (!members || members.length === 0) {
      try {
        const resSimple = await fetch(`${configRes.url}/rest/v1/shop_members?shop_id=eq.${encodeURIComponent(shopId)}&removed_at=is.null&select=*`, {
          method: 'GET',
          headers: headers
        });
        if (resSimple.ok) {
          members = await resSimple.json();
        }
      } catch (_) {}
    }

    if (Array.isArray(members) && members.length > 0) {
      const missingUserIds = members.filter(m => !m.profiles?.email).map(m => m.user_id).filter(Boolean);
      if (missingUserIds.length > 0) {
        try {
          const profRes = await fetch(`${configRes.url}/rest/v1/profiles?id=in.(${missingUserIds.map(id => `"${id}"`).join(',')})&select=*`, {
            method: 'GET',
            headers: headers
          });
          if (profRes.ok) {
            const profs = await profRes.json();
            const profMap = new Map((profs || []).map(p => [p.id, p]));
            members = members.map(m => {
              const p = profMap.get(m.user_id);
              if (p) {
                return {
                  ...m,
                  profiles: { ...(m.profiles || {}), ...p },
                  email: p.email || m.email,
                  full_name: p.full_name || m.full_name
                };
              }
              return m;
            });
          }
        } catch (_) {}
      }
    }

    return members || [];
  }

  static async removeShopMember(shopId, userId) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);
    const res = await fetch(`${configRes.url}/rest/v1/shop_members?shop_id=eq.${encodeURIComponent(shopId)}&user_id=eq.${encodeURIComponent(userId)}`, {
      method: 'PATCH',
      headers: headers,
      body: JSON.stringify({ removed_at: new Date().toISOString(), status: 'inactive' })
    });
    return res.ok;
  }

  static async forceLogoutUser(userId) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);
    const res = await fetch(`${configRes.url}/rest/v1/user_devices?user_id=eq.${encodeURIComponent(userId)}`, {
      method: 'PATCH',
      headers: headers,
      body: JSON.stringify({ revoked: true, revoked_at: new Date().toISOString() })
    });
    return res.ok;
  }

  static async restoreShop(shopId) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);
    const res = await fetch(`${configRes.url}/rest/v1/shops?id=eq.${encodeURIComponent(shopId)}`, {
      method: 'PATCH',
      headers: headers,
      body: JSON.stringify({ status: 'active', updated_at: new Date().toISOString() })
    });
    if (!res.ok) {
      throw new Error(`Khôi phục cửa hàng thất bại: ${res.status} - ${await res.text()}`);
    }
    return true;
  }
  static createReseller(name, code, commissionRate) { return this._rpc('admin_create_reseller', { p_name: name, p_code: code, p_commission_rate: commissionRate }); }

  /**
   * Ghi log Audit Admin qua RPC SECURITY DEFINER insert_audit_log
   * (audit_logs bị RLS chặn INSERT qua REST — probe 42501; bảng
   * admin_audit_logs cũ KHÔNG tồn tại trong DB)
   */
  static async insertAuditLog(action, targetId, targetType, beforeState, afterState, result = 'SUCCESS') {
    try {
      const configRes = await this._getConfig();
      const headers = await this._getAuthHeaders(configRes);
      const adminId = await this._getAdminId();

      if (!adminId) return; // Bỏ qua nếu không lấy được Admin ID

      const payload = {
        p_action: action,
        p_entity_type: targetType,
        p_entity_id: targetId != null ? String(targetId) : null,
        p_details: {
          before_state: beforeState ?? null,
          after_state: afterState ?? null,
          result: result,
        },
      };

      const res = await fetch(`${configRes.url}/rest/v1/rpc/insert_audit_log`, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(payload)
      });
      
      if (!res.ok) console.warn("Lỗi ghi Admin Audit Log:", await res.text());
    } catch (e) {
      console.warn("Lỗi ghi Admin Audit Log:", e);
    }
  }

  /**
   * Gọi RPC get_admin_kpis
   */
  static async getKpis() {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/rpc/get_admin_kpis`, {
      method: 'POST',
      headers: headers
    });

    if (!res.ok) {
      throw new Error(`RPC get_admin_kpis Failed: ${res.status} - ${await res.text()}`);
    }

    return await res.json();
  }

  /**
   * Gọi RPC get_system_health — số liệu thật cho System Health page
   */
  static async getSystemHealth() {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/rpc/get_system_health`, {
      method: 'POST',
      headers: headers
    });

    if (!res.ok) {
      throw new Error(`RPC get_system_health Failed: ${res.status} - ${await res.text()}`);
    }

    return await res.json();
  }

  /**
   * Quick Action: Thử lại toàn bộ các bản ghi đồng bộ bị lỗi
   */
  static async retryFailedSyncs() {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/rpc/admin_retry_failed_syncs`, {
      method: 'POST',
      headers: headers
    });

    if (!res.ok) {
      throw new Error(`RPC admin_retry_failed_syncs Failed: ${res.status}`);
    }

    return await res.json();
  }

  /**
   * Quick Action: Gửi tín hiệu kiểm tra trạng thái bưu cục (VNPost / J&T)
   */
  static async pingCarrier(carrierCode) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/rpc/admin_ping_carrier_health`, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify({ p_carrier_code: carrierCode })
    });

    if (!res.ok) {
      throw new Error(`RPC admin_ping_carrier_health Failed: ${res.status}`);
    }

    return await res.json();
  }

  /**
   * Quick Action: Xóa cache và nạp lại Database Schema
   */
  static async flushSystemCache() {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/rpc/admin_flush_system_cache`, {
      method: 'POST',
      headers: headers
    });

    if (!res.ok) {
      throw new Error(`RPC admin_flush_system_cache Failed: ${res.status}`);
    }

    return await res.json();
  }

  /**
   * Lấy danh sách Shops (Tenant)
   */
  static async getShops() {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/shops?select=*&order=created_at.desc`, {
      method: 'GET',
      headers: headers
    });

    if (!res.ok) throw new Error(`Fetch Shops Failed: ${res.status}`);
    return await res.json();
  }

  /**
   * Lấy danh sách người dùng
   */
  static async getUsers() {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/profiles?select=*&order=created_at.desc`, {
      method: 'GET',
      headers: headers
    });

    if (!res.ok) throw new Error(`Fetch Users Failed: ${res.status}`);
    return await res.json();
  }

  /**
   * Lấy danh sách Shops dạng tổng hợp cho Admin Dashboard (Phase 2)
   */
  static async getShopsList() {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/rpc/get_admin_shops_list`, {
      method: 'POST',
      headers: headers
    });

    if (!res.ok) {
      throw new Error(`RPC get_admin_shops_list Failed: ${res.status} - ${await res.text()}`);
    }

    return await res.json();
  }

  /**
   * Cập nhật trạng thái Shop
   */
  static async updateShopStatus(shopId, status) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/shops?id=eq.${shopId}`, {
      method: 'PATCH',
      headers: headers,
      body: JSON.stringify({ status: status, updated_at: new Date().toISOString() })
    });

    if (!res.ok) throw new Error(`Update Shop Status Failed: ${res.status}`);
    return true;
  }

  /**
   * Xóa Shop khỏi hệ thống
   */
  static async deleteShop(shopId) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/shops?id=eq.${encodeURIComponent(shopId)}`, {
      method: 'DELETE',
      headers: headers
    });

    if (!res.ok) {
      throw new Error(`Xóa Shop thất bại: ${res.status}`);
    }
    return true;
  }

  /**
   * Xóa nhiều Shop khỏi hệ thống
   */
  static async deleteMultipleShops(shopIds = []) {
    if (!Array.isArray(shopIds) || shopIds.length === 0) return true;
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const inFilter = `in.(${shopIds.map(id => encodeURIComponent(id)).join(',')})`;
    const res = await fetch(`${configRes.url}/rest/v1/shops?id=${inFilter}`, {
      method: 'DELETE',
      headers: headers
    });

    if (!res.ok) {
      let deleted = 0;
      for (const id of shopIds) {
        try {
          await this.deleteShop(id);
          deleted++;
        } catch (_) {}
      }
      return deleted > 0;
    }
    return true;
  }

  // ==========================================
  // SHOP FEATURE FLAGS MANAGEMENT
  // ==========================================

  static async getShopFeatureFlags(shopId) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/shop_feature_flags?shop_id=eq.${shopId}&select=*`, {
      method: 'GET',
      headers: headers
    });

    if (!res.ok) throw new Error(`Fetch Shop Feature Flags Failed: ${res.status}`);
    const data = await res.json();
    return data && data.length > 0 ? data[0] : null;
  }

  static async updateShopFeatureFlags(shopId, updates) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/shop_feature_flags?shop_id=eq.${shopId}`, {
      method: 'PATCH',
      headers: headers,
      body: JSON.stringify({ ...updates, updated_at: new Date().toISOString() })
    });

    if (!res.ok) throw new Error(`Update Shop Feature Flags Failed: ${res.status}`);
    return true;
  }

  // ==========================================
  // USERS MANAGEMENT
  // ==========================================

  /**
   * Lấy danh sách người dùng cho Admin Dashboard (Phase 3)
   */
  static async getUsersList({ searchText, status, role, limit = 20, offset = 0 } = {}) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const body = {
      p_search_text: searchText || null,
      p_status: status || null,
      p_role: role || null,
      p_limit: limit,
      p_offset: offset
    };

    const res = await fetch(`${configRes.url}/rest/v1/rpc/get_admin_users_list`, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify(body)
    });

    if (!res.ok) {
      throw new Error(`RPC get_admin_users_list Failed: ${res.status} - ${await res.text()}`);
    }

    return await res.json();
  }

  /**
   * Cập nhật trạng thái User (Khóa / Kích hoạt)
   */
  static async updateUserStatus(userId, status) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/profiles?id=eq.${userId}`, {
      method: 'PATCH',
      headers: headers,
      body: JSON.stringify({ status: status, updated_at: new Date().toISOString() })
    });

    if (!res.ok) throw new Error(`Update User Status Failed: ${res.status}`);
    return true;
  }

  /**
   * Xóa vĩnh viễn tài khoản người dùng
   */
  static async deleteUser(userId) {
    try {
      return await this._rpc('admin_delete_user', { p_user_id: userId });
    } catch (rpcErr) {
      const configRes = await this._getConfig();
      const headers = await this._getAuthHeaders(configRes);

      await fetch(`${configRes.url}/rest/v1/user_roles?user_id=eq.${encodeURIComponent(userId)}`, { method: 'DELETE', headers }).catch(() => {});
      await fetch(`${configRes.url}/rest/v1/shop_members?user_id=eq.${encodeURIComponent(userId)}`, { method: 'DELETE', headers }).catch(() => {});
      
      const res = await fetch(`${configRes.url}/rest/v1/profiles?id=eq.${encodeURIComponent(userId)}`, {
        method: 'DELETE',
        headers: headers
      });
      if (!res.ok) {
        throw new Error(`Xóa tài khoản thất bại: ${res.status} - ${await res.text()}`);
      }
      return { success: true };
    }
  }

  // ==========================================
  // DEVICE MANAGEMENT
  // ==========================================

  /**
   * Liệt kê toàn bộ thiết bị hệ thống (RPC admin_list_devices kèm Fallback REST)
   */
  static async listDevices() {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    try {
      const res = await fetch(`${configRes.url}/rest/v1/rpc/admin_list_devices`, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify({})
      });

      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) return data;
      }
    } catch (_) {}

    // Fallback: Query trực tiếp bảng extension_devices
    try {
      const fallbackRes = await fetch(
        `${configRes.url}/rest/v1/extension_devices?select=*,profiles:user_id(email,full_name),shops:shop_id(id,name)&order=last_seen.desc`,
        { method: 'GET', headers: headers }
      );
      if (fallbackRes.ok) {
        const rows = await fallbackRes.json();
        return (rows || []).map(r => ({
          device_id: r.id || r.device_id,
          user_id: r.user_id,
          email: r.profiles?.email || r.email || '—',
          full_name: r.profiles?.full_name || r.full_name || 'Nhân viên',
          device_name: r.device_name || 'Trình duyệt Web',
          browser: r.browser || 'Google Chrome',
          version: r.client_version || r.version || 'v2.4 Pro',
          revoked: !!r.revoked,
          shop_id: r.shop_id || r.shops?.id,
          shop_name: r.shops?.name || r.shop_name || '—',
          os_info: r.os_info || 'Windows',
          ip_address: r.ip_address || '127.0.0.1',
          metadata: r.metadata || {},
          last_seen: r.last_seen,
          created_at: r.created_at
        }));
      }
    } catch (_) {}

    return [];
  }

  /**
   * Thu hồi (revoke) hoặc khôi phục (restore) thiết bị
   */
  static async revokeDevice(deviceId, revoked = true) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/rpc/admin_revoke_device`, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify({ p_device_id: deviceId, p_revoked: revoked })
    });

    if (!res.ok) throw new Error(`RPC admin_revoke_device Failed: ${res.status} - ${await res.text()}`);
    return await res.json();
  }

  // ==========================================
  // SUBSCRIPTIONS
  // ==========================================

  /**
   * Lấy danh sách subscriptions kèm thông tin shop
   */
  static async getSubscriptions() {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(
      `${configRes.url}/rest/v1/subscriptions?select=*,shops(id,name)&order=created_at.desc`,
      { method: 'GET', headers: headers }
    );

    if (!res.ok) throw new Error(`Fetch Subscriptions Failed: ${res.status} - ${await res.text()}`);
    return await res.json();
  }

  /**
   * Cập nhật subscription của shop (plan, status)
   */
  static async updateSubscription(subscriptionId, updates) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/subscriptions?id=eq.${subscriptionId}`, {
      method: 'PATCH',
      headers: headers,
      body: JSON.stringify({ ...updates, updated_at: new Date().toISOString() })
    });

    if (!res.ok) throw new Error(`Update Subscription Failed: ${res.status}`);
    return true;
  }

  /**
   * Cập nhật Plan của Shop bằng cách cập nhật/tạo mới subscription tương ứng
   */
  static async updateShopPlan(shopId, newPlan) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    // 1. Kiểm tra xem shop đã có subscription chưa
    const checkRes = await fetch(`${configRes.url}/rest/v1/subscriptions?shop_id=eq.${shopId}&select=id`, {
      method: 'GET',
      headers: headers
    });
    if (!checkRes.ok) throw new Error(`Query Subscription Failed: ${checkRes.status}`);
    const data = await checkRes.json();

    if (data && data.length > 0) {
      // 2. Cập nhật subscription hiện tại
      const updateRes = await fetch(`${configRes.url}/rest/v1/subscriptions?id=eq.${data[0].id}`, {
        method: 'PATCH',
        headers: headers,
        body: JSON.stringify({ plan_code: newPlan, updated_at: new Date().toISOString() })
      });
      if (!updateRes.ok) throw new Error(`Update Subscription Failed: ${updateRes.status}`);
    } else {
      // 3. Tạo mới subscription
      const insertRes = await fetch(`${configRes.url}/rest/v1/subscriptions`, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify({ shop_id: shopId, plan_code: newPlan, status: 'active' })
      });
      if (!insertRes.ok) throw new Error(`Insert Subscription Failed: ${insertRes.status}`);
    }
    return true;
  }

  // ==========================================
  // SUPPORT TICKETS
  // ==========================================

  /**
   * Lấy danh sách support tickets kèm thông tin shop
   */
  static async getSupportTickets({ status, priority, limit = 50 } = {}) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    let url = `${configRes.url}/rest/v1/support_tickets?select=*,shops(id,name)&order=created_at.desc&limit=${limit}`;
    if (status) url += `&status=eq.${status}`;
    if (priority) url += `&priority=eq.${priority}`;

    const res = await fetch(url, { method: 'GET', headers: headers });
    if (!res.ok) throw new Error(`Fetch Support Tickets Failed: ${res.status} - ${await res.text()}`);
    return await res.json();
  }

  /**
   * Cập nhật trạng thái ticket
   */
  static async updateTicketStatus(ticketId, status) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/support_tickets?id=eq.${ticketId}`, {
      method: 'PATCH',
      headers: headers,
      body: JSON.stringify({ status, updated_at: new Date().toISOString() })
    });

    if (!res.ok) throw new Error(`Update Ticket Status Failed: ${res.status}`);
    return true;
  }

  // ==========================================
  // RELEASE VERSIONS
  // ==========================================

  /**
   * Lấy danh sách phiên bản Extension
   */
  static async getReleaseVersions() {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(
      `${configRes.url}/rest/v1/release_versions?order=created_at.desc`,
      { method: 'GET', headers: headers }
    );

    if (!res.ok) throw new Error(`Fetch Release Versions Failed: ${res.status} - ${await res.text()}`);
    return await res.json();
  }

  // ==========================================
  // CARRIER HEALTH
  // ==========================================

  /**
   * Lấy thống kê sức khoẻ carrier gần nhất (1 bản ghi/carrier)
   */
  static async getCarrierHealth() {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    // Lấy bản ghi mới nhất cho mỗi carrier_code
    const res = await fetch(
      `${configRes.url}/rest/v1/carrier_health_logs?order=detected_at.desc&limit=50`,
      { method: 'GET', headers: headers }
    );

    if (!res.ok) throw new Error(`Fetch Carrier Health Failed: ${res.status} - ${await res.text()}`);
    const rows = await res.json();

    // Deduplicate: chỉ giữ bản ghi mới nhất cho mỗi carrier_code
    const seen = new Set();
    return rows.filter(r => {
      if (seen.has(r.carrier_code)) return false;
      seen.add(r.carrier_code);
      return true;
    });
  }

  // ==========================================
  // FEATURE FLAGS
  // ==========================================

  /**
   * Lấy danh sách feature flags
   */
  static async getFeatureFlags() {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(
      `${configRes.url}/rest/v1/feature_flags?order=created_at.desc`,
      { method: 'GET', headers: headers }
    );

    if (!res.ok) throw new Error(`Fetch Feature Flags Failed: ${res.status} - ${await res.text()}`);
    return await res.json();
  }

  /**
   * Toggle feature flag (bật / tắt)
   */
  static async updateFeatureFlag(flagId, updates) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/feature_flags?id=eq.${flagId}`, {
      method: 'PATCH',
      headers: headers,
      body: JSON.stringify({ ...updates, updated_at: new Date().toISOString() })
    });

    if (!res.ok) throw new Error(`Update Feature Flag Failed: ${res.status}`);
    return true;
  }

  // ==========================================
  // ADDRESS DATASET VERSIONS
  // ==========================================

  /**
   * Lấy danh sách các phiên bản Address Dataset
   */
  static async getAddressDatasets() {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(
      `${configRes.url}/rest/v1/address_dataset_versions?order=created_at.desc`,
      { method: 'GET', headers: headers }
    );

    if (!res.ok) throw new Error(`Fetch Address Datasets Failed: ${res.status} - ${await res.text()}`);
    return await res.json();
  }

  /**
   * Cập nhật trạng thái Address Dataset
   */
  static async updateAddressDataset(datasetId, updates) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(`${configRes.url}/rest/v1/address_dataset_versions?id=eq.${datasetId}`, {
      method: 'PATCH',
      headers: headers,
      body: JSON.stringify(updates)
    });

    if (!res.ok) throw new Error(`Update Address Dataset Failed: ${res.status}`);
    return true;
  }

  static async activateAddressDataset(datasetId, action, reason) {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);
    const res = await fetch(`${configRes.url}/rest/v1/rpc/activate_address_dataset`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ p_dataset_id: datasetId, p_action: action, p_reason: reason })
    });
    if (!res.ok) throw new Error(`Activate Address Dataset Failed: ${res.status} - ${await res.text()}`);
    return await res.json();
  }

  // ==========================================
  // SECURITY / AUDIT LOGS
  // ==========================================


  /**
   * Lấy thống kê audit logs cho SecurityRLS page
   */
  static async getSecurityStats() {
    const configRes = await this._getConfig();
    const headers = await this._getAuthHeaders(configRes);

    const res = await fetch(
      `${configRes.url}/rest/v1/audit_logs?select=id,actor_id,user_id,action,entity_type,entity_id,details,payload,created_at&order=created_at.desc&limit=100`,
      { method: 'GET', headers: headers }
    );

    if (!res.ok) return { total: 0, logs: [] };
    const logs = await res.json();
    return { total: logs.length, logs };
  }
}
