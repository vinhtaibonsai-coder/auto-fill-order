import { AdminRepository } from './admin.repository.js';
import { AuthSession } from '../auth/auth.session.esm.js';

/**
 * Admin Service - Lớp Xử Lý Business Logic (Service Layer)
 * Giao tiếp với UI component. Bọc lỗi, định dạng Response.
 */
export class AdminService {
  /**
   * Kiểm tra Authentication & Authorization (Frontend Basic)
   * Lớp an ninh chính vẫn nằm ở Supabase RLS.
   */
  static async _ensureAdmin() {
    const sess = await AuthSession.getSession().catch(() => null);
    if (!sess || !sess.user) {
      throw new Error("Lỗi Xác Thực: Bạn chưa đăng nhập.");
    }

    // Kiểm tra quyền Admin ở tầng ứng dụng bằng cách truy cập Supabase client trực tiếp
    const configRes = await AdminRepository._getConfig();
    const headers = await AdminRepository._getAuthHeaders(configRes);
    const res = await fetch(
      `${configRes.url}/rest/v1/user_roles?user_id=eq.${encodeURIComponent(sess.user.id)}&select=role_id,roles(code)`,
      { headers }
    );

    if (!res.ok) {
      throw new Error(`Lá»—i kiá»ƒm tra quyá»n Admin: HTTP ${res.status}`);
    }

    const rows = await res.json().catch(() => []);
    const hasSystemAdminRole = Array.isArray(rows) && rows.some(ur => ur.roles && ur.roles.code === 'SYSTEM_ADMIN');

    if (!hasSystemAdminRole) {
      throw new Error("Lá»—i Quyá»n Háº¡n: Chá»‰ tÃ i khoáº£n Quáº£n trá»‹ viÃªn há»‡ thá»‘ng (SYSTEM_ADMIN) má»›i cÃ³ quyá»n thá»±c hiá»‡n.");
    }

    return sess.user.id;

    const supabase = null;
    if (supabase) {
      const { data, error } = await supabase
        .from('user_roles')
        .select('role_id, roles(code)')
        .eq('user_id', sess.user.id);

      let isAdmin = false;
      if (data && data.length > 0) {
        isAdmin = data.some(ur => ur.roles && ur.roles.code === 'SYSTEM_ADMIN');
      }

      if (!isAdmin) {
        throw new Error("Lỗi Quyền Hạn: Chỉ tài khoản Quản trị viên hệ thống (SYSTEM_ADMIN) mới có quyền thực hiện.");
      }
    }
    return sess.user.id;
  }

  /**
   * Fetch KPIs cho trang Overview
   */
  static async getOverviewMetrics() {
    try {
      await this._ensureAdmin();
      const kpis = await AdminRepository.getKpis();
      return {
        success: true,
        data: kpis
      };
    } catch (e) {
      console.error("[AdminService] getOverviewMetrics Error:", e);
      return {
        success: false,
        error: e.message || "Không thể lấy số liệu tổng quan"
      };
    }
  }

  /**
   * Fetch System Health thật cho trang System Health
   */
  static async getSystemHealth() {
    try {
      await this._ensureAdmin();
      const health = await AdminRepository.getSystemHealth();
      return {
        success: true,
        data: health
      };
    } catch (e) {
      console.error("[AdminService] getSystemHealth Error:", e);
      return {
        success: false,
        error: e.message || "Không thể lấy dữ liệu hệ thống"
      };
    }
  }

  /**
   * Action: Thử lại các tác vụ đồng bộ thất bại
   */
  static async retryFailedSyncs() {
    try {
      await this._ensureAdmin();
      const res = await AdminRepository.retryFailedSyncs();
      return {
        success: true,
        data: res
      };
    } catch (e) {
      console.error("[AdminService] retryFailedSyncs Error:", e);
      return {
        success: false,
        error: e.message || "Không thể thực thi thử lại đồng bộ"
      };
    }
  }

  /**
   * Action: Kiểm tra kết nối và độ phản hồi bưu cục
   */
  static async pingCarrier(carrierCode) {
    try {
      await this._ensureAdmin();
      const res = await AdminRepository.pingCarrier(carrierCode);
      return {
        success: true,
        data: res
      };
    } catch (e) {
      console.error("[AdminService] pingCarrier Error:", e);
      return {
        success: false,
        error: e.message || "Không thể gửi tín hiệu kiểm tra bưu cục"
      };
    }
  }

  /**
   * Action: Xóa cache và tải lại toàn bộ Schema
   */
  static async flushSystemCache() {
    try {
      await this._ensureAdmin();
      const res = await AdminRepository.flushSystemCache();
      return {
        success: true,
        data: res
      };
    } catch (e) {
      console.error("[AdminService] flushSystemCache Error:", e);
      return {
        success: false,
        error: e.message || "Không thể xóa cache hệ thống"
      };
    }
  }

  /**
   * Fetch Danh sách Cửa hàng
   */
  static async getAllShops() {
    try {
      await this._ensureAdmin();
      const shops = await AdminRepository.getShops();
      return {
        success: true,
        data: shops
      };
    } catch (e) {
      console.error("[AdminService] getAllShops Error:", e);
      return {
        success: false,
        error: e.message || "Không thể tải danh sách cửa hàng"
      };
    }
  }

  /**
   * Fetch Danh sách Users
   */
  static async getAllUsers() {
    try {
      await this._ensureAdmin();
      const users = await AdminRepository.getUsers();
      return {
        success: true,
        data: users
      };
    } catch (e) {
      console.error("[AdminService] getAllUsers Error:", e);
      return {
        success: false,
        error: e.message || "Không thể tải danh sách người dùng"
      };
    }
  }

  // --- ACTIONS (Kèm Audit Log Tự Động) --- //

  /**
   * Ví dụ: Thay đổi Plan của Shop
   */
  static async updateShopPlan(shopId, oldPlan, newPlan) {
    try {
      await this._ensureAdmin();
      
      // Thực hiện cập nhật thật trong cơ sở dữ liệu
      await AdminRepository.updateShopPlan(shopId, newPlan);

      // Tự động Audit
      await AdminRepository.insertAuditLog(
        'ADMIN_CHANGE_PLAN',
        shopId,
        'shop',
        { plan: oldPlan },
        { plan: newPlan },
        'SUCCESS'
      );

      return { success: true };
    } catch (e) {
      await AdminRepository.insertAuditLog(
        'ADMIN_CHANGE_PLAN',
        shopId,
        'shop',
        { plan: oldPlan },
        { plan: newPlan },
        'FAILED'
      );
      return { success: false, error: e.message };
    }
  }

  /**
   * Fetch Danh sách Shops (Tổng hợp KPIs) cho màn hình Shops
   */
  static async getShopsList() {
    try {
      await this._ensureAdmin();
      const shops = await AdminRepository.getShopsList();
      return {
        success: true,
        data: shops
      };
    } catch (e) {
      console.error("[AdminService] getShopsList Error:", e);
      return {
        success: false,
        error: e.message || "Không thể tải danh sách cửa hàng"
      };
    }
  }

  /**
   * Cập nhật trạng thái Shop (Active/Suspended/Trial)
   */
  static async updateShopStatus(shopId, oldStatus, newStatus) {
    try {
      await this._ensureAdmin();
      await AdminRepository.updateShopStatus(shopId, newStatus);
      
      await AdminRepository.insertAuditLog(
        'ADMIN_UPDATE_SHOP_STATUS',
        shopId,
        'shop',
        { status: oldStatus },
        { status: newStatus },
        'SUCCESS'
      );
      return { success: true };
    } catch (e) {
      await AdminRepository.insertAuditLog(
        'ADMIN_UPDATE_SHOP_STATUS',
        shopId,
        'shop',
        { status: oldStatus },
        { status: newStatus },
        'FAILED'
      );
      return { success: false, error: e.message };
    }
  }

  // ==========================================
  // SHOP FEATURE FLAGS MANAGEMENT
  // ==========================================

  static async getShopFeatureFlags(shopId) {
    try {
      await this._ensureAdmin();
      const flags = await AdminRepository.getShopFeatureFlags(shopId);
      return { success: true, data: flags };
    } catch (e) {
      console.error("[AdminService] getShopFeatureFlags Error:", e);
      return { success: false, error: e.message || "Không thể tải cấu hình Shop" };
    }
  }

  static async updateShopFeatureFlags(shopId, oldData, updates) {
    try {
      await this._ensureAdmin();
      await AdminRepository.updateShopFeatureFlags(shopId, updates);
      
      await AdminRepository.insertAuditLog(
        'ADMIN_UPDATE_SHOP_FLAGS',
        shopId,
        'shop',
        oldData,
        updates,
        'SUCCESS'
      );
      return { success: true };
    } catch (e) {
      await AdminRepository.insertAuditLog(
        'ADMIN_UPDATE_SHOP_FLAGS',
        shopId,
        'shop',
        oldData,
        updates,
        'FAILED'
      );
      return { success: false, error: e.message };
    }
  }

  // ==========================================
  // SHOP MEMBERS MANAGEMENT
  // ==========================================

  /**
   * Lấy danh sách thành viên của Shop
   */
  static async getShopMembers(shopId) {
    try {
      await this._ensureAdmin();
      const members = await AdminRepository.getShopMembers(shopId);
      return { success: true, data: members };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  /**
   * Gán người dùng vào Shop
   */
  static async assignUserShop(userId, shopId, roleCode = 'STAFF') {
    try {
      await this._ensureAdmin();
      const res = await AdminRepository.assignUserShop(userId, shopId, roleCode);
      await AdminRepository.insertAuditLog('ADMIN_ASSIGN_SHOP_MEMBER', shopId, 'shop_member', { userId, roleCode }, null, 'SUCCESS');
      return { success: true, data: res };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  /**
   * Tạo tài khoản mới và gán trực tiếp vào Shop
   */
  static async createAndAddShopMember(shopId, memberData) {
    try {
      await this._ensureAdmin();
      const res = await AdminRepository.createAndAddShopMember(shopId, memberData);
      await AdminRepository.insertAuditLog('ADMIN_CREATE_ADD_SHOP_MEMBER', shopId, 'shop_member', { email: memberData.email, role: memberData.roleCode }, null, 'SUCCESS');
      return { success: true, data: res };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  /**
   * Xóa nhân viên khỏi Shop
   */
  static async removeShopMember(shopId, userId) {
    try {
      await this._ensureAdmin();
      const res = await AdminRepository.removeShopMember(shopId, userId);
      await AdminRepository.insertAuditLog('ADMIN_REMOVE_SHOP_MEMBER', shopId, 'shop_member', { userId }, null, 'SUCCESS');
      return { success: true, data: res };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  /**
   * Lấy tất cả user cho autocomplete
   */
  static async getAllUsers() {
    try {
      await this._ensureAdmin();
      const users = await AdminRepository.getUsersList({ limit: 1000 });
      return { success: true, data: users };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  // ==========================================
  // USERS MANAGEMENT
  // ==========================================

  /**
   * Fetch Danh sách Users cho Admin Dashboard
   */
  static async getUsersList(filters = {}) {
    try {
      await this._ensureAdmin();
      const users = await AdminRepository.getUsersList(filters);
      return {
        success: true,
        data: users
      };
    } catch (e) {
      console.error("[AdminService] getUsersList Error:", e);
      return {
        success: false,
        error: e.message || "Không thể tải danh sách người dùng"
      };
    }
  }

  /**
   * Cập nhật trạng thái User (Active/Suspended)
   */
  static async updateUserStatus(userId, oldStatus, newStatus) {
    try {
      await this._ensureAdmin();
      await AdminRepository.updateUserStatus(userId, newStatus);
      
      await AdminRepository.insertAuditLog(
        'ADMIN_UPDATE_USER_STATUS',
        userId,
        'user',
        { status: oldStatus },
        { status: newStatus },
        'SUCCESS'
      );
      return { success: true };
    } catch (e) {
      await AdminRepository.insertAuditLog(
        'ADMIN_UPDATE_USER_STATUS',
        userId,
        'user',
        { status: oldStatus },
        { status: newStatus },
        'FAILED'
      );
      return { success: false, error: e.message };
    }
  }

  /**
   * Xóa vĩnh viễn tài khoản người dùng (SYSTEM_ADMIN only)
   */
  static async deleteUser(userId, userEmail = '') {
    try {
      await this._ensureAdmin();
      const res = await AdminRepository.deleteUser(userId);
      await AdminRepository.insertAuditLog(
        'ADMIN_DELETE_USER',
        userId,
        'user',
        { email: userEmail },
        null,
        'SUCCESS'
      );
      return { success: true, data: res };
    } catch (e) {
      await AdminRepository.insertAuditLog(
        'ADMIN_DELETE_USER',
        userId,
        'user',
        { email: userEmail },
        null,
        'FAILED'
      );
      return { success: false, error: e.message };
    }
  }

  /**
   * Xóa hàng loạt tài khoản người dùng
   */
  static async deleteMultipleUsers(userIds) {
    try {
      await this._ensureAdmin();
      let count = 0;
      for (const id of userIds) {
        const res = await AdminRepository.deleteUser(id);
        if (res?.success || res === true) count++;
      }
      await AdminRepository.insertAuditLog(
        'ADMIN_BULK_DELETE_USERS',
        'bulk',
        'user',
        { count, userIds },
        null,
        'SUCCESS'
      );
      return { success: true, count };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  // ==========================================
  // DEVICE MANAGEMENT
  // ==========================================

  /**
   * Liệt kê toàn bộ thiết bị trong hệ thống (SYSTEM_ADMIN only)
   */
  static async listDevices() {
    try {
      await this._ensureAdmin();
      const devices = await AdminRepository.listDevices();
      return { success: true, data: devices };
    } catch (e) {
      console.error('[AdminService] listDevices Error:', e);
      return { success: false, error: e.message || 'Không thể tải danh sách thiết bị' };
    }
  }

  /**
   * Thu hồi hoặc khôi phục thiết bị
   */
  static async revokeDevice(deviceId, revoked = true) {
    try {
      await this._ensureAdmin();
      const result = await AdminRepository.revokeDevice(deviceId, revoked);
      await AdminRepository.insertAuditLog(
        revoked ? 'ADMIN_REVOKE_DEVICE' : 'ADMIN_RESTORE_DEVICE',
        deviceId,
        'device',
        { revoked: !revoked },
        { revoked },
        'SUCCESS'
      );
      return { success: true, data: result };
    } catch (e) {
      console.error('[AdminService] revokeDevice Error:', e);
      return { success: false, error: e.message || 'Không thể cập nhật thiết bị' };
    }
  }

  // ==========================================
  // SUBSCRIPTIONS
  // ==========================================

  /**
   * Lấy danh sách subscriptions kèm thông tin shop
   */
  static async getSubscriptions() {
    try {
      await this._ensureAdmin();
      const subs = await AdminRepository.getSubscriptions();
      return { success: true, data: subs };
    } catch (e) {
      console.error('[AdminService] getSubscriptions Error:', e);
      return { success: false, error: e.message || 'Không thể tải danh sách subscriptions' };
    }
  }

  /**
   * Cập nhật subscription (đổi plan, trạng thái)
   */
  static async updateSubscription(subscriptionId, oldData, updates) {
    try {
      await this._ensureAdmin();
      await AdminRepository.updateSubscription(subscriptionId, updates);
      await AdminRepository.insertAuditLog(
        'ADMIN_UPDATE_SUBSCRIPTION',
        subscriptionId,
        'subscription',
        oldData,
        updates,
        'SUCCESS'
      );
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  // ==========================================
  // SUPPORT TICKETS
  // ==========================================

  /**
   * Lấy danh sách support tickets
   */
  static async getSupportTickets(filters = {}) {
    try {
      await this._ensureAdmin();
      const tickets = await AdminRepository.getSupportTickets(filters);
      return { success: true, data: tickets };
    } catch (e) {
      console.error('[AdminService] getSupportTickets Error:', e);
      return { success: false, error: e.message || 'Không thể tải danh sách tickets' };
    }
  }

  /**
   * Cập nhật trạng thái ticket
   */
  static async updateTicketStatus(ticketId, oldStatus, newStatus) {
    try {
      await this._ensureAdmin();
      await AdminRepository.updateTicketStatus(ticketId, newStatus);
      await AdminRepository.insertAuditLog(
        'ADMIN_UPDATE_TICKET_STATUS',
        ticketId,
        'support_ticket',
        { status: oldStatus },
        { status: newStatus },
        'SUCCESS'
      );
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  // ==========================================
  // RELEASE VERSIONS
  // ==========================================

  /**
   * Lấy danh sách phiên bản Extension
   */
  static async getReleaseVersions() {
    try {
      await this._ensureAdmin();
      const versions = await AdminRepository.getReleaseVersions();
      return { success: true, data: versions };
    } catch (e) {
      console.error('[AdminService] getReleaseVersions Error:', e);
      return { success: false, error: e.message || 'Không thể tải danh sách phiên bản' };
    }
  }

  // ==========================================
  // CARRIER HEALTH
  // ==========================================

  /**
   * Lấy trạng thái sức khoẻ của các nhà vận chuyển
   */
  static async getCarrierHealth() {
    try {
      await this._ensureAdmin();
      const carriers = await AdminRepository.getCarrierHealth();
      return { success: true, data: carriers };
    } catch (e) {
      console.error('[AdminService] getCarrierHealth Error:', e);
      return { success: false, error: e.message || 'Không thể tải dữ liệu carrier' };
    }
  }

  // ==========================================
  // FEATURE FLAGS
  // ==========================================

  /**
   * Lấy danh sách feature flags
   */
  static async getFeatureFlags() {
    try {
      await this._ensureAdmin();
      const flags = await AdminRepository.getFeatureFlags();
      return { success: true, data: flags };
    } catch (e) {
      console.error('[AdminService] getFeatureFlags Error:', e);
      return { success: false, error: e.message || 'Không thể tải feature flags' };
    }
  }

  /**
   * Toggle feature flag
   */
  static async updateFeatureFlag(flagId, oldData, updates) {
    try {
      await this._ensureAdmin();
      await AdminRepository.updateFeatureFlag(flagId, updates);
      await AdminRepository.insertAuditLog(
        'ADMIN_UPDATE_FEATURE_FLAG',
        flagId,
        'feature_flag',
        oldData,
        updates,
        'SUCCESS'
      );
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  // ==========================================
  // ADDRESS DATASET VERSIONS
  // ==========================================

  /**
   * Lấy danh sách Address Dataset Versions
   */
  static async getAddressDatasets() {
    try {
      await this._ensureAdmin();
      const datasets = await AdminRepository.getAddressDatasets();
      return { success: true, data: datasets };
    } catch (e) {
      console.error('[AdminService] getAddressDatasets Error:', e);
      return { success: false, error: e.message || 'Không thể tải Address Datasets' };
    }
  }

  /**
   * Cập nhật trạng thái Address Dataset (VD: Rollback, Kích hoạt)
   */
  static async updateAddressDatasetStatus(datasetId, oldData, updates) {
    try {
      await this._ensureAdmin();
      await AdminRepository.updateAddressDataset(datasetId, updates);
      await AdminRepository.insertAuditLog(
        'ADMIN_UPDATE_ADDRESS_DATASET',
        datasetId,
        'address_dataset_version',
        oldData,
        updates,
        'SUCCESS'
      );
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  static async activateAddressDataset(dataset, action, reason) {
    try {
      await this._ensureAdmin();
      if (!dataset?.id || !dataset?.version || Number(dataset.total_records || 0) <= 0) {
        throw new Error('Dataset chưa vượt qua bước validate.');
      }
      if (!['publish', 'rollback'].includes(action)) throw new Error('Hành động phát hành không hợp lệ.');
      if (!reason?.trim()) throw new Error('Phải nhập lý do phát hành hoặc rollback.');
      const result = await AdminRepository.activateAddressDataset(dataset.id, action, reason.trim());
      return { success: true, data: result };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  // ==========================================
  // SECURITY / AUDIT
  // ==========================================

  /**
   * Lấy thống kê bảo mật và audit logs hôm nay
   */
  static async getSecurityStats() {
    try {
      await this._ensureAdmin();
      const stats = await AdminRepository.getSecurityStats();
      return { success: true, data: stats };
    } catch (e) {
      console.error('[AdminService] getSecurityStats Error:', e);
      return { success: false, data: { total: 0, logs: [] } };
    }
  }

  static async _runAdminAction(action, targetId, targetType, beforeState, afterState, operation) {
    try {
      await this._ensureAdmin();
      const data = await operation();
      await AdminRepository.insertAuditLog(action, targetId, targetType, beforeState, afterState, 'SUCCESS');
      if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
        window.dispatchEvent(new CustomEvent('admin:refresh_data', { 
          detail: { action, targetId, targetType, timestamp: Date.now() } 
        }));
      }
      return { success: true, data };
    } catch (e) {
      await AdminRepository.insertAuditLog(action, targetId, targetType, beforeState, afterState, 'FAILED');
      return { success: false, error: e.message };
    }
  }

  static createShopWithAccount(form) {
    const password = form.password || `Afo@${crypto.getRandomValues(new Uint32Array(1))[0].toString(36)}!`;
    return this._runAdminAction('ADMIN_CREATE_SHOP', null, 'shop', null, { email: form.ownerEmail }, () => AdminRepository.createShopWithAccount({ ...form, password, dailyAiLimit: 500 }));
  }

  static topupQuota(shopId, amount) {
    if (![500, 1000, 2000].includes(Number(amount))) return Promise.resolve({ success: false, error: 'Mức cấp quota không hợp lệ.' });
    return this._runAdminAction('ADMIN_TOPUP_QUOTA', shopId, 'shop_quota', null, { amount }, () => AdminRepository.topupQuota(shopId, Number(amount)));
  }
  static async getQuotaOverview() { try { await this._ensureAdmin(); return { success: true, data: await AdminRepository.getQuotaOverview() }; } catch (e) { return { success: false, error: e.message }; } }

  static transferShopOwnership(shopId, targetIdentifier) {
    const trimmed = String(targetIdentifier || '').trim();
    if (!trimmed) return Promise.resolve({ success: false, error: 'Vui lòng nhập Email hoặc UUID tài khoản chủ sở hữu mới.' });

    return this._runAdminAction('ADMIN_TRANSFER_OWNERSHIP', shopId, 'shop', null, { target: trimmed }, async () => {
      let targetUserId = trimmed;
      const isEmail = trimmed.includes('@');
      const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(trimmed);

      if (isEmail || !isUUID) {
        const foundUser = await AdminRepository.findUserByEmailOrId(trimmed);
        if (!foundUser || !foundUser.id) {
          throw new Error(`Không tìm thấy tài khoản người dùng với email/tên "${trimmed}" trong hệ thống.`);
        }
        targetUserId = foundUser.id;
      }

      return await AdminRepository.transferShopOwnership(shopId, targetUserId);
    });
  }
  static createAdminAccount(data) { return this._runAdminAction('ADMIN_CREATE_ACCOUNT', null, 'user', null, { email: data.email, role: data.role }, () => AdminRepository.createAdminAccount(data)); }

  static startImpersonation(shopId, shopName, reason) {
    if (!reason?.trim()) return Promise.resolve({ success: false, error: 'Phải nhập lý do giả lập Shop.' });
    return this._runAdminAction('IMPERSONATION_START', shopId, 'shop', null, { reason }, async () => {
      await AdminRepository.startImpersonation(shopId, reason.trim());
      return { shopId, shopName, reason: reason.trim(), startedAt: new Date().toISOString() };
    });
  }

  static setUserRole(userId, role) { return this._runAdminAction('ADMIN_SET_USER_ROLE', userId, 'user', null, { role }, () => AdminRepository.setUserRole(userId, role)); }
  static overrideSubscription(shopId, plan, months) { return this._runAdminAction('ADMIN_OVERRIDE_SUBSCRIPTION', shopId, 'subscription', null, { plan, months }, () => AdminRepository.overrideSubscription(shopId, plan, months)); }
  static revokeShopDevices(shopId) { return this._runAdminAction('ADMIN_REVOKE_SHOP_DEVICES', shopId, 'device', null, { revoked: true }, () => AdminRepository.revokeShopDevices(shopId)); }
  static replySupportTicket(ticketId, reply, internalNote) { return this._runAdminAction('ADMIN_REPLY_TICKET', ticketId, 'support_ticket', null, { hasReply: true, hasInternalNote: Boolean(internalNote) }, () => AdminRepository.replySupportTicket(ticketId, reply, internalNote)); }
  static publishRelease(data) { return this._runAdminAction('ADMIN_PUBLISH_RELEASE', data.version, 'release', null, data, () => AdminRepository.publishRelease(data)); }
  static recordCarrierProbe(carrierCode, status, responseTimeMs, errorMessage) { return this._runAdminAction('ADMIN_CARRIER_PROBE', carrierCode, 'carrier', null, { status, responseTimeMs, errorMessage }, () => AdminRepository.recordCarrierProbe(carrierCode, status, responseTimeMs, errorMessage)); }
  static async getUnitEconomics() { try { await this._ensureAdmin(); return { success: true, data: await AdminRepository.getUnitEconomics() }; } catch (e) { return { success: false, error: e.message }; } }
  static publishRemoteSelectors(data) { return this._runAdminAction('ADMIN_PUBLISH_REMOTE_SELECTORS', data.carrierCode, 'remote_selector_release', null, { minVersion: data.minVersion, keys: Object.keys(data.selectors || {}) }, () => AdminRepository.publishRemoteSelectors(data)); }
  static async getGrowthMetrics() { try { await this._ensureAdmin(); return { success: true, data: await AdminRepository.getGrowthMetrics() }; } catch (e) { return { success: false, error: e.message }; } }
  static creditWallet(shopId, amount, referenceId, description) { return this._runAdminAction('ADMIN_CREDIT_WALLET', shopId, 'wallet', null, { amount, referenceId }, () => AdminRepository.creditWallet(shopId, amount, referenceId, description)); }
  static createReseller(name, code, commissionRate) { return this._runAdminAction('ADMIN_CREATE_RESELLER', code, 'reseller', null, { name, commissionRate }, () => AdminRepository.createReseller(name, code, commissionRate)); }

  static resetUserPassword(userId, newPassword, forceLogout = true) {
    if (!newPassword || newPassword.length < 6) {
      return Promise.resolve({ success: false, error: 'Mật khẩu phải có ít nhất 6 ký tự.' });
    }
    return this._runAdminAction('ADMIN_RESET_PASSWORD', userId, 'user', null, { forceLogout }, async () => {
      await AdminRepository.resetUserPassword(userId, newPassword);
      if (forceLogout) {
        await AdminRepository.forceLogoutUser(userId).catch(() => {});
      }
      return { userId, forceLogout };
    });
  }

  static updateUserName(userId, fullName) {
    if (!fullName?.trim()) {
      return Promise.resolve({ success: false, error: 'Họ và tên không được để trống.' });
    }
    return this._runAdminAction('ADMIN_UPDATE_USER_NAME', userId, 'user', null, { fullName: fullName.trim() }, () => AdminRepository.updateUserName(userId, fullName.trim()));
  }

  static assignUserShop(userId, shopId, roleCode) {
    return this._runAdminAction('ADMIN_ASSIGN_USER_SHOP', userId, 'user', null, { shopId, roleCode }, () => AdminRepository.assignUserShop(userId, shopId, roleCode));
  }

  static async getShopMembers(shopId) {
    try {
      await this._ensureAdmin();
      const members = await AdminRepository.getShopMembers(shopId);
      return { success: true, data: members || [] };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  static removeShopMember(shopId, userId) {
    return this._runAdminAction('ADMIN_REMOVE_SHOP_MEMBER', shopId, 'shop_member', null, { userId }, () => AdminRepository.removeShopMember(shopId, userId));
  }

  static forceLogoutUser(userId) {
    return this._runAdminAction('ADMIN_FORCE_LOGOUT_USER', userId, 'user', null, { revoked: true }, () => AdminRepository.forceLogoutUser(userId));
  }

  static restoreShop(shopId, shopName) {
    return this._runAdminAction('ADMIN_RESTORE_SHOP', shopId, 'shop', null, { name: shopName }, () => AdminRepository.restoreShop(shopId));
  }

  static deleteShop(shopId, shopName) {
    return this._runAdminAction('ADMIN_DELETE_SHOP', shopId, 'shop', { name: shopName }, null, () => AdminRepository.deleteShop(shopId));
  }

  static deleteMultipleShops(shopIds = []) {
    if (!Array.isArray(shopIds) || shopIds.length === 0) return Promise.resolve({ success: true, count: 0 });
    return this._runAdminAction('ADMIN_BULK_DELETE_SHOPS', null, 'shop', null, { count: shopIds.length, shopIds }, async () => {
      await AdminRepository.deleteMultipleShops(shopIds);
      return { count: shopIds.length };
    });
  }

  static async purgeInactiveShops() {
    try {
      await this._ensureAdmin();
      const listRes = await this.getShopsList();
      if (!listRes.success || !Array.isArray(listRes.data)) throw new Error(listRes.error || 'Không thể lấy danh sách Shop');
      const inactives = listRes.data.filter(s => {
        const status = String(s.status || '').toLowerCase();
        const usersCount = Number(s.users_count || 0);
        const devicesCount = Number(s.devices_count || 0);
        const isDummy = String(s.name || '').startsWith('Shop của ') && usersCount === 0;
        return ((status === 'inactive' || status === 'deleted' || usersCount === 0) && devicesCount === 0) || isDummy;
      });
      if (inactives.length === 0) return { success: true, count: 0 };
      let deleted = 0;
      for (const s of inactives) {
        try {
          await AdminRepository.deleteShop(s.id);
          deleted++;
        } catch (_) {}
      }
      await AdminRepository.insertAuditLog('ADMIN_PURGE_INACTIVE_SHOPS', null, 'shop', null, { count: deleted }, 'SUCCESS');
      return { success: true, count: deleted };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  /**
   * Quản lý Thiết bị Hệ thống (Device Management)
   */
  static async listDevices() {
    try {
      await this._ensureAdmin();
      const devices = await AdminRepository.listDevices();
      return { success: true, data: devices };
    } catch (e) {
      return { success: false, error: e.message, data: [] };
    }
  }

  static async revokeDevice(deviceId, revoked = true) {
    try {
      await this._ensureAdmin();
      await AdminRepository.revokeDevice(deviceId, revoked);
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  static async revokeShopDevices(shopId) {
    try {
      await this._ensureAdmin();
      await AdminRepository.revokeShopDevices(shopId);
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
}
