// =========================================================================
// BULK-PARSER.SERVICE.JS — BÓC TÁCH ĐƠN HÀNG LOẠT & XUẤT EXCEL (PHASE 3)
// =========================================================================

(function (global) {
  'use strict';

  /**
   * Phân tách một đoạn văn bản thô chứa nhiều đơn hàng thành từng chunk riêng biệt
   */
  function hasVietnamesePhone(str) {
    if (!str) return false;
    const clean = str.replace(/[\s\.\-]/g, '');
    return /(?:(?:\+84|84|0)[35789]\d{8})/.test(clean);
  }

  function splitRawTextToChunks(rawText) {
    if (!rawText || typeof rawText !== 'string') return [];
    const text = rawText.trim();
    if (!text) return [];

    // 1. Thử tách theo phân cách rõ ràng: đường kẻ ngang hoặc khối dòng trống
    const rawBlocks = text.split(/\n\s*[-=_*]{3,}\s*\n|\n\s*\n+/).map(b => b.trim()).filter(Boolean);
    if (rawBlocks.length > 1) {
      // Gom các block thành các chunk đơn hàng hoàn chỉnh
      const chunks = [];
      let currentBlocks = [];

      for (let i = 0; i < rawBlocks.length; i++) {
        const block = rawBlocks[i];
        const blockHasPhone = hasVietnamesePhone(block);
        const currentHasPhone = currentBlocks.some(b => hasVietnamesePhone(b));

        if (blockHasPhone) {
          if (currentHasPhone && currentBlocks.length > 0) {
            chunks.push(currentBlocks.join('\n\n').trim());
            currentBlocks = [block];
          } else {
            currentBlocks.push(block);
          }
        } else {
          // Block không có SĐT
          if (currentHasPhone) {
            // Kiểm tra xem block này có phải là bắt đầu của đơn tiếp theo (ví dụ: địa chỉ hoặc tên đứng trước SĐT)
            const remainingBlocksHavePhone = rawBlocks.slice(i + 1).some(b => hasVietnamesePhone(b));
            const lastBlock = currentBlocks[currentBlocks.length - 1].toLowerCase();
            const lastBlockHasCodOrCode = /cod|tiền|thu\s*hộ|thu\s*cước|freeship|bao\s*ship|[a-z]\d+[\.-]\d+/i.test(lastBlock);
            const isNewOrderStart = /^(?:đc|đ\/c|địa\s*chỉ|số\s*\d|\d+[a-z]?\/|[a-zà-ỹ\s]+$)/i.test(block);

            if (remainingBlocksHavePhone && lastBlockHasCodOrCode && isNewOrderStart) {
              chunks.push(currentBlocks.join('\n\n').trim());
              currentBlocks = [block];
            } else {
              currentBlocks.push(block);
            }
          } else {
            currentBlocks.push(block);
          }
        }
      }

      if (currentBlocks.length > 0) {
        chunks.push(currentBlocks.join('\n\n').trim());
      }

      if (chunks.length > 1) {
        return chunks;
      }
    }

    // 2. Thử tách theo tiền tố đánh số đơn hàng (VD: "Đơn 1:", "Đơn 2:", "1.", "2.", "#1", "#2")
    const orderPrefixRegex = /(?:^|\n)(?=(?:đơn\s*\d+|#\d+|\d+[\.)]|khách\s*\d+)[\s:]+)/i;
    const prefixChunks = text.split(orderPrefixRegex).map(c => c.trim()).filter(Boolean);
    if (prefixChunks.length > 1) {
      return prefixChunks;
    }

    // 3. Tách theo dòng có chứa số điện thoại Việt Nam mới (kể cả số có dấu chấm/cách/gạch ngang)
    const lines = text.split(/\r?\n/);
    const chunks = [];
    let currentChunk = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const hasPhone = hasVietnamesePhone(line);
      const currentHasPhone = currentChunk.some(l => hasVietnamesePhone(l));

      if (hasPhone && currentHasPhone && currentChunk.length > 0) {
        // Kiểm tra xem dòng ngay trước SĐT có phải là Tên hoặc Địa chỉ của đơn mới không
        const lastLine = currentChunk[currentChunk.length - 1].trim();
        const prevLine = currentChunk.length >= 2 ? currentChunk[currentChunk.length - 2].trim() : '';
        const prevHasCodOrCode = /cod|tiền|thu\s*hộ|thu\s*cước|freeship|bao\s*ship|[a-z]\d+[\.-]\d+/i.test(prevLine);
        const lastIsNameOrAddr = /^(?:đc|đ\/c|địa\s*chỉ|[a-zà-ỹ\s]{2,35}$)/i.test(lastLine);

        if (prevHasCodOrCode && lastIsNameOrAddr) {
          const detachedLine = currentChunk.pop();
          chunks.push(currentChunk.join('\n').trim());
          currentChunk = [detachedLine, line];
        } else {
          chunks.push(currentChunk.join('\n').trim());
          currentChunk = [line];
        }
      } else {
        currentChunk.push(line);
      }
    }

    if (currentChunk.length > 0) {
      chunks.push(currentChunk.join('\n').trim());
    }

    return chunks.length > 0 ? chunks : [text];
  }

  /**
   * Trích xuất số tiền COD từ chuỗi
   */
  function extractCodAmount(text) {
    if (!text) return 0;
    // Tìm các cụm từ chỉ COD miễn phí: "chỉ thu cước", "ko thu", "0đ", "0k"
    if (/(?:chỉ\s+thu\s+cước|ko\s+thu|không\s+thu|\b0\s*(?:đ|k|vnđ)\b)/i.test(text)) {
      return 0;
    }

    const codRegex = /(?:cod|thu\s*hộ|tiền\s*thu|thu|tiền|giá)[\s:]*([0-9.,]+)\s*(k|đ|vnđ|d)?/i;
    const match = text.match(codRegex);
    if (match) {
      let numStr = match[1].replace(/[.,]/g, '');
      let val = parseInt(numStr, 10) || 0;
      if (match[2] && match[2].toLowerCase() === 'k') {
        val *= 1000;
      }
      return val;
    }

    // Thử tìm số tiền dạng 200k, 150k lẻ loi
    const shortK = text.match(/\b(\d{2,4})\s*k\b/i);
    if (shortK) {
      return parseInt(shortK[1], 10) * 1000;
    }

    return 0;
  }

  /**
   * Trích xuất SĐT từ chunk
   */
  function extractPhone(text) {
    const match = text.match(/(?:(?:\+84|84|0)[35789]\d{8})/);
    if (match) {
      let p = match[0].replace(/\D/g, '');
      if (p.startsWith('84')) p = '0' + p.slice(2);
      return p;
    }
    return '';
  }

  /**
   * Trích xuất mã đơn hàng nếu có
   */
  function extractOrderCode(text) {
    const match = text.match(/(?:mã\s*(?:đơn|đh)?|order\s*code|mđh)[\s:#]*([A-Za-z0-9_-]{4,20})/i);
    return match ? match[1].trim() : '';
  }

  /**
   * Bóc tách một chunk đơn lẻ
   */
  function parseSingleChunk(chunk, index = 1) {
    const phone = extractPhone(chunk);
    const cod = extractCodAmount(chunk);
    const orderCode = extractOrderCode(chunk) || `DH-${Date.now().toString().slice(-4)}-${index}`;

    // Tìm tên và địa chỉ dựa trên các dòng
    const lines = chunk.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    let name = '';
    let address = '';
    let goodsName = 'Hàng hóa thời trang';
    let weightGrams = 200;

    // 1. Trích xuất họ tên
    const nameMatch = chunk.match(/(?:tên|khách|người\s*nhận|họ\s*tên)[\s:]+([^\n,]+)/i);
    if (nameMatch) {
      name = nameMatch[1].trim();
    } else if (phone) {
      const beforePhone = chunk.split(phone)[0].replace(/(?:đơn\s*\d+|#\d+|\d+[\.)]|khách\s*\d+)[\s:]*/i, '').replace(/,\s*$/, '').trim();
      const lastLineBefore = beforePhone.split('\n').pop().trim();
      if (lastLineBefore && lastLineBefore.length <= 40 && !/[0-9]{4,}/.test(lastLineBefore)) {
        name = lastLineBefore;
      }
    }

    // 2. Trích xuất hàng hóa / sản phẩm
    const itemMatch = chunk.match(/(?:hàng|sp|sản\s*phẩm|món)[\s:]+([^\n,]+)/i);
    if (itemMatch) {
      goodsName = itemMatch[1].trim();
    }

    // 3. Trích xuất địa chỉ
    const addrMatch = chunk.match(/(?:địa\s*chỉ|đ\/c|đc|nhận\s*tại)[\s:]+([^\n]+)/i);
    if (addrMatch) {
      address = addrMatch[1].trim();
    } else if (phone) {
      const afterPhone = chunk.split(phone)[1] || '';
      const segs = afterPhone.split(/,\s*(?:thu\s*hộ|cod|tiền|giá|sp|hàng|món)[\s:]*/i)[0];
      const cleanAddr = segs.replace(/^[\s,:-]+/, '').trim();
      if (cleanAddr.length >= 8) {
        address = cleanAddr.split('\n')[0].trim();
      }
    }

    // Trọng lượng
    const weightMatch = chunk.match(/(\d+(?:\.\d+)?)\s*(kg|kí|g|gram)\b/i);
    if (weightMatch) {
      const num = parseFloat(weightMatch[1]);
      const unit = weightMatch[2].toLowerCase();
      weightGrams = (unit === 'kg' || unit === 'kí') ? Math.round(num * 1000) : Math.round(num);
    }

    if (!name && lines.length > 0) {
      name = lines[0].replace(phone, '').replace(/(?:đơn\s*\d+|#\d+|\d+[\.)])[\s:]*/i, '').split(',')[0].trim() || 'Khách hàng';
    }

    if (!address) {
      address = chunk.replace(/\r?\n/g, ', ');
    }

    return {
      stt: index,
      orderCode,
      name: name || 'Khách hàng',
      phone: phone || '',
      address: address || chunk.replace(/\r?\n/g, ', '),
      cod,
      goodsName,
      weightGrams,
      weightKg: Number((weightGrams / 1000).toFixed(2)),
      notes: 'Cho xem hàng, không thử',
      rawText: chunk
    };
  }

  /**
   * Bóc tách hàng loạt danh sách đơn hàng có báo cáo tiến trình
   */
  async function parseBulkOrders(rawText, onProgress) {
    const chunks = splitRawTextToChunks(rawText);
    const results = [];
    const total = chunks.length;

    for (let i = 0; i < total; i++) {
      const parsed = parseSingleChunk(chunks[i], i + 1);
      results.push(parsed);

      if (typeof onProgress === 'function') {
        const percent = Math.round(((i + 1) / total) * 100);
        onProgress({ current: i + 1, total, percent, lastParsed: parsed });
      }

      // Cho phép UI render mượt mà giữa các chunk
      if (total > 5) {
        await new Promise(r => setTimeout(r, 10));
      }
    }

    return results;
  }

  /**
   * Xuất file CSV UTF-8 với BOM (\uFEFF) cho VNPost hoặc J&T
   */
  function exportCarrierCsv(orders, carrier = 'vnpost') {
    if (!Array.isArray(orders) || orders.length === 0) return '';

    const escapeCell = (str) => {
      if (str === null || str === undefined) return '""';
      const s = String(str).replace(/"/g, '""');
      return `"${s}"`;
    };

    let headers = [];
    let rows = [];

    if (carrier.toLowerCase() === 'jt') {
      headers = [
        'STT',
        'Mã đơn hàng (Tham chiếu)',
        'Tên người nhận',
        'Điện thoại',
        'Địa chỉ chi tiết',
        'Tên hàng hóa',
        'Khối lượng (kg)',
        'Tiền thu hộ COD (đ)',
        'Ghi chú giao hàng'
      ];

      rows = orders.map((o, idx) => [
        idx + 1,
        escapeCell(o.orderCode || ''),
        escapeCell(o.name || ''),
        escapeCell(o.phone || ''),
        escapeCell(o.address || ''),
        escapeCell(o.goodsName || 'Hàng hóa'),
        escapeCell(o.weightKg || (o.weightGrams ? (o.weightGrams / 1000).toFixed(2) : '0.2')),
        escapeCell(o.cod || 0),
        escapeCell(o.notes || '')
      ]);
    } else {
      // VNPost mặc định
      headers = [
        'STT',
        'Mã đơn khách hàng',
        'Họ tên người nhận',
        'Số điện thoại',
        'Địa chỉ nhận hàng',
        'Nội dung bưu gửi',
        'Khối lượng (gram)',
        'Tiền thu hộ COD',
        'Chỉ dẫn phát'
      ];

      rows = orders.map((o, idx) => [
        idx + 1,
        escapeCell(o.orderCode || ''),
        escapeCell(o.name || ''),
        escapeCell(o.phone || ''),
        escapeCell(o.address || ''),
        escapeCell(o.goodsName || 'Hàng hóa'),
        escapeCell(o.weightGrams || 200),
        escapeCell(o.cod || 0),
        escapeCell(o.notes || 'Cho xem hàng')
      ]);
    }

    // Thêm BOM UTF-8 (\uFEFF) để Excel trên Windows hiển thị đúng tiếng Việt
    const csvContent = '\uFEFF' + [
      headers.join(','),
      ...rows.map(r => r.join(','))
    ].join('\r\n');

    return csvContent;
  }

  /**
   * Kích hoạt tải file về máy
   */
  function downloadCsvFile(content, fileName) {
    if (typeof document === 'undefined') return;
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', fileName || `Don_Hang_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  const BulkParserService = {
    splitRawTextToChunks,
    extractCodAmount,
    extractPhone,
    extractOrderCode,
    parseSingleChunk,
    parseBulkOrders,
    exportCarrierCsv,
    downloadCsvFile
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = BulkParserService;
  }
  global.BulkParserService = BulkParserService;
})(typeof globalThis !== 'undefined' ? globalThis : this);
