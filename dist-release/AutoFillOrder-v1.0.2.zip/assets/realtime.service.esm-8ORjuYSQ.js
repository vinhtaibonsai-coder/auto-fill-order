import"./realtime.service.js-B_BTeEyg.js";const i=globalThis.RealtimeService||(typeof window<"u"?window.RealtimeService:null);export{i as R};
