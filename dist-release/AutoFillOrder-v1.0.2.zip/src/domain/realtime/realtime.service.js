// =========================================================================
// REALTIME.SERVICE.JS — DỊCH VỤ ĐỒNG BỘ REALTIME & PRESENCE MÁY TRẠM (SUPABASE)
// =========================================================================

const RealtimeService = {
  _activeChannel: null,
  _presenceChannels: new Map(),

  async _getClient() {
    if (typeof window !== 'undefined' && window.supabaseClient) {
      return window.supabaseClient;
    }
    if (typeof globalThis !== 'undefined' && globalThis.supabaseClient) {
      return globalThis.supabaseClient;
    }
    try {
      const configRes = typeof SupabaseCloud !== 'undefined' && typeof SupabaseCloud.loadConfig === 'function'
        ? await SupabaseCloud.loadConfig()
        : null;
      if (configRes?.url && configRes?.anonKey) {
        const { createClient } = await import('@supabase/supabase-js');
        const client = createClient(configRes.url, configRes.anonKey, {
          auth: {
            persistSession: false,
            autoRefreshToken: false,
            detectSessionInUrl: false
          }
        });
        if (typeof window !== 'undefined') window.supabaseClient = client;
        if (typeof globalThis !== 'undefined') globalThis.supabaseClient = client;
        return client;
      }
    } catch (e) {
      console.warn('[RealtimeService] Không thể tự động khởi tạo Supabase Client:', e);
    }
    return null;
  },

  async subscribeShopChannel(shopId, onDataChanged) {
    if (!shopId) {
      const activeShop = typeof ShopService !== 'undefined' ? await ShopService.getActiveShop() : null;
      if (activeShop) shopId = activeShop.id;
    }
    if (!shopId) return false;

    console.log(`[RealtimeService] Đã lắng nghe Kênh Realtime Shop: shop-${shopId}`);
    const client = await this._getClient();
    if (client) {
      try {
        if (this._activeChannel) {
          client.removeChannel(this._activeChannel);
        }

        const channelName = `shop-${shopId}`;
        this._activeChannel = client
          .channel(channelName)
          .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, payload => {
            console.log('[Realtime] Nhận sự kiện Đơn nháp:', payload?.eventType || 'change');
            if (typeof onDataChanged === 'function') onDataChanged('orders', payload);
          })
          .on('postgres_changes', { event: '*', schema: 'public', table: 'submitted_orders' }, payload => {
            console.log('[Realtime] Nhận sự kiện Đơn đã lên:', payload?.eventType || 'change');
            if (typeof onDataChanged === 'function') onDataChanged('submitted_orders', payload);
          })
          .subscribe();
      } catch (e) {
        console.warn('[RealtimeService] Lỗi subscribe channel:', e);
      }
    }
    return true;
  },

  /**
   * Phương Án 1: Máy trạm phát tín hiệu hiện diện (Presence) qua WebSocket
   * Zero DB write - Tự động phát hiện offline trong vài giây khi tab/trình duyệt đóng
   */
  async trackWorkstationPresence(shopId, deviceInfo) {
    if (!shopId || !deviceInfo?.device_id) return false;
    const client = await this._getClient();
    if (!client) return false;

    const channelName = `workstations-presence-${shopId}`;
    const deviceId = deviceInfo.device_id;

    try {
      let channel = this._presenceChannels.get(channelName);
      if (!channel) {
        channel = client.channel(channelName, {
          config: {
            presence: {
              key: deviceId
            }
          }
        });
        this._presenceChannels.set(channelName, channel);
      }

      const payload = {
        device_id: deviceId,
        device_name: deviceInfo.device_name || 'Máy trạm Kho',
        staff_name: deviceInfo.staff_name || 'Nhân viên',
        user_id: deviceInfo.user_id || null,
        client_type: deviceInfo.client_type || 'EXTENSION',
        surface: deviceInfo.surface || 'EXTENSION_PANEL',
        online_at: new Date().toISOString()
      };

      channel.subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          console.log(`[Realtime Presence] Bắt đầu phát hiện diện trực tuyến: ${deviceId}`);
          await channel.track(payload);
        }
      });

      return true;
    } catch (err) {
      console.warn('[Realtime Presence] Lỗi phát hiện diện:', err);
      return false;
    }
  },

  /**
   * Ngắt tín hiệu hiện diện khi đăng xuất hoặc chủ động tắt máy
   */
  async untrackWorkstationPresence(shopId, deviceId) {
    if (!shopId) return;
    const channelName = `workstations-presence-${shopId}`;
    const channel = this._presenceChannels.get(channelName);
    if (channel) {
      try {
        await channel.untrack();
        const client = await this._getClient();
        if (client) client.removeChannel(channel);
        this._presenceChannels.delete(channelName);
        console.log(`[Realtime Presence] Đã dừng phát hiện diện thiết bị: ${deviceId || ''}`);
      } catch (_) {}
    }
  },

  /**
   * Dashboard Admin & Trang Quản Lý Nhân Viên lắng nghe danh sách máy online trực tiếp
   */
  async subscribeWorkstationPresence(shopId, onPresenceChange) {
    if (!shopId) return () => {};
    const client = await this._getClient();
    if (!client) return () => {};

    const channelName = `workstations-presence-${shopId}`;
    const listenerKey = `listener-${Math.random().toString(36).slice(2, 8)}`;

    try {
      const channel = client.channel(channelName, {
        config: {
          presence: {
            key: listenerKey
          }
        }
      });

      const handlePresenceSync = () => {
        const state = channel.presenceState();
        const onlineMap = {};
        for (const [key, presences] of Object.entries(state)) {
          if (Array.isArray(presences) && presences.length > 0) {
            const latest = presences[presences.length - 1];
            if (latest.device_id) {
              onlineMap[latest.device_id] = latest;
            }
          }
        }
        if (typeof onPresenceChange === 'function') {
          onPresenceChange(onlineMap);
        }
      };

      channel
        .on('presence', { event: 'sync' }, handlePresenceSync)
        .on('presence', { event: 'join' }, handlePresenceSync)
        .on('presence', { event: 'leave' }, handlePresenceSync)
        .subscribe();

      return () => {
        try {
          client.removeChannel(channel);
        } catch (_) {}
      };
    } catch (err) {
      console.warn('[Realtime Presence] Lỗi subscribe presence:', err);
      return () => {};
    }
  }
};

if (typeof globalThis !== 'undefined') {
  globalThis.RealtimeService = RealtimeService;
}
if (typeof window !== 'undefined') {
  window.RealtimeService = RealtimeService;
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { RealtimeService };
}
