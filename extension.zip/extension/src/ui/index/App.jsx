import React, { useState, useEffect } from 'react';
import { AuthSession } from '../../domain/auth/auth.session.esm.js';
import { AuthService } from '../../domain/auth/auth.service.esm.js';

const DEFAULT_SUPABASE = {
  url: 'https://xlgovgynbsahuykyjzcx.supabase.co',
  anonKey: 'sb_publishable_i7Ox-gsXTnPbP_AghSxb4Q_w6-5vbMg'
};

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard'); // dashboard, orders, parse, customers, sync
  const [parseText, setParseText] = useState('');
  const [isParsing, setIsParsing] = useState(false);
  const [parsedResult, setParsedResult] = useState(null);
  const [orderStats, setOrderStats] = useState({
    orders_today: 0,
    cod_today: 0,
    submitted_today: 0,
    drafts: 0,
    orders_total: 0
  });
  const [orders, setOrders] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [customers, setCustomers] = useState([]);
  const [shopName, setShopName] = useState('Auto Fill Order');
  const [isAuth, setIsAuth] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [parseError, setParseError] = useState('');

  // ---------- Helpers ----------
  const getSupabaseConfig = async () => {
    try {
      if (globalThis.SupabaseCloud && typeof globalThis.SupabaseCloud.loadConfig === 'function') {
        const c = await globalThis.SupabaseCloud.loadConfig();
        if (c && c.url && c.anonKey) return c;
      }
    } catch (_) {}
    return DEFAULT_SUPABASE;
  };

  const fmtMoney = (n) => new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(n || 0);
  
  const fmtTime = (iso) => {
    if (!iso) return '';
    try {
      const diff = Date.now() - new Date(iso).getTime();
      const mins = Math.floor(diff / 60000);
      if (mins < 1) return 'Vừa xong';
      if (mins < 60) return `${mins} phút trước`;
      const hours = Math.floor(mins / 60);
      if (hours < 24) return `${hours} giờ trước`;
      return new Date(iso).toLocaleDateString('vi-VN');
    } catch (_) { return ''; }
  };

  // ---------- Load Data ----------
  const loadAll = async () => {
    try {
      const config = await getSupabaseConfig();
      let sess = null;
      try {
        sess = await AuthSession.getSession();
      } catch (_) {}

      const token = (sess && sess.access_token && !sess.access_token.startsWith('local_dev_token_'))
        ? sess.access_token
        : config.anonKey;

      const headers = {
        'apikey': config.anonKey,
        'Authorization': `Bearer ${token}`
      };

      const shopId = sess?.active_shop_id || localStorage.getItem('current_shop_id') || '';

      // 1. Tải thông tin Shop
      if (shopId) {
        try {
          const shopRes = await fetch(`${config.url}/rest/v1/shops?select=name&id=eq.${encodeURIComponent(shopId)}`, { headers });
          if (shopRes.ok) {
            const rows = await shopRes.json();
            if (rows && rows[0]?.name) setShopName(rows[0].name);
          }
        } catch (_) {}
      }

      // 2. Tải danh sách đơn nháp và đơn đã gửi (ĐÃ BỎ LỖI query deleted_at)
      let ordersUrl = `${config.url}/rest/v1/orders?select=*&order=created_at.desc&limit=50`;
      let subUrl = `${config.url}/rest/v1/submitted_orders?select=*&order=submitted_at.desc&limit=100`;
      if (shopId) {
        ordersUrl += `&shop_id=eq.${encodeURIComponent(shopId)}`;
        subUrl += `&shop_id=eq.${encodeURIComponent(shopId)}`;
      }

      const [ordersRes, subRes] = await Promise.all([
        fetch(ordersUrl, { headers }).catch(() => ({ ok: false })),
        fetch(subUrl, { headers }).catch(() => ({ ok: false }))
      ]);

      const draftOrders = ordersRes.ok ? await ordersRes.json() : [];
      const submitted = subRes.ok ? await subRes.json() : [];

      const todayStr = new Date().toISOString().substring(0, 10);
      let codToday = 0;
      let submittedTodayCount = 0;

      const list = [
        ...(draftOrders || []).map(o => ({
          id: o.id,
          name: o.name || 'Đơn nháp',
          phone: o.phone || '',
          address: o.address || '',
          orderCode: o.order_code || '',
          trackingCode: '',
          carrier: '',
          status: 'draft',
          value: Number(o.cod_amount) || 0,
          date: o.created_at,
          tag: 'Nháp'
        })),
        ...(submitted || []).map(s => {
          const val = Number(s.cod_amount) || 0;
          const sDate = (s.submitted_at || s.submitted_date || '').substring(0, 10);
          if (sDate === todayStr) {
            codToday += val;
            submittedTodayCount++;
          }
          return {
            id: s.id,
            name: s.name || '—',
            phone: s.phone || '',
            address: s.address || '',
            orderCode: s.order_code || '',
            trackingCode: s.tracking_code || '',
            carrier: (s.platform || 'VNPost').toUpperCase(),
            status: s.status || 'submitted',
            value: val,
            date: s.submitted_at || s.created_at,
            tag: 'Đã gửi'
          };
        })
      ];

      setOrders(list);

      // Tính toán KPI thực tế
      setOrderStats({
        orders_today: submittedTodayCount,
        cod_today: codToday,
        submitted_today: submittedTodayCount,
        drafts: (draftOrders || []).length,
        orders_total: list.length
      });

      // 3. Gom Khách hàng
      const custMap = new Map();
      list.forEach(item => {
        if (!item.phone || item.phone.length < 9) return;
        const key = item.phone.replace(/\D/g, '');
        const cur = custMap.get(key);
        if (!cur || new Date(item.date) > new Date(cur.last)) {
          custMap.set(key, {
            phone: key,
            name: item.name !== '—' && item.name ? item.name : (cur?.name || 'Khách hàng'),
            address: item.address || cur?.address || '',
            last: item.date,
            count: (cur ? cur.count : 0) + 1,
            totalVal: (cur ? cur.totalVal : 0) + (item.value || 0)
          });
        } else {
          cur.count += 1;
          cur.totalVal += (item.value || 0);
        }
      });
      setCustomers(Array.from(custMap.values()).sort((a, b) => b.count - a.count));

    } catch (err) {
      console.warn('Lỗi tải dữ liệu Index Workspace:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  // ---------- Local Fallback Parser ----------
  const localParseText = (text) => {
    let name = '', phone = '', address = '', orderCode = '', codAmount = 0;

    // Trích xuất SĐT
    const phoneMatch = text.match(/(?:\+84|84|0)(?:\s*[\.\-]?\s*\d){9,10}\b/);
    if (phoneMatch) phone = phoneMatch[0].replace(/\D/g, '');

    // Trích xuất COD
    const codMatch = text.match(/(?:cod|thu hộ|tiền thu|cọc|thu|thanh toán)[\s:]*([0-9\.,]{3,10})(?:\s*k|\s*đ|\s*vnd)?/i) ||
                     text.match(/([0-9]{2,4})k\b/i);
    if (codMatch) {
      let raw = codMatch[1].replace(/[\.,]/g, '');
      if (codMatch[0].toLowerCase().endsWith('k')) raw += '000';
      codAmount = parseInt(raw, 10) || 0;
    }

    // Trích xuất Tên (dòng đầu tiên)
    const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
    if (lines.length > 0) {
      const firstLine = lines[0].replace(phoneMatch ? phoneMatch[0] : '', '').trim();
      if (firstLine.length > 1 && firstLine.length < 40) name = firstLine;
    }

    // Địa chỉ (toàn bộ text bỏ phone, cod, name)
    let cleanAddr = text;
    if (phone) cleanAddr = cleanAddr.replace(phone, '');
    if (name) cleanAddr = cleanAddr.replace(name, '');
    cleanAddr = cleanAddr.replace(/(?:cod|thu hộ|mã đơn|sđt|tên)[\s:]*[^\n]+/gi, '').trim();
    address = cleanAddr.replace(/\n+/g, ', ').replace(/\s{2,}/g, ' ');

    return { name, phone, address, orderCode, codAmount };
  };

  // ---------- Tách đơn AI / Local ----------
  const handleRemoteParse = async (e) => {
    e.preventDefault();
    if (!parseText.trim()) return;
    setIsParsing(true);
    setParseError('');
    setParsedResult(null);

    try {
      const config = await getSupabaseConfig();
      let sess = null;
      try { sess = await AuthSession.getSession(); } catch (_) {}
      
      let parsed = null;
      // Thử gọi AI Gateway
      if (sess && sess.access_token && !sess.access_token.startsWith('local_dev_token_')) {
        try {
          const resp = await fetch(`${config.url}/functions/v1/ai-gateway`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${sess.access_token}`
            },
            body: JSON.stringify({ task: 'parse', text: parseText })
          });
          if (resp.ok) {
            const data = await resp.json();
            parsed = data.data || data.result;
          }
        } catch (_) {}
      }

      // Fallback parser cục bộ thông minh
      if (!parsed) {
        parsed = localParseText(parseText);
      }

      setParsedResult({
        name: parsed.name || 'Khách hàng',
        phone: parsed.phone || '',
        address: parsed.address || parsed.correctAddress || '',
        orderCode: parsed.orderCode || '',
        codAmount: parsed.codAmount || 0
      });

      // Lưu đơn nháp lên Cloud
      try {
        const token = sess?.access_token || config.anonKey;
        await fetch(`${config.url}/rest/v1/orders`, {
          method: 'POST',
          headers: {
            'apikey': config.anonKey,
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            shop_id: sess?.active_shop_id || null,
            name: parsed.name || '',
            phone: parsed.phone || '',
            address: parsed.address || '',
            order_code: parsed.orderCode || '',
            cod_amount: Number(parsed.codAmount) || 0,
            status: 'draft'
          })
        });
        loadAll();
      } catch (_) {}

    } catch (err) {
      setParseError(err.message || 'Lỗi bóc tách đơn hàng');
    } finally {
      setIsParsing(false);
    }
  };

  // Lọc danh sách đơn
  const filteredOrders = orders.filter(o => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    return (o.name || '').toLowerCase().includes(q) ||
           (o.phone || '').includes(q) ||
           (o.orderCode || '').toLowerCase().includes(q) ||
           (o.trackingCode || '').toLowerCase().includes(q);
  });

  if (isLoading) {
    return (
      <div className="mobile-layout" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh' }}>
        <div style={{ textAlign: 'center', color: '#64748b' }}>
          <div style={{ fontSize: '24px', marginBottom: '8px' }}>⏳</div>
          <div style={{ fontWeight: 600 }}>Đang tải Workspace...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="mobile-layout" style={{ maxWidth: '600px', margin: '0 auto', minHeight: '100vh', display: 'flex', flexDirection: 'column', background: '#f8fafc' }}>
      {/* Topbar Header */}
      <header className="mobile-header" style={{ padding: '14px 16px', background: '#ffffff', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'sticky', top: 0, zIndex: 100 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{ background: 'linear-gradient(135deg, #4f46e5, #6366f1)', color: '#fff', width: '32px', height: '32px', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: '13px' }}>
            AF
          </div>
          <div>
            <div style={{ fontWeight: 800, fontSize: '15px', color: '#0f172a', lineHeight: 1.2 }}>Auto Fill Order</div>
            <div style={{ fontSize: '11px', color: '#64748b' }}>{shopName}</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button
            onClick={() => loadAll()}
            style={{ background: '#f1f5f9', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '6px 10px', fontSize: '12px', cursor: 'pointer', fontWeight: 600, color: '#475569' }}
            title="Làm mới dữ liệu"
          >
            🔄
          </button>
          <button
            onClick={() => window.open('/frontend/options/options.html', '_blank')}
            style={{ background: '#4f46e5', border: 'none', borderRadius: '8px', padding: '6px 12px', fontSize: '12px', cursor: 'pointer', fontWeight: 600, color: '#ffffff' }}
          >
            ⚙️ Quản lý
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="mobile-content" style={{ flex: 1, padding: '16px', overflowY: 'auto' }}>
        {/* DASHBOARD TAB */}
        {activeTab === 'dashboard' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {/* Hero KPI Card */}
            <div style={{ background: 'linear-gradient(135deg, #4f46e5, #3730a3)', color: '#fff', padding: '20px', borderRadius: '16px', boxShadow: '0 10px 25px rgba(79, 70, 229, 0.25)' }}>
              <div style={{ fontSize: '12px', opacity: 0.85, fontWeight: 600, letterSpacing: '0.5px' }}>TỔNG ĐƠN GỬI HÔM NAY</div>
              <div style={{ fontSize: '32px', fontWeight: 800, margin: '6px 0 10px 0' }}>
                {orderStats.orders_today} <span style={{ fontSize: '16px', fontWeight: 500 }}>đơn</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', borderTop: '1px solid rgba(255,255,255,0.15)', paddingTop: '10px' }}>
                <span>Tiền COD: <strong>{fmtMoney(orderStats.cod_today)}</strong></span>
                <span>Đơn nháp: <strong>{orderStats.drafts}</strong></span>
              </div>
            </div>

            {/* Quick Actions Grid */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
              <div style={{ background: '#ffffff', padding: '16px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
                <div style={{ fontSize: '12px', color: '#64748b', fontWeight: 600 }}>TỔNG ĐƠN HÀNG</div>
                <div style={{ fontSize: '22px', fontWeight: 800, color: '#0f172a', marginTop: '4px' }}>{orderStats.orders_total}</div>
              </div>
              <div style={{ background: '#ffffff', padding: '16px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
                <div style={{ fontSize: '12px', color: '#64748b', fontWeight: 600 }}>KHÁCH HÀNG</div>
                <div style={{ fontSize: '22px', fontWeight: 800, color: '#0f172a', marginTop: '4px' }}>{customers.length}</div>
              </div>
            </div>

            {/* CTA Button */}
            <button
              onClick={() => setActiveTab('parse')}
              style={{
                padding: '14px', background: '#10b981', color: '#fff', border: 'none', borderRadius: '12px',
                fontWeight: 700, fontSize: '15px', cursor: 'pointer', textAlign: 'center', boxShadow: '0 4px 14px rgba(16, 185, 129, 0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px'
              }}
            >
              <span>⚡</span> TÁCH ĐƠN HÀNG NHANH
            </button>

            {/* Recent Orders Preview */}
            <div style={{ background: '#ffffff', padding: '16px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                <h4 style={{ margin: 0, fontSize: '14px', fontWeight: 700 }}>Đơn hàng gần đây</h4>
                <button onClick={() => setActiveTab('orders')} style={{ background: 'none', border: 'none', color: '#4f46e5', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}>Xem tất cả →</button>
              </div>
              {orders.slice(0, 5).map(o => (
                <div key={o.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #f1f5f9' }}>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: '13px', color: '#0f172a' }}>{o.name}</div>
                    <div style={{ fontSize: '11px', color: '#64748b' }}>📞 {o.phone || '—'} {o.trackingCode ? `• 📦 ${o.trackingCode}` : ''}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontWeight: 700, fontSize: '13px', color: '#10b981' }}>{fmtMoney(o.value)}</div>
                    <span style={{ fontSize: '10px', background: o.tag === 'Nháp' ? '#f1f5f9' : '#dcfce7', color: o.tag === 'Nháp' ? '#475569' : '#15803d', padding: '1px 6px', borderRadius: '4px', fontWeight: 600 }}>{o.tag}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ORDERS TAB */}
        {activeTab === 'orders' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 800 }}>📦 Quản lý Đơn hàng ({filteredOrders.length})</h3>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="🔍 Tìm theo Tên, SĐT, Mã đơn, Vận đơn..."
              style={{ padding: '10px 14px', borderRadius: '10px', border: '1px solid #cbd5e1', fontSize: '13px', width: '100%', outline: 'none' }}
            />
            {filteredOrders.length === 0 ? (
              <div style={{ padding: '40px 20px', textAlign: 'center', color: '#94a3b8', background: '#ffffff', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
                Không tìm thấy đơn hàng phù hợp.
              </div>
            ) : filteredOrders.map(o => (
              <div key={o.id} style={{ padding: '14px', background: '#ffffff', borderRadius: '12px', border: '1px solid #e2e8f0', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontWeight: 700, fontSize: '14px', color: '#0f172a' }}>{o.name}</span>
                  <span style={{ fontSize: '10px', background: o.tag === 'Nháp' ? '#f1f5f9' : '#dcfce7', color: o.tag === 'Nháp' ? '#475569' : '#15803d', padding: '2px 8px', borderRadius: '6px', fontWeight: 700 }}>{o.tag}</span>
                </div>
                <div style={{ fontSize: '12px', color: '#475569' }}>
                  📞 {o.phone || '—'} {o.value > 0 ? `• 💰 ${fmtMoney(o.value)}` : ''}
                </div>
                {o.address && <div style={{ fontSize: '12px', color: '#64748b' }}>📍 {o.address}</div>}
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#94a3b8', marginTop: '4px', borderTop: '1px solid #f1f5f9', paddingTop: '6px' }}>
                  <span>{fmtTime(o.date)}</span>
                  {o.trackingCode && <span style={{ fontWeight: 700, color: '#4f46e5', fontFamily: 'monospace' }}>📦 {o.trackingCode}</span>}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* PARSE TAB */}
        {activeTab === 'parse' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <div>
              <h3 style={{ margin: '0 0 4px 0', fontSize: '16px', fontWeight: 800 }}>⚡ Bóc tách Đơn hàng</h3>
              <p style={{ fontSize: '12px', color: '#64748b', margin: 0 }}>
                Dán tin nhắn khách hàng (Zalo, Messenger, TikTok) để bóc tách thông tin tức thì.
              </p>
            </div>

            <form onSubmit={handleRemoteParse} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <textarea
                rows={6}
                value={parseText}
                onChange={(e) => setParseText(e.target.value)}
                placeholder="Dán tin nhắn chứa tên, số điện thoại, địa chỉ và tiền thu COD vào đây..."
                style={{ padding: '12px', borderRadius: '12px', border: '1.5px solid #cbd5e1', fontSize: '13px', resize: 'vertical', width: '100%', outline: 'none', fontFamily: 'inherit' }}
              />
              <button
                type="submit"
                disabled={isParsing || !parseText.trim()}
                style={{
                  padding: '14px', background: '#4f46e5', color: '#fff', border: 'none', borderRadius: '12px',
                  fontWeight: 700, fontSize: '14px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px'
                }}
              >
                {isParsing ? '⏳ Đang phân tích...' : '🤖 Bóc tách thông tin'}
              </button>
            </form>

            {parseError && (
              <div style={{ background: '#fef2f2', border: '1px solid #fecaca', padding: '12px', borderRadius: '10px', fontSize: '13px', color: '#b91c1c' }}>
                ❌ {parseError}
              </div>
            )}

            {parsedResult && (
              <div style={{ background: '#f0fdf4', border: '1.5px solid #86efac', padding: '16px', borderRadius: '12px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <div style={{ fontWeight: 800, fontSize: '14px', color: '#166534', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  ✅ Kết quả bóc tách
                </div>
                <div style={{ fontSize: '13px', color: '#1f2937' }}><strong>Họ tên:</strong> {parsedResult.name || '—'}</div>
                <div style={{ fontSize: '13px', color: '#1f2937' }}><strong>Số điện thoại:</strong> {parsedResult.phone || '—'}</div>
                <div style={{ fontSize: '13px', color: '#1f2937' }}><strong>Địa chỉ:</strong> {parsedResult.address || '—'}</div>
                <div style={{ fontSize: '13px', color: '#1f2937' }}><strong>Tiền COD:</strong> {fmtMoney(parsedResult.codAmount)}</div>
                <div style={{ fontSize: '11px', color: '#15803d', marginTop: '6px', borderTop: '1px solid #bbf7d0', paddingTop: '8px' }}>
                  Đơn đã được lưu vào danh sách đơn nháp trên hệ thống!
                </div>
              </div>
            )}
          </div>
        )}

        {/* CUSTOMERS TAB */}
        {activeTab === 'customers' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 800 }}>👥 Sổ tay Khách hàng ({customers.length})</h3>
            {customers.length === 0 ? (
              <div style={{ padding: '40px 20px', textAlign: 'center', color: '#94a3b8', background: '#ffffff', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
                Chưa có dữ liệu khách hàng.
              </div>
            ) : customers.map((c, i) => (
              <div key={c.phone + i} style={{ padding: '14px', background: '#ffffff', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontWeight: 700, fontSize: '14px', color: '#0f172a' }}>{c.name}</span>
                  <span style={{ fontSize: '11px', background: '#e0e7ff', color: '#4338ca', padding: '2px 8px', borderRadius: '6px', fontWeight: 700 }}>{c.count} Đơn</span>
                </div>
                <div style={{ fontSize: '12px', color: '#475569', marginTop: '4px' }}>📞 {c.phone} • Tổng tiền: {fmtMoney(c.totalVal)}</div>
                {c.address && <div style={{ fontSize: '12px', color: '#64748b', marginTop: '4px' }}>📍 {c.address}</div>}
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="mobile-nav" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', background: '#ffffff', borderTop: '1px solid #e2e8f0', position: 'sticky', bottom: 0, zIndex: 100 }}>
        <button
          onClick={() => setActiveTab('dashboard')}
          style={{ padding: '10px 4px', border: 'none', background: 'none', color: activeTab === 'dashboard' ? '#4f46e5' : '#64748b', fontWeight: activeTab === 'dashboard' ? 700 : 500, fontSize: '11px', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '2px' }}
        >
          <span style={{ fontSize: '18px' }}>📊</span>
          Dashboard
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          style={{ padding: '10px 4px', border: 'none', background: 'none', color: activeTab === 'orders' ? '#4f46e5' : '#64748b', fontWeight: activeTab === 'orders' ? 700 : 500, fontSize: '11px', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '2px' }}
        >
          <span style={{ fontSize: '18px' }}>📦</span>
          Đơn hàng
        </button>
        <button
          onClick={() => setActiveTab('parse')}
          style={{ padding: '10px 4px', border: 'none', background: 'none', color: activeTab === 'parse' ? '#4f46e5' : '#64748b', fontWeight: activeTab === 'parse' ? 700 : 500, fontSize: '11px', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '2px' }}
        >
          <span style={{ fontSize: '18px' }}>⚡</span>
          Tách đơn
        </button>
        <button
          onClick={() => setActiveTab('customers')}
          style={{ padding: '10px 4px', border: 'none', background: 'none', color: activeTab === 'customers' ? '#4f46e5' : '#64748b', fontWeight: activeTab === 'customers' ? 700 : 500, fontSize: '11px', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '2px' }}
        >
          <span style={{ fontSize: '18px' }}>👥</span>
          Khách hàng
        </button>
      </nav>
    </div>
  );
}